{
	"version": "147",
	"lastModified": "2025-11-21T00:00:00Z",
	"X308": "HL_Calc_V59_251215",
	"X309": "CCPL_Calc_V12_251215",
	"termsAndConditions": {
		"version": "1.0",
		"url": "https://www.anz.com/mobile-au/en/holmes/content.html",
		"applicableDate": "29/06/2015"
	},
	"employmentIncludeBonus": {
		"endDateLimitInDays": "60",
		"startDateLimitInMonths": "18",
		"startDateRangeBegining": "01-07-2021",
		"startDateRangeEnd": "15-08-2021"
	},
	"productBrouchers": [{
		"title": "ANZ Personal Banking Account Fees and Charges booklet",
		"url": "https://www.anz.com.au/content/dam/anzcomau/documents/pdf/personal-account-fees-charges.pdf"
		}, {
		"title": "ANZ Consumer Lending Terms and Conditions booklet",
		"url": "https://www.anz.com.au/content/dam/anzcomau/documents/pdf/consumer-lending-tc.pdf"
		}, {
		"title": "Home & Investment loan brochure",
		"url": "https://www.anz.com.au/content/dam/anzcomau/documents/pdf/anz-mortgages-hero-brochure.pdf"
		}, {
		"title": "ANZ Fixed Rate loans brochure",
		"url": "https://www.anz.com.au/content/dam/anzcomau/documents/pdf/fixed-rate-loans-what-happens-if-you-pay-early.pdf"
		}, {
		"title": "ANZ Breakfree Terms and Conditions",
		"url": "https://www.anz.com.au/content/dam/anzcomau/documents/pdf/breakfree-tc.pdf"
		}, {
		"title": "Key Fact Sheet for Credit Cards",
		"url": "https://www.anz.com.au/content/dam/anzcomau/documents/pdf/anz-credit-cards-key-facts-sheet.pdf"
		}],
	"parameters": {
		"X001": "0.03",
		"X002": "0.03",
		"X301": "0.0225",
		"X302": "0.015",
		"X303": "0.03",
		"X304": "0.03",
		"X021": "0",
		"X014": "0.8",
		"X020": "1000",
		"X012": "0.038",
		"X010": "0.06",
		"X008": "0.03",
		"X006": "30",
		"X003": "30",
		"X004": "25",
		"X209": "7",
		"X210": "10",
		"X005": "7",
		"X315": "10",
		"X016": "0.39",
		"X011": "0.8",
		"X013": "0.8",
		"X009": "0.8",
		"X015": "0.39",
		"X022": "0.07317",
		"medicareLevySurchargeFamilyPerChildThresholdIncrease": "1500",
		"medicareLevySurchargeFamilyChildrenCountWithoutThresholdIncrease": "1",
		"X007": "0.8",
		"X207": "0.9",
		"X317": "0.75",
		"X208": "0.8",
		"X206": "0.1",
		"suburbSummaryBaseUrl": "https://www.realestate.com.au/neighbourhoods/",
		"suburbSummaryDisclaimerText": "You have left 'Your Home Loan 360' and are on a third party website. ANZ takes no responsibility for this third party site.",
		"suburbSummaryEnabled": true,
		"anzPropertyProfileUrl": "https://vis.rpdata.com/anz/uas/logon.xhtml",
		"mandatorySuperannuationContributions": "0.12",
		"X024": "80",
		"X025": "90",
		"X026": "92",
		"X027": "95",
		"X028": "97",
		"X035": "0",
		"X036": "0.051",
		"X040": "1000",
		"maximumFundsRemainingBuyingPower": "1000",
		"maximumPossibleBuyingPowerLvrWithoutLmi": "X024",
		"maximumPossibleBuyingPowerLvrWithLmi": "X024",
		"defaultRentalYield": "0.04",
		"X203": "0.07",
		"defaultDutiableValuePercent": "1",
		"minimumCreditCardLimitBreakfree": "6000",
		"defaultBuyingPowerNonAnzCustomer": "X025",
		"defaultBuyingPowerAnzCustomer": "X027",
		"defaultBankFeesRefinance": "0",
		"defaultBankFeesRefinanceNoAdditionalFunds": "0",
		"propertyProfileReportCacheDuration": "2",
		"X044": "0.8",
		"X045": "0.8",
		"X046": "600",
		"migLockoutInDays": "1",
		"X058": "0.2",
		"X059": "-0.2",
		"X076": false,
		"backupGenerationEnabled": true,
		"backupWith": "email",
		"X108": "0.4",
		"X109": "0.03",
		"X110": "1.4",
		"X111": "1.1",
		"X113": "1",
		"X112": "0.8",
		"X224": "0.75",
		"X146": "0.15",
		"X160": "0.2",
		"X117": false,
		"X163": "3",
		"X118": "3",
		"X119": "0.85",
		"X197": "0.9",
		"X199": "0.95",
		"X200": "1",
		"X198": "0.65",
		"X290": "0.7",
		"X205": "0.2",
		"X223": "750",
		"X291": "75000",
		"X292": "75000",
		"X305": "1.05",
		"X306": "15",
		"X311": "1.15",
		"X312": "15",
		"X313": "1.2",
		"X314": "0.8"
	},
	"effectiveDateLVRThreshold": "2024-09-23T00:00:00Z",
	"X280": "3000000",
	"X281": "750000",
	"X037": [{
		"X098": true,
		"repaymentTypes": ["Line of Credit"],
		"repaymentType": "Line of Credit",
		"withoutLmi": "0",
		"excludingLmi": "0",
		"includingLmi": "0",
		"X100": false,
		"X251": "0",
		"X252": "0"
		}, {
		"X089": ["RSTD","RSTA","RLUO", "RCOT", "RRUL", "RRU2"],
		"X068": true,
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "70",
		"includingLmi": "70",
		"X100": false,
		"X251": "70",
		"X252": "70"
		}, {
		"X089": ["RCOT", "RRUL", "RRU2"],
		"X065": ["N/A"],
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "70",
		"includingLmi": "70",
		"X100": false,
		"X251": "70",
		"X252": "70"
		}, {
		"X089": ["RSTD","RSTA","RLUO"],
		"X091": "4000000",
		"X065": ["N/A"],
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "4000000",
		"X065": ["N/A"],
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RCOT", "RRUL", "RRU2"],
		"loDoc": false,
		"repaymentTypes": ["Line of Credit"],
		"repaymentType": "Line of Credit",
		"withoutLmi": "70",
		"excludingLmi": "70",
		"includingLmi": "70",
		"X100": false,
		"X251": "70",
		"X252": "70"
		}, {
		"X089": ["RSTD","RSTA","RLUO"],
		"X091": "4000000",
		"loDoc": false,
		"repaymentTypes": ["Line of Credit"],
		"repaymentType": "Line of Credit",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "4000000",
		"loDoc": false,
		"repaymentTypes": ["Line of Credit"],
		"repaymentType": "Line of Credit",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RCOT", "RRUL", "RRU2"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"repaymentTypes": ["Interest Only", "Interest In Advance"],
		"repaymentType": "Interest Only",
		"withoutLmi": "70",
		"excludingLmi": "70",
		"includingLmi": "70",
		"X100": false,
		"X251": "70",
		"X252": "70"
		}, {
		"X089": ["RSTD","RSTA","RLUO"],
		"X091": "4000000",
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"repaymentTypes": ["Interest Only", "Interest In Advance"],
		"repaymentType": "Interest Only",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "4000000",
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"repaymentTypes": ["Interest Only", "Interest In Advance"],
		"repaymentType": "Interest Only",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RCOT", "RRUL", "RRU2"],
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "70",
		"excludingLmi": "70",
		"includingLmi": "70",
		"X100": false,
		"X251": "70",
		"X252": "70"
		}, {
		"X089": ["RCOT", "RRUL", "RRU2"],
		"X091": "4000000",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurpose": ["Refinance Non-ANZ investment loan", "Refinance Non-ANZ Loan"],
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RLUO"],
		"X091": "4000000",
		"X065": ["On Application"],
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "70",
		"X252": "70"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "4000000",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "4000000",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurpose": ["Refinance Non-ANZ investment loan", "Refinance Non-ANZ Loan"],
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "4000000",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "4000000",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurpose": ["Refinance Non-ANZ investment loan", "Refinance Non-ANZ Loan"],
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2631579",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "95",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X251": "95",
		"X252": "97",
		"X104": "WITHOUT LMI",
		"X216": "90",
		"X217": "INV WITH LMI",
		"X105": "INV WITH LMI",
		"X106": "INV FAIL"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "3125000",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"X099": "2500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X252": "97",
		"X104": "WITHOUT LMI",
		"X216": "90",
		"X217": "INV WITH LMI",
		"X105": "INV WITH LMI",
		"X106": "INV FAIL"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2631579",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"withoutLmi": "80",
		"excludingLmi": "95",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X251": "95",
		"X252": "97",
		"X104": "WITHOUT LMI",
		"X216": "92",
		"X217": "OO WITH LMI NTB",
		"X105": "OO WITH LMI EXISTING",
		"X106": "OO EX LVR FAIL"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "3125000",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"withoutLmi": "80",
		"X099": "2500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X252": "97",
		"X104": "WITHOUT LMI",
		"X216": "92",
		"X217": "OO WITH LMI NTB",
		"X105": "OO WITH LMI EXISTING",
		"X106": "OO EX LOAN FAIL"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2105264",
		"X065": ["Category 2"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "95",
		"includingLmi": "97",
		"X100": true,
		"X250": "2000000",
		"X251": "95",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2500000",
		"X065": ["Category 2"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "80",
		"X099": "2000000",
		"includingLmi": "97",
		"X100": true,
		"X250": "2000000",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1052632",
		"X065": ["Category 3"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "95",
		"includingLmi": "97",
		"X100": true,
		"X250": "1000000",
		"X251": "95",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1111112",
		"X065": ["Category 3"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "80",
		"X099": "1000000",
		"includingLmi": "97",
		"X100": true,
		"X250": "1000000",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1666667",
		"X065": ["Category 3"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X251": "90",
		"X252": "92"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1875000",
		"X065": ["Category 3"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "80",
		"X099": "1500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X252": "92"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "526316",
		"X065": ["On Application"],
		"X215": "6",
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"excludingLmi": "95",
		"includingLmi": "97",
		"X100": true,
		"X250": "500000",
		"X251": "95",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "588236",
		"X065": ["On Application"],
		"X215": "6",
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"X099": "500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "500000",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "882353",
		"X065": ["On Application"],
		"X215": "6",
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X251": "85",
		"X252": "87"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "937500",
		"X065": ["On Application"],
		"X215": "6",
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"X099": "750000",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X252": "87"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2777778",
		"X065": ["Category 1"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "90",
		"X100": true,
		"X250": "2500000",
		"X251": "90",
		"X252": "90"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "3125000",
		"X065": ["Category 1"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"X099": "2500000",
		"includingLmi": "90",
		"X100": true,
		"X250": "2500000",
		"X252": "90"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2222223",
		"X065": ["Category 2"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "90",
		"X100": true,
		"X250": "2000000",
		"X251": "90",
		"X252": "90"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2500000",
		"X065": ["Category 2"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"X099": "2000000",
		"includingLmi": "90",
		"X100": true,
		"X250": "2000000",
		"X252": "90"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1666667",
		"X065": ["Category 3"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "90",
		"X100": true,
		"X250": "1500000",
		"X251": "90",
		"X252": "90"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1875000",
		"X065": ["Category 3"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"X099": "1500000",
		"includingLmi": "90",
		"X100": true,
		"X250": "1500000",
		"X252": "90"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2631579",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"excludingLmi": "95",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X251": "95",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2777778",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "92",
		"X100": true,
		"X250": "2500000",
		"X251": "90",
		"X252": "92"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "3125000",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"X099": "2500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "3125000",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "80",
		"X099": "2500000",
		"includingLmi": "92",
		"X100": true,
		"X250": "2500000",
		"X252": "92"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2105264",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"excludingLmi": "95",
		"includingLmi": "97",
		"X100": true,
		"X250": "2000000",
		"X251": "95",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2222223",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "92",
		"X100": true,
		"X250": "2000000",
		"X251": "90",
		"X252": "92"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2500000",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"X099": "2000000",
		"includingLmi": "97",
		"X100": true,
		"X250": "2000000",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "2500000",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "80",
		"X099": "2000000",
		"includingLmi": "92",
		"X100": true,
		"X250": "2000000",
		"X252": "92"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1052632",
		"X065": ["Category 3"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"excludingLmi": "95",
		"includingLmi": "97",
		"X100": true,
		"X250": "1000000",
		"X251": "95",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1111112",
		"X065": ["Category 3"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"X099": "1000000",
		"includingLmi": "97",
		"X100": true,
		"X250": "1000000",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1666667",
		"X065": ["Category 3"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X251": "90",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1666667",
		"X065": ["Category 3"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "92",
		"X100": true,
		"X250": "1500000",
		"X251": "90",
		"X252": "92"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1875000",
		"X065": ["Category 3"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"X099": "1500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "1875000",
		"X065": ["Category 3"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "80",
		"X099": "1500000",
		"includingLmi": "92",
		"X100": true,
		"X250": "1500000",
		"X252": "92"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "526316",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": true,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"excludingLmi": "95",
		"includingLmi": "97",
		"X100": true,
		"X250": "500000",
		"X251": "95",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "555556",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "92",
		"X100": true,
		"X250": "500000",
		"X251": "90",
		"X252": "92"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "588236",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": true,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"X099": "500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "500000",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "588236",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"X099": "500000",
		"includingLmi": "92",
		"X100": true,
		"X250": "500000",
		"X252": "92"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "882353",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": true,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X251": "85",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "882353",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"excludingLmi": "85",
		"includingLmi": "92",
		"X100": true,
		"X250": "750000",
		"X251": "85",
		"X252": "92"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "937500",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": true,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"X099": "750000",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X252": "97"
		}, {
		"X089": ["RSTD","RSTA"],
		"X091": "937500",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "80",
		"X099": "750000",
		"includingLmi": "92",
		"X100": true,
		"X250": "750000",
		"X252": "92"
		}, {
		"X089": ["RLUO"],
		"X091": "833334",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X251": "90",
		"X252": "97"
		}, {
		"X089": ["RLUO"],
		"X091": "882353",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "80",
		"X099": "750000",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X252": "97"
		}, {
		"X089": ["RLUO"],
		"X091": "1176471",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "1000000",
		"X251": "85",
		"X252": "97"
		}, {
		"X089": ["RLUO"],
		"X091": "1250000",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "80",
		"X099": "1000000",
		"includingLmi": "97",
		"X100": true,
		"X250": "1000000",
		"X252": "97"
		}, {
		"X089": ["RLUO"],
		"X091": "833334",
		"X065": ["Category 1"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "90",
		"X100": true,
		"X250": "750000",
		"X251": "90",
		"X252": "90"
		}, {
		"X089": ["RLUO"],
		"X091": "882353",
		"X065": ["Category 1"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"X099": "750000",
		"includingLmi": "90",
		"X100": true,
		"X250": "750000",
		"X252": "90"
		}, {
		"X089": ["RLUO"],
		"X091": "1176471",
		"X065": ["Category 1"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "85",
		"includingLmi": "90",
		"X100": true,
		"X250": "1000000",
		"X251": "85",
		"X252": "90"
		}, {
		"X089": ["RLUO"],
		"X091": "1250000",
		"X065": ["Category 1"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"X099": "1000000",
		"includingLmi": "90",
		"X100": true,
		"X250": "1000000",
		"X252": "90"
		}, {
		"X089": ["RLUO"],
		"X091": "833334",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X251": "90",
		"X252": "97"
		}, {
		"X089": ["RLUO"],
		"X091": "882353",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"X099": "750000",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X252": "97"
		}, {
		"X089": ["RLUO"],
		"X091": "1176471",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "1000000",
		"X251": "85",
		"X252": "97"
		}, {
		"X089": ["RLUO"],
		"X091": "1250000",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "80",
		"X099": "1000000",
		"includingLmi": "97",
		"X100": true,
		"X250": "1000000",
		"X252": "97"
		}, {
		"X089": ["RLUO"],
		"X091": "833334",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "80",
		"excludingLmi": "90",
		"includingLmi": "92",
		"X100": true,
		"X250": "750000",
		"X251": "90",
		"X252": "92"
		}, {
		"X089": ["RLUO"],
		"X091": "882353",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "80",
		"X099": "750000",
		"includingLmi": "92",
		"X100": true,
		"X250": "750000",
		"X252": "92"
		}, {
		"X089": ["RLUO"],
		"X091": "1176471",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "80",
		"excludingLmi": "85",
		"includingLmi": "92",
		"X100": true,
		"X250": "1000000",
		"X251": "85",
		"X252": "92"
		}, {
		"X089": ["RLUO"],
		"X091": "1250000",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "80",
		"X099": "1000000",
		"includingLmi": "92",
		"X100": true,
		"X250": "1000000",
		"X252": "92"
		}, {
		"X089": ["RCOT"],
		"X091": "2941177",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X251": "85",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "3571429",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "70",
		"X099": "2500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "2352942",
		"X065": ["Category 2"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "2000000",
		"X251": "85",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "2857143",
		"X065": ["Category 2"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "70",
		"X099": "2000000",
		"includingLmi": "97",
		"X100": true,
		"X250": "2000000",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "1764706",
		"X065": ["Category 3"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X251": "85",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "2142858",
		"X065": ["Category 3"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "70",
		"X099": "1500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "882353",
		"X065": ["On Application"],
		"X215": "6",
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X251": "85",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "1071429",
		"X065": ["On Application"],
		"X215": "6",
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "70",
		"X099": "750000",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "2941177",
		"X065": ["Category 1"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "90",
		"X100": true,
		"X250": "2500000",
		"X251": "85",
		"X252": "90"
		}, {
		"X089": ["RCOT"],
		"X091": "3571429",
		"X065": ["Category 1"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "70",
		"X099": "2500000",
		"includingLmi": "90",
		"X100": true,
		"X250": "2500000",
		"X252": "90"
		}, {
		"X089": ["RCOT"],
		"X091": "2352942",
		"X065": ["Category 2"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "90",
		"X100": true,
		"X250": "2000000",
		"X251": "85",
		"X252": "90"
		}, {
		"X089": ["RCOT"],
		"X091": "2857143",
		"X065": ["Category 2"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "70",
		"X099": "2000000",
		"includingLmi": "90",
		"X100": true,
		"X250": "2000000",
		"X252": "90"
		}, {
		"X089": ["RCOT"],
		"X091": "1764706",
		"X065": ["Category 3"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "90",
		"X100": true,
		"X250": "1500000",
		"X251": "85",
		"X252": "90"
		}, {
		"X089": ["RCOT"],
		"X091": "2142858",
		"X065": ["Category 3"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "70",
		"X099": "1500000",
		"includingLmi": "90",
		"X100": true,
		"X250": "1500000",
		"X252": "90"
		}, {
		"X089": ["RCOT"],
		"X091": "2941177",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X251": "85",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "3571429",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "70",
		"X099": "2500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "2352942",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "2000000",
		"X251": "85",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "2857143",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "70",
		"X099": "2000000",
		"includingLmi": "97",
		"X100": true,
		"X250": "2000000",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "1764706",
		"X065": ["Category 3"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X251": "85",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "2142858",
		"X065": ["Category 3"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "70",
		"X099": "1500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "882353",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": true,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X251": "85",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "1071429",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": true,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "70",
		"X099": "750000",
		"includingLmi": "97",
		"X100": true,
		"X250": "750000",
		"X252": "97"
		}, {
		"X089": ["RCOT"],
		"X091": "2941177",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "92",
		"X100": true,
		"X250": "2500000",
		"X251": "85",
		"X252": "92"
		}, {
		"X089": ["RCOT"],
		"X091": "3571429",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "70",
		"X099": "2500000",
		"includingLmi": "92",
		"X100": true,
		"X250": "2500000",
		"X252": "92"
		}, {
		"X089": ["RCOT"],
		"X091": "2352942",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "92",
		"X100": true,
		"X250": "2000000",
		"X251": "85",
		"X252": "92"
		}, {
		"X089": ["RCOT"],
		"X091": "2857143",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "70",
		"X099": "2000000",
		"includingLmi": "92",
		"X100": true,
		"X250": "2000000",
		"X252": "92"
		}, {
		"X089": ["RCOT"],
		"X091": "1764706",
		"X065": ["Category 3"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "92",
		"X100": true,
		"X250": "1500000",
		"X251": "85",
		"X252": "92"
		}, {
		"X089": ["RCOT"],
		"X091": "2142858",
		"X065": ["Category 3"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "70",
		"X099": "1500000",
		"includingLmi": "92",
		"X100": true,
		"X250": "1500000",
		"X252": "92"
		}, {
		"X089": ["RCOT"],
		"X091": "882353",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "70",
		"excludingLmi": "85",
		"includingLmi": "92",
		"X100": true,
		"X250": "750000",
		"X251": "85",
		"X252": "92"
		}, {
		"X089": ["RCOT"],
		"X091": "1071429",
		"X065": ["On Application"],
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"existingCustomer": false,
		"predominantPurpose": ["New Motor Car",
"Used Motor Car",
"Motor Cycles",
"Boats or Caravans",
"Residential Land",
"Household/Personal",
"Travel Holidays",
"Construction-Not 1st Home",
"Construction-1st Home",
"Purch New Home-Not 1st Home",
"Purch New Home-1st Home",
"Purch Estab Home-Not 1st Home",
"Purch Estab Home-1st Home",
"Home - Improvements"],
		"withoutLmi": "70",
		"X099": "750000",
		"includingLmi": "92",
		"X100": true,
		"X250": "750000",
		"X252": "92"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "2777778",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "90",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X251": "90",
		"X252": "97"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "3571429",
		"X065": ["Category 1"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "70",
		"X099": "2500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X252": "97"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "1666667",
		"X065": ["Category 2"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "90",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X251": "90",
		"X252": "97"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "2142858",
		"X065": ["Category 2"],
		"X215": "6",
		"loDoc": false,
		"withoutLmi": "70",
		"X099": "1500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X252": "97"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "2777778",
		"X065": ["Category 1"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "70",
		"excludingLmi": "90",
		"includingLmi": "90",
		"X100": true,
		"X250": "2500000",
		"X251": "90",
		"X252": "90"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "3571429",
		"X065": ["Category 1"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "70",
		"X099": "2500000",
		"includingLmi": "90",
		"X100": true,
		"X250": "2500000",
		"X252": "90"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "1666667",
		"X065": ["Category 2"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "70",
		"excludingLmi": "90",
		"includingLmi": "90",
		"X100": true,
		"X250": "1500000",
		"X251": "90",
		"X252": "90"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "2142858",
		"X065": ["Category 2"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "70",
		"X099": "1500000",
		"includingLmi": "90",
		"X100": true,
		"X250": "1500000",
		"X252": "90"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "2777778",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "70",
		"excludingLmi": "90",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X251": "90",
		"X252": "97"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "3571429",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "70",
		"X099": "2500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "2500000",
		"X252": "97"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "1666667",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "70",
		"excludingLmi": "90",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X251": "90",
		"X252": "97"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "2142858",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": true,
		"withoutLmi": "70",
		"X099": "1500000",
		"includingLmi": "97",
		"X100": true,
		"X250": "1500000",
		"X252": "97"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "2777778",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "70",
		"excludingLmi": "90",
		"includingLmi": "92",
		"X100": true,
		"X250": "2500000",
		"X251": "90",
		"X252": "92"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "3571429",
		"X065": ["Category 1"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "70",
		"X099": "2500000",
		"includingLmi": "92",
		"X100": true,
		"X250": "2500000",
		"X252": "92"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "1666667",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "70",
		"excludingLmi": "90",
		"includingLmi": "92",
		"X100": true,
		"X250": "1500000",
		"X251": "90",
		"X252": "92"
		}, {
		"X089": ["RRUL", "RRU2"],
		"X091": "2142858",
		"X065": ["Category 2"],
		"loDoc": false,
		"existingCustomer": false,
		"withoutLmi": "70",
		"X099": "1500000",
		"includingLmi": "92",
		"X100": true,
		"X250": "1500000",
		"X252": "92"
		}, {
		"X089": ["RSTA", "RLUO"],
		"X091": "4000000",
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": true,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "4000000",
		"X098": true,
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": true,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X091": "4000000",
		"X098": true,
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": true,
		"X251": "80",
		"X252": "80",
		"X104": "WITHOUT LMI",
		"X106": "INV FAIL HIGH"
		}, {
		"X089": ["RSTD"],
		"X091": "4000000",
		"X098": true,
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": true,
		"X251": "80",
		"X252": "80",
		"X104": "WITHOUT LMI",
		"X106": "OO FAIL HIGH"
		}, {
		"X089": ["RSTD"],
		"X091": "5000000",
		"X065": ["N/A"],
		"X098": false,
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "5000000",
		"X065": ["N/A"],
		"X098": false,
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X091": "5000000",
		"X098": false,
		"loDoc": false,
		"repaymentTypes": ["Line of Credit"],
		"repaymentType": "Line of Credit",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "5000000",
		"X098": false,
		"loDoc": false,
		"repaymentTypes": ["Line of Credit"],
		"repaymentType": "Line of Credit",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X091": "5000000",
		"X098": false,
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"repaymentTypes": ["Interest Only", "Interest In Advance"],
		"repaymentType": "Interest Only",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "5000000",
		"X098": false,
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"repaymentTypes": ["Interest Only", "Interest In Advance"],
		"repaymentType": "Interest Only",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X091": "5000000",
		"X065": ["On Application"],
		"X098": false,
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X091": "5000000",
		"X065": ["On Application"],
		"X098": false,
		"loDoc": false,
		"predominantPurpose": ["Refinance Non-ANZ investment loan", "Refinance Non-ANZ Loan"],
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "5000000",
		"X065": ["On Application"],
		"X098": false,
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "5000000",
		"X065": ["On Application"],
		"X098": false,
		"loDoc": false,
		"predominantPurpose": ["Refinance Non-ANZ investment loan", "Refinance Non-ANZ Loan"],
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"X091": "5000000",
		"X098": false,
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": true,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X091": "5000000",
		"X098": false,
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": true,
		"X251": "80",
		"X252": "80",
		"X104": "WITHOUT LMI",
		"X106": "INV FAIL HIGH"
		}, {
		"X089": ["RSTD"],
		"X091": "5000000",
		"X098": false,
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": true,
		"X251": "80",
		"X252": "80",
		"X104": "WITHOUT LMI",
		"X106": "OO FAIL HIGH"
		}, {
		"X089": ["RSTD","RSTA","RLUO"],
		"X215": ["9999"],
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "75",
		"excludingLmi": "75",
		"includingLmi": "75",
		"X100": false,
		"X251": "75",
		"X252": "75",
		"X104": "WITHOUT LMI",
		"X106": "INV FAIL LUXURY"
		}, {
		"X089": ["RSTD","RSTA","RLUO"],
		"X215": ["9999"],
		"loDoc": false,
		"withoutLmi": "75",
		"excludingLmi": "75",
		"includingLmi": "75",
		"X100": false,
		"X251": "75",
		"X252": "75",
		"X104": "WITHOUT LMI",
		"X106": "OO FAIL LUXURY"
		}, {
		"X089": ["RSTD"],
		"X215": ["2024", "2025", "2026", "2063", "2090", "2095", "2110", "3186"],
		"X091": "6000000",
		"X065": ["N/A"],
		"X098": false,
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X215": ["2024", "2025", "2026", "2063", "2090", "2095", "2110", "3186"],
		"X091": "6000000",
		"X098": false,
		"loDoc": false,
		"repaymentTypes": ["Line of Credit"],
		"repaymentType": "Line of Credit",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X215": ["2024", "2025", "2026", "2063", "2090", "2095", "2110", "3186"],
		"X091": "6000000",
		"X098": false,
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"repaymentTypes": ["Interest Only", "Interest In Advance"],
		"repaymentType": "Interest Only",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X215": ["2024", "2025", "2026", "2063", "2090", "2095", "2110", "3186"],
		"X091": "6000000",
		"X065": ["On Application"],
		"X098": false,
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X215": ["2024", "2025", "2026", "2063", "2090", "2095", "2110", "3186"],
		"X091": "6000000",
		"X065": ["On Application"],
		"X098": false,
		"loDoc": false,
		"predominantPurpose": ["Refinance Non-ANZ investment loan", "Refinance Non-ANZ Loan"],
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X215": ["2024", "2025", "2026", "2063", "2090", "2095", "2110", "3186"],
		"X091": "6000000",
		"X098": false,
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": true,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X215": ["2023", "2027", "2028", "2029", "2030", "2088", "2108", "3142"],
		"X091": "8000000",
		"X065": ["N/A"],
		"X098": false,
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X215": ["2023", "2027", "2028", "2029", "2030", "2088", "2108", "3142"],
		"X091": "8000000",
		"X098": false,
		"loDoc": false,
		"repaymentTypes": ["Line of Credit"],
		"repaymentType": "Line of Credit",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X215": ["2023", "2027", "2028", "2029", "2030", "2088", "2108", "3142"],
		"X091": "8000000",
		"X098": false,
		"loDoc": false,
		"predominantPurposeInvestment": false,
		"repaymentTypes": ["Interest Only", "Interest In Advance"],
		"repaymentType": "Interest Only",
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X215": ["2023", "2027", "2028", "2029", "2030", "2088", "2108", "3142"],
		"X091": "8000000",
		"X065": ["On Application"],
		"X098": false,
		"loDoc": false,
		"predominantPurposeInvestment": true,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X215": ["2023", "2027", "2028", "2029", "2030", "2088", "2108", "3142"],
		"X091": "8000000",
		"X065": ["On Application"],
		"X098": false,
		"loDoc": false,
		"predominantPurpose": ["Refinance Non-ANZ investment loan", "Refinance Non-ANZ Loan"],
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": false,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD"],
		"X215": ["2023", "2027", "2028", "2029", "2030", "2088", "2108", "3142"],
		"X091": "8000000",
		"X098": false,
		"loDoc": false,
		"withoutLmi": "80",
		"excludingLmi": "80",
		"includingLmi": "80",
		"X100": true,
		"X251": "80",
		"X252": "80"
		}, {
		"X089": ["RSTD","RSTA","RLUO"],
		"loDoc": false,
		"withoutLmi": "75",
		"excludingLmi": "75",
		"includingLmi": "75",
		"X100": false,
		"X251": "75",
		"X252": "75"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"loDoc": false,
		"withoutLmi": "75",
		"excludingLmi": "75",
		"includingLmi": "75",
		"X100": false,
		"X251": "75",
		"X252": "75"
		}, {
		"X089": ["LHOR"],
		"loDoc": false,
		"withoutLmi": "50",
		"excludingLmi": "50",
		"includingLmi": "50",
		"X100": false,
		"X251": "50",
		"X252": "50"
		}, {
		"X089": ["RSBR"],
		"loDoc": false,
		"withoutLmi": "60",
		"excludingLmi": "60",
		"includingLmi": "60",
		"X100": false,
		"X251": "60",
		"X252": "60"
		}, {
		"X089": ["RRUL"],
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "70",
		"includingLmi": "70",
		"X100": false,
		"X251": "70",
		"X252": "70"
		}, {
		"X089": ["RRU2"],
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "70",
		"includingLmi": "70",
		"X100": false,
		"X251": "70",
		"X252": "70"
		}, {
		"X089": ["RRU3"],
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "70",
		"includingLmi": "70",
		"X100": false,
		"X251": "70",
		"X252": "70"
		}, {
		"X089": ["RMDS"],
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "70",
		"includingLmi": "70",
		"X100": false,
		"X251": "70",
		"X252": "70"
		}, {
		"X089": ["RCOT"],
		"loDoc": false,
		"withoutLmi": "70",
		"excludingLmi": "70",
		"includingLmi": "70",
		"X100": false,
		"X251": "70",
		"X252": "70"
		}, {
		"X089": ["RSTD","RSTA"],
		"loDoc": true,
		"withoutLmi": "60",
		"excludingLmi": "60",
		"includingLmi": "60",
		"X100": false,
		"X251": "60",
		"X252": "60"
		}, {
		"X089": ["LHOR"],
		"state": ["ACT"],
		"loDoc": true,
		"withoutLmi": "60",
		"excludingLmi": "60",
		"includingLmi": "60",
		"X100": false,
		"X251": "60",
		"X252": "60"
		}, {
		"X089": ["LHOR", "RLUO", "RCOT", "RMDS"],
		"loDoc": true,
		"withoutLmi": "0",
		"excludingLmi": "0",
		"includingLmi": "0",
		"X100": false,
		"X251": "0",
		"X252": "0"
		}, {
		"X089": ["RSTD","RSTA", "LHOR", "RLUO", "RCOT", "RMDS","RSBR","RRUL","RRU2","RRU3","RMD2","COMM"],
		"withoutLmi": "0",
		"excludingLmi": "0",
		"includingLmi": "0",
		"X100": false,
		"X251": "0",
		"X252": "0"
		}],
	"X282": [{
		"X283": ["RSTD", "RSTA", "RRUL", "RRU2", "RCOT"],
		"X285": ["Category 1"],
		"X287": "2500000",
		"X288": "1"
		}, {
		"X283": ["RSTD", "RSTA", "RCOT"],
		"X285": ["Category 2"],
		"X287": "2000000",
		"X288": "2"
		}, {
		"X283": ["RRUL", "RRU2"],
		"X285": ["Category 2"],
		"X287": "1500000",
		"X288": "3"
		}, {
		"X283": ["RSTD", "RSTA", "RCOT"],
		"X284": "1052632",
		"X285": ["Category 3"],
		"X286": "0.95",
		"X288": "4"
		}, {
		"X283": ["RSTD", "RSTA", "RCOT"],
		"X284": "1111112",
		"X285": ["Category 3"],
		"X287": "1000000",
		"X288": "5"
		}, {
		"X283": ["RSTD", "RSTA", "RCOT"],
		"X284": "1666667",
		"X285": ["Category 3"],
		"X286": "0.9",
		"X288": "6"
		}, {
		"X283": ["RSTD", "RSTA", "RCOT"],
		"X284": "1875000",
		"X285": ["Category 3"],
		"X287": "1500000",
		"X288": "7"
		}, {
		"X283": ["RLUO"],
		"X284": "833334",
		"X285": ["Category 1"],
		"X286": "0.9",
		"X288": "8"
		}, {
		"X283": ["RLUO"],
		"X284": "882353",
		"X285": ["Category 1"],
		"X287": "750000",
		"X288": "9"
		}, {
		"X283": ["RLUO"],
		"X284": "1176471",
		"X285": ["Category 1"],
		"X286": "0.85",
		"X288": "10"
		}, {
		"X283": ["RLUO"],
		"X284": "1250000",
		"X285": ["Category 1"],
		"X287": "1000000",
		"X288": "11"
		}, {
		"X283": ["RSTD", "RSTA", "RCOT"],
		"X284": "526316",
		"X285": ["On Application"],
		"X286": "0.95",
		"X288": "12"
		}, {
		"X283": ["RSTD", "RSTA", "RCOT"],
		"X284": "588236",
		"X285": ["On Application"],
		"X287": "500000",
		"X288": "13"
		}, {
		"X283": ["RSTD", "RSTA", "RCOT"],
		"X284": "882353",
		"X285": ["On Application"],
		"X286": "0.85",
		"X288": "14"
		}, {
		"X283": ["RSTD", "RSTA", "RCOT"],
		"X284": "937500",
		"X285": ["On Application"],
		"X287": "750000",
		"X288": "15"
		}, {
		"X286": "0.8",
		"X287": "0",
		"X288": "16"
		}],
	"X087": [{
		"X088": ["House", "Townhouse"],
		"X089": "RSTD"
		}, {
		"X088": ["Rural House"],
		"X093": true,
		"X089": "RSTD"
		}, {
		"X088": ["Rural House"],
		"X093": false,
		"X089": "RRUL"
		}, {
		"X088": ["Apartment or Unit"],
		"X092": [">50"],
		"X089": "RSTA"
		}, {
		"X088": ["Apartment or Unit"],
		"X092": [">40<50"],
		"X089": "RLUO"
		}, {
		"X088": ["Apartment or Unit"],
		"X092": ["<40"],
		"X089": "RSBR"
		}, {
		"X088": ["Apartment or Unit"],
		"X089": "RSTA"
		}],
	"X056": [{
		"X086": "Standard Residential",
		"X089": "RSTD",
		"X098": true,
		"X114": "0.75",
		"X115": true,
		"X116": "Residential Standard",
		"X158": "Freehold Residential",
		"X159": "Residential"
		}, {
		"X086": "Standard Residential Apartment",
		"X089": "RSTA",
		"X098": false,
		"X114": "0.75",
		"X115": true,
		"X116": "Residential Standard",
		"X158": "Freehold Residential",
		"X159": "Residential"
		}, {
		"X086": "Small Residential Property (=>40m2 & <50m2)",
		"X089": "RLUO",
		"X098": false,
		"X114": "0.75",
		"X115": true,
		"X116": "Residential Single Bedroom <50m2",
		"X158": "Freehold Residential",
		"X159": "Residential"
		}, {
		"X086": "Small residential property (< 40m2)",
		"X089": "RSBR",
		"X098": false,
		"X114": "0.75",
		"X115": true,
		"X116": "Residential Single Bedroom <50m2",
		"X158": "Freehold Residential",
		"X159": "Residential"
		}, {
		"X086": "Leasehold",
		"X089": "LHOR",
		"X098": true,
		"X114": "0.75",
		"X115": true,
		"X116": "Leasehold Property - Residential",
		"X158": "Leasehold Residential",
		"X159": "Residential"
		}, {
		"X086": "Rural Resi Housing 10-50 hectares",
		"X089": "RRUL",
		"X098": false,
		"X114": "0.75",
		"X115": true,
		"X116": "Rural Residential",
		"X158": "Freehold Residential",
		"X159": "Rural Residential"
		}, {
		"X086": "Rural Resi Serviced Land 2-10 hectares",
		"X089": "RRU2",
		"X098": true,
		"X114": "0.75",
		"X115": true,
		"X116": "Rural Residential",
		"X158": "Freehold Residential",
		"X159": "Rural Residential"
		}, {
		"X086": "Rural Resi Land - Not Serviced",
		"X089": "RRU3",
		"X098": false,
		"X114": "0.75",
		"X115": true,
		"X116": "Residential Vacant Ld-Not Fully Serviced",
		"X158": "Freehold Residential",
		"X159": "Rural Residential"
		}, {
		"X086": "Company Title Units",
		"X089": "RCOT",
		"X098": false,
		"X114": "0.75",
		"X115": true,
		"X116": "Residential Standard",
		"X158": "Unit Title",
		"X159": "Residential"
		}, {
		"X086": "Duplex",
		"X089": "RSTD",
		"X098": false,
		"X114": "0.75",
		"X115": true,
		"X116": "Residential Multi Dwell/ 1 Title",
		"X158": "Freehold Residential",
		"X159": "Residential"
		}, {
		"X086": "Multi Dwelling",
		"X089": "RMDS",
		"X098": false,
		"X114": "0.75",
		"X115": true,
		"X116": "Residential Multi Dwell/ 1 Title",
		"X158": "Freehold Residential",
		"X159": "Residential"
		}, {
		"X086": "Commercial Property",
		"X089": "COMM",
		"X098": false,
		"X114": "0.6",
		"X115": false
		}],
	"X222": "552",
	"X042": {
		"includeThreshold": false,
			"entries": [{
			"incomeThreshold": "0",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2603"
				}, {
				"dependents": "1",
				"value": "3059"
				}, {
				"dependents": "2",
				"value": "3345"
				}, {
				"dependents": "3",
				"value": "3735"
				}, {
				"dependents": "4",
				"value": "4125"
				}, {
				"dependents": "5",
				"value": "4515"
				}, {
				"dependents": "6",
				"value": "4905"
				}, {
				"dependents": "7",
				"value": "5296"
				}, {
				"dependents": "8",
				"value": "5686"
				}, {
				"dependents": "9",
				"value": "6160"
				}, {
				"dependents": "10",
				"value": "6707"
				}]
			}, {
			"incomeThreshold": "24753",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2603"
				}, {
				"dependents": "1",
				"value": "3059"
				}, {
				"dependents": "2",
				"value": "3345"
				}, {
				"dependents": "3",
				"value": "3735"
				}, {
				"dependents": "4",
				"value": "4125"
				}, {
				"dependents": "5",
				"value": "4515"
				}, {
				"dependents": "6",
				"value": "4905"
				}, {
				"dependents": "7",
				"value": "5296"
				}, {
				"dependents": "8",
				"value": "5686"
				}, {
				"dependents": "9",
				"value": "6160"
				}, {
				"dependents": "10",
				"value": "6707"
				}]
			}, {
			"incomeThreshold": "34893",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2667"
				}, {
				"dependents": "1",
				"value": "3059"
				}, {
				"dependents": "2",
				"value": "3345"
				}, {
				"dependents": "3",
				"value": "3735"
				}, {
				"dependents": "4",
				"value": "4125"
				}, {
				"dependents": "5",
				"value": "4515"
				}, {
				"dependents": "6",
				"value": "4905"
				}, {
				"dependents": "7",
				"value": "5296"
				}, {
				"dependents": "8",
				"value": "5686"
				}, {
				"dependents": "9",
				"value": "6076"
				}, {
				"dependents": "10",
				"value": "6466"
				}]
			}, {
			"incomeThreshold": "44573",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2775"
				}, {
				"dependents": "1",
				"value": "3168"
				}, {
				"dependents": "2",
				"value": "3453"
				}, {
				"dependents": "3",
				"value": "3735"
				}, {
				"dependents": "4",
				"value": "4017"
				}, {
				"dependents": "5",
				"value": "4300"
				}, {
				"dependents": "6",
				"value": "4582"
				}, {
				"dependents": "7",
				"value": "4918"
				}, {
				"dependents": "8",
				"value": "5401"
				}, {
				"dependents": "9",
				"value": "5885"
				}, {
				"dependents": "10",
				"value": "6368"
				}]
			}, {
			"incomeThreshold": "54093",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2952"
				}, {
				"dependents": "1",
				"value": "3345"
				}, {
				"dependents": "2",
				"value": "3629"
				}, {
				"dependents": "3",
				"value": "3911"
				}, {
				"dependents": "4",
				"value": "4194"
				}, {
				"dependents": "5",
				"value": "4476"
				}, {
				"dependents": "6",
				"value": "4758"
				}, {
				"dependents": "7",
				"value": "5093"
				}, {
				"dependents": "8",
				"value": "5576"
				}, {
				"dependents": "9",
				"value": "6059"
				}, {
				"dependents": "10",
				"value": "6542"
				}]
			}, {
			"incomeThreshold": "62933",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3226"
				}, {
				"dependents": "1",
				"value": "3620"
				}, {
				"dependents": "2",
				"value": "3902"
				}, {
				"dependents": "3",
				"value": "4184"
				}, {
				"dependents": "4",
				"value": "4467"
				}, {
				"dependents": "5",
				"value": "4749"
				}, {
				"dependents": "6",
				"value": "5031"
				}, {
				"dependents": "7",
				"value": "5363"
				}, {
				"dependents": "8",
				"value": "5845"
				}, {
				"dependents": "9",
				"value": "6328"
				}, {
				"dependents": "10",
				"value": "6810"
				}]
			}, {
			"incomeThreshold": "80613",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3605"
				}, {
				"dependents": "1",
				"value": "4001"
				}, {
				"dependents": "2",
				"value": "4281"
				}, {
				"dependents": "3",
				"value": "4563"
				}, {
				"dependents": "4",
				"value": "4845"
				}, {
				"dependents": "5",
				"value": "5127"
				}, {
				"dependents": "6",
				"value": "5409"
				}, {
				"dependents": "7",
				"value": "5737"
				}, {
				"dependents": "8",
				"value": "6219"
				}, {
				"dependents": "9",
				"value": "6701"
				}, {
				"dependents": "10",
				"value": "7183"
				}]
			}, {
			"incomeThreshold": "98293",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3927"
				}, {
				"dependents": "1",
				"value": "4324"
				}, {
				"dependents": "2",
				"value": "4602"
				}, {
				"dependents": "3",
				"value": "4884"
				}, {
				"dependents": "4",
				"value": "5166"
				}, {
				"dependents": "5",
				"value": "5448"
				}, {
				"dependents": "6",
				"value": "5729"
				}, {
				"dependents": "7",
				"value": "6054"
				}, {
				"dependents": "8",
				"value": "6536"
				}, {
				"dependents": "9",
				"value": "7018"
				}, {
				"dependents": "10",
				"value": "7499"
				}]
			}, {
			"incomeThreshold": "114433",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4285"
				}, {
				"dependents": "1",
				"value": "4684"
				}, {
				"dependents": "2",
				"value": "4959"
				}, {
				"dependents": "3",
				"value": "5241"
				}, {
				"dependents": "4",
				"value": "5522"
				}, {
				"dependents": "5",
				"value": "5804"
				}, {
				"dependents": "6",
				"value": "6086"
				}, {
				"dependents": "7",
				"value": "6408"
				}, {
				"dependents": "8",
				"value": "6889"
				}, {
				"dependents": "9",
				"value": "7370"
				}, {
				"dependents": "10",
				"value": "7851"
				}]
			}, {
			"incomeThreshold": "130903",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4495"
				}, {
				"dependents": "1",
				"value": "4895"
				}, {
				"dependents": "2",
				"value": "5169"
				}, {
				"dependents": "3",
				"value": "5451"
				}, {
				"dependents": "4",
				"value": "5732"
				}, {
				"dependents": "5",
				"value": "6014"
				}, {
				"dependents": "6",
				"value": "6296"
				}, {
				"dependents": "7",
				"value": "6615"
				}, {
				"dependents": "8",
				"value": "7096"
				}, {
				"dependents": "9",
				"value": "7577"
				}, {
				"dependents": "10",
				"value": "8057"
				}]
			}, {
			"incomeThreshold": "145163",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4782"
				}, {
				"dependents": "1",
				"value": "5183"
				}, {
				"dependents": "2",
				"value": "5455"
				}, {
				"dependents": "3",
				"value": "5737"
				}, {
				"dependents": "4",
				"value": "6018"
				}, {
				"dependents": "5",
				"value": "6300"
				}, {
				"dependents": "6",
				"value": "6582"
				}, {
				"dependents": "7",
				"value": "6898"
				}, {
				"dependents": "8",
				"value": "7379"
				}, {
				"dependents": "9",
				"value": "7859"
				}, {
				"dependents": "10",
				"value": "8339"
				}]
			}, {
			"incomeThreshold": "172723",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "5289"
				}, {
				"dependents": "1",
				"value": "5692"
				}, {
				"dependents": "2",
				"value": "5961"
				}, {
				"dependents": "3",
				"value": "6242"
				}, {
				"dependents": "4",
				"value": "6524"
				}, {
				"dependents": "5",
				"value": "6805"
				}, {
				"dependents": "6",
				"value": "7086"
				}, {
				"dependents": "7",
				"value": "7398"
				}, {
				"dependents": "8",
				"value": "7878"
				}, {
				"dependents": "9",
				"value": "8357"
				}, {
				"dependents": "10",
				"value": "8837"
				}]
			}, {
			"incomeThreshold": "207703",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "6038"
				}, {
				"dependents": "1",
				"value": "6445"
				}, {
				"dependents": "2",
				"value": "6708"
				}, {
				"dependents": "3",
				"value": "6989"
				}, {
				"dependents": "4",
				"value": "7271"
				}, {
				"dependents": "5",
				"value": "7552"
				}, {
				"dependents": "6",
				"value": "7833"
				}, {
				"dependents": "7",
				"value": "8137"
				}, {
				"dependents": "8",
				"value": "8616"
				}, {
				"dependents": "9",
				"value": "9095"
				}, {
				"dependents": "10",
				"value": "9573"
				}]
			}, {
			"incomeThreshold": "242683",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "6103"
				}, {
				"dependents": "1",
				"value": "6509"
				}, {
				"dependents": "2",
				"value": "6773"
				}, {
				"dependents": "3",
				"value": "7054"
				}, {
				"dependents": "4",
				"value": "7335"
				}, {
				"dependents": "5",
				"value": "7616"
				}, {
				"dependents": "6",
				"value": "7897"
				}, {
				"dependents": "7",
				"value": "8201"
				}, {
				"dependents": "8",
				"value": "8679"
				}, {
				"dependents": "9",
				"value": "9158"
				}, {
				"dependents": "10",
				"value": "9636"
				}]
			}]
	},
	"X043": {
		"includeThreshold": false,
			"entries": [{
			"incomeThreshold": "0",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "1352"
				}, {
				"dependents": "1",
				"value": "1848"
				}, {
				"dependents": "2",
				"value": "2331"
				}, {
				"dependents": "3",
				"value": "2878"
				}, {
				"dependents": "4",
				"value": "3425"
				}, {
				"dependents": "5",
				"value": "3972"
				}, {
				"dependents": "6",
				"value": "4519"
				}, {
				"dependents": "7",
				"value": "5066"
				}, {
				"dependents": "8",
				"value": "5613"
				}, {
				"dependents": "9",
				"value": "6160"
				}, {
				"dependents": "10",
				"value": "6707"
				}]
			}, {
			"incomeThreshold": "24753",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "1419"
				}, {
				"dependents": "1",
				"value": "1848"
				}, {
				"dependents": "2",
				"value": "2331"
				}, {
				"dependents": "3",
				"value": "2878"
				}, {
				"dependents": "4",
				"value": "3425"
				}, {
				"dependents": "5",
				"value": "3972"
				}, {
				"dependents": "6",
				"value": "4519"
				}, {
				"dependents": "7",
				"value": "5066"
				}, {
				"dependents": "8",
				"value": "5613"
				}, {
				"dependents": "9",
				"value": "6160"
				}, {
				"dependents": "10",
				"value": "6707"
				}]
			}, {
			"incomeThreshold": "34893",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "1483"
				}, {
				"dependents": "1",
				"value": "1911"
				}, {
				"dependents": "2",
				"value": "2395"
				}, {
				"dependents": "3",
				"value": "2878"
				}, {
				"dependents": "4",
				"value": "3361"
				}, {
				"dependents": "5",
				"value": "3845"
				}, {
				"dependents": "6",
				"value": "4328"
				}, {
				"dependents": "7",
				"value": "4812"
				}, {
				"dependents": "8",
				"value": "5295"
				}, {
				"dependents": "9",
				"value": "5778"
				}, {
				"dependents": "10",
				"value": "6262"
				}]
			}, {
			"incomeThreshold": "44573",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "1591"
				}, {
				"dependents": "1",
				"value": "2019"
				}, {
				"dependents": "2",
				"value": "2502"
				}, {
				"dependents": "3",
				"value": "2985"
				}, {
				"dependents": "4",
				"value": "3469"
				}, {
				"dependents": "5",
				"value": "3952"
				}, {
				"dependents": "6",
				"value": "4435"
				}, {
				"dependents": "7",
				"value": "4918"
				}, {
				"dependents": "8",
				"value": "5401"
				}, {
				"dependents": "9",
				"value": "5885"
				}, {
				"dependents": "10",
				"value": "6368"
				}]
			}, {
			"incomeThreshold": "54093",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "1768"
				}, {
				"dependents": "1",
				"value": "2195"
				}, {
				"dependents": "2",
				"value": "2678"
				}, {
				"dependents": "3",
				"value": "3161"
				}, {
				"dependents": "4",
				"value": "3644"
				}, {
				"dependents": "5",
				"value": "4127"
				}, {
				"dependents": "6",
				"value": "4610"
				}, {
				"dependents": "7",
				"value": "5093"
				}, {
				"dependents": "8",
				"value": "5576"
				}, {
				"dependents": "9",
				"value": "6059"
				}, {
				"dependents": "10",
				"value": "6542"
				}]
			}, {
			"incomeThreshold": "62933",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2043"
				}, {
				"dependents": "1",
				"value": "2467"
				}, {
				"dependents": "2",
				"value": "2950"
				}, {
				"dependents": "3",
				"value": "3432"
				}, {
				"dependents": "4",
				"value": "3915"
				}, {
				"dependents": "5",
				"value": "4398"
				}, {
				"dependents": "6",
				"value": "4880"
				}, {
				"dependents": "7",
				"value": "5363"
				}, {
				"dependents": "8",
				"value": "5845"
				}, {
				"dependents": "9",
				"value": "6328"
				}, {
				"dependents": "10",
				"value": "6810"
				}]
			}, {
			"incomeThreshold": "80613",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2423"
				}, {
				"dependents": "1",
				"value": "2845"
				}, {
				"dependents": "2",
				"value": "3327"
				}, {
				"dependents": "3",
				"value": "3809"
				}, {
				"dependents": "4",
				"value": "4291"
				}, {
				"dependents": "5",
				"value": "4773"
				}, {
				"dependents": "6",
				"value": "5255"
				}, {
				"dependents": "7",
				"value": "5737"
				}, {
				"dependents": "8",
				"value": "6219"
				}, {
				"dependents": "9",
				"value": "6701"
				}, {
				"dependents": "10",
				"value": "7183"
				}]
			}, {
			"incomeThreshold": "98293",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2745"
				}, {
				"dependents": "1",
				"value": "3165"
				}, {
				"dependents": "2",
				"value": "3647"
				}, {
				"dependents": "3",
				"value": "4128"
				}, {
				"dependents": "4",
				"value": "4610"
				}, {
				"dependents": "5",
				"value": "5091"
				}, {
				"dependents": "6",
				"value": "5573"
				}, {
				"dependents": "7",
				"value": "6054"
				}, {
				"dependents": "8",
				"value": "6536"
				}, {
				"dependents": "9",
				"value": "7018"
				}, {
				"dependents": "10",
				"value": "7499"
				}]
			}, {
			"incomeThreshold": "114433",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3104"
				}, {
				"dependents": "1",
				"value": "3521"
				}, {
				"dependents": "2",
				"value": "4002"
				}, {
				"dependents": "3",
				"value": "4483"
				}, {
				"dependents": "4",
				"value": "4964"
				}, {
				"dependents": "5",
				"value": "5445"
				}, {
				"dependents": "6",
				"value": "5927"
				}, {
				"dependents": "7",
				"value": "6408"
				}, {
				"dependents": "8",
				"value": "6889"
				}, {
				"dependents": "9",
				"value": "7370"
				}, {
				"dependents": "10",
				"value": "7851"
				}]
			}, {
			"incomeThreshold": "130903",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3314"
				}, {
				"dependents": "1",
				"value": "3731"
				}, {
				"dependents": "2",
				"value": "4211"
				}, {
				"dependents": "3",
				"value": "4692"
				}, {
				"dependents": "4",
				"value": "5173"
				}, {
				"dependents": "5",
				"value": "5654"
				}, {
				"dependents": "6",
				"value": "6134"
				}, {
				"dependents": "7",
				"value": "6615"
				}, {
				"dependents": "8",
				"value": "7096"
				}, {
				"dependents": "9",
				"value": "7577"
				}, {
				"dependents": "10",
				"value": "8057"
				}]
			}, {
			"incomeThreshold": "145163",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3602"
				}, {
				"dependents": "1",
				"value": "4016"
				}, {
				"dependents": "2",
				"value": "4497"
				}, {
				"dependents": "3",
				"value": "4977"
				}, {
				"dependents": "4",
				"value": "5457"
				}, {
				"dependents": "5",
				"value": "5938"
				}, {
				"dependents": "6",
				"value": "6418"
				}, {
				"dependents": "7",
				"value": "6898"
				}, {
				"dependents": "8",
				"value": "7379"
				}, {
				"dependents": "9",
				"value": "7859"
				}, {
				"dependents": "10",
				"value": "8339"
				}]
			}, {
			"incomeThreshold": "172723",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4109"
				}, {
				"dependents": "1",
				"value": "4520"
				}, {
				"dependents": "2",
				"value": "5000"
				}, {
				"dependents": "3",
				"value": "5480"
				}, {
				"dependents": "4",
				"value": "5959"
				}, {
				"dependents": "5",
				"value": "6439"
				}, {
				"dependents": "6",
				"value": "6919"
				}, {
				"dependents": "7",
				"value": "7398"
				}, {
				"dependents": "8",
				"value": "7878"
				}, {
				"dependents": "9",
				"value": "8357"
				}, {
				"dependents": "10",
				"value": "8837"
				}]
			}, {
			"incomeThreshold": "207703",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4860"
				}, {
				"dependents": "1",
				"value": "5266"
				}, {
				"dependents": "2",
				"value": "5745"
				}, {
				"dependents": "3",
				"value": "6223"
				}, {
				"dependents": "4",
				"value": "6702"
				}, {
				"dependents": "5",
				"value": "7180"
				}, {
				"dependents": "6",
				"value": "7659"
				}, {
				"dependents": "7",
				"value": "8137"
				}, {
				"dependents": "8",
				"value": "8616"
				}, {
				"dependents": "9",
				"value": "9095"
				}, {
				"dependents": "10",
				"value": "9573"
				}]
			}, {
			"incomeThreshold": "242683",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4925"
				}, {
				"dependents": "1",
				"value": "5330"
				}, {
				"dependents": "2",
				"value": "5809"
				}, {
				"dependents": "3",
				"value": "6287"
				}, {
				"dependents": "4",
				"value": "6766"
				}, {
				"dependents": "5",
				"value": "7244"
				}, {
				"dependents": "6",
				"value": "7723"
				}, {
				"dependents": "7",
				"value": "8201"
				}, {
				"dependents": "8",
				"value": "8679"
				}, {
				"dependents": "9",
				"value": "9158"
				}, {
				"dependents": "10",
				"value": "9636"
				}]
			}]
	},
	"X192": {
		"includeThreshold": false,
			"entries": [{
			"incomeThreshold": "0",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2603"
				}, {
				"dependents": "1",
				"value": "3059"
				}, {
				"dependents": "2",
				"value": "3345"
				}, {
				"dependents": "3",
				"value": "3735"
				}, {
				"dependents": "4",
				"value": "4125"
				}, {
				"dependents": "5",
				"value": "4515"
				}, {
				"dependents": "6",
				"value": "4905"
				}, {
				"dependents": "7",
				"value": "5296"
				}, {
				"dependents": "8",
				"value": "5686"
				}, {
				"dependents": "9",
				"value": "6160"
				}, {
				"dependents": "10",
				"value": "6707"
				}]
			}, {
			"incomeThreshold": "26001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2603"
				}, {
				"dependents": "1",
				"value": "3059"
				}, {
				"dependents": "2",
				"value": "3345"
				}, {
				"dependents": "3",
				"value": "3735"
				}, {
				"dependents": "4",
				"value": "4125"
				}, {
				"dependents": "5",
				"value": "4515"
				}, {
				"dependents": "6",
				"value": "4905"
				}, {
				"dependents": "7",
				"value": "5296"
				}, {
				"dependents": "8",
				"value": "5686"
				}, {
				"dependents": "9",
				"value": "6160"
				}, {
				"dependents": "10",
				"value": "6707"
				}]
			}, {
			"incomeThreshold": "39001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2667"
				}, {
				"dependents": "1",
				"value": "3059"
				}, {
				"dependents": "2",
				"value": "3345"
				}, {
				"dependents": "3",
				"value": "3735"
				}, {
				"dependents": "4",
				"value": "4125"
				}, {
				"dependents": "5",
				"value": "4515"
				}, {
				"dependents": "6",
				"value": "4905"
				}, {
				"dependents": "7",
				"value": "5296"
				}, {
				"dependents": "8",
				"value": "5686"
				}, {
				"dependents": "9",
				"value": "6076"
				}, {
				"dependents": "10",
				"value": "6466"
				}]
			}, {
			"incomeThreshold": "52001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2775"
				}, {
				"dependents": "1",
				"value": "3168"
				}, {
				"dependents": "2",
				"value": "3453"
				}, {
				"dependents": "3",
				"value": "3735"
				}, {
				"dependents": "4",
				"value": "4017"
				}, {
				"dependents": "5",
				"value": "4300"
				}, {
				"dependents": "6",
				"value": "4582"
				}, {
				"dependents": "7",
				"value": "4918"
				}, {
				"dependents": "8",
				"value": "5401"
				}, {
				"dependents": "9",
				"value": "5885"
				}, {
				"dependents": "10",
				"value": "6368"
				}]
			}, {
			"incomeThreshold": "66001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2952"
				}, {
				"dependents": "1",
				"value": "3345"
				}, {
				"dependents": "2",
				"value": "3629"
				}, {
				"dependents": "3",
				"value": "3911"
				}, {
				"dependents": "4",
				"value": "4194"
				}, {
				"dependents": "5",
				"value": "4476"
				}, {
				"dependents": "6",
				"value": "4758"
				}, {
				"dependents": "7",
				"value": "5093"
				}, {
				"dependents": "8",
				"value": "5576"
				}, {
				"dependents": "9",
				"value": "6059"
				}, {
				"dependents": "10",
				"value": "6542"
				}]
			}, {
			"incomeThreshold": "79001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3226"
				}, {
				"dependents": "1",
				"value": "3620"
				}, {
				"dependents": "2",
				"value": "3902"
				}, {
				"dependents": "3",
				"value": "4184"
				}, {
				"dependents": "4",
				"value": "4467"
				}, {
				"dependents": "5",
				"value": "4749"
				}, {
				"dependents": "6",
				"value": "5031"
				}, {
				"dependents": "7",
				"value": "5363"
				}, {
				"dependents": "8",
				"value": "5845"
				}, {
				"dependents": "9",
				"value": "6328"
				}, {
				"dependents": "10",
				"value": "6810"
				}]
			}, {
			"incomeThreshold": "105001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3605"
				}, {
				"dependents": "1",
				"value": "4001"
				}, {
				"dependents": "2",
				"value": "4281"
				}, {
				"dependents": "3",
				"value": "4563"
				}, {
				"dependents": "4",
				"value": "4845"
				}, {
				"dependents": "5",
				"value": "5127"
				}, {
				"dependents": "6",
				"value": "5409"
				}, {
				"dependents": "7",
				"value": "5737"
				}, {
				"dependents": "8",
				"value": "6219"
				}, {
				"dependents": "9",
				"value": "6701"
				}, {
				"dependents": "10",
				"value": "7183"
				}]
			}, {
			"incomeThreshold": "131001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3927"
				}, {
				"dependents": "1",
				"value": "4324"
				}, {
				"dependents": "2",
				"value": "4602"
				}, {
				"dependents": "3",
				"value": "4884"
				}, {
				"dependents": "4",
				"value": "5166"
				}, {
				"dependents": "5",
				"value": "5448"
				}, {
				"dependents": "6",
				"value": "5729"
				}, {
				"dependents": "7",
				"value": "6054"
				}, {
				"dependents": "8",
				"value": "6536"
				}, {
				"dependents": "9",
				"value": "7018"
				}, {
				"dependents": "10",
				"value": "7499"
				}]
			}, {
			"incomeThreshold": "157001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4285"
				}, {
				"dependents": "1",
				"value": "4684"
				}, {
				"dependents": "2",
				"value": "4959"
				}, {
				"dependents": "3",
				"value": "5241"
				}, {
				"dependents": "4",
				"value": "5522"
				}, {
				"dependents": "5",
				"value": "5804"
				}, {
				"dependents": "6",
				"value": "6086"
				}, {
				"dependents": "7",
				"value": "6408"
				}, {
				"dependents": "8",
				"value": "6889"
				}, {
				"dependents": "9",
				"value": "7370"
				}, {
				"dependents": "10",
				"value": "7851"
				}]
			}, {
			"incomeThreshold": "184001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4495"
				}, {
				"dependents": "1",
				"value": "4895"
				}, {
				"dependents": "2",
				"value": "5169"
				}, {
				"dependents": "3",
				"value": "5451"
				}, {
				"dependents": "4",
				"value": "5732"
				}, {
				"dependents": "5",
				"value": "6014"
				}, {
				"dependents": "6",
				"value": "6296"
				}, {
				"dependents": "7",
				"value": "6615"
				}, {
				"dependents": "8",
				"value": "7096"
				}, {
				"dependents": "9",
				"value": "7577"
				}, {
				"dependents": "10",
				"value": "8057"
				}]
			}, {
			"incomeThreshold": "210001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4782"
				}, {
				"dependents": "1",
				"value": "5183"
				}, {
				"dependents": "2",
				"value": "5455"
				}, {
				"dependents": "3",
				"value": "5737"
				}, {
				"dependents": "4",
				"value": "6018"
				}, {
				"dependents": "5",
				"value": "6300"
				}, {
				"dependents": "6",
				"value": "6582"
				}, {
				"dependents": "7",
				"value": "6898"
				}, {
				"dependents": "8",
				"value": "7379"
				}, {
				"dependents": "9",
				"value": "7859"
				}, {
				"dependents": "10",
				"value": "8339"
				}]
			}, {
			"incomeThreshold": "262001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "5289"
				}, {
				"dependents": "1",
				"value": "5692"
				}, {
				"dependents": "2",
				"value": "5961"
				}, {
				"dependents": "3",
				"value": "6242"
				}, {
				"dependents": "4",
				"value": "6524"
				}, {
				"dependents": "5",
				"value": "6805"
				}, {
				"dependents": "6",
				"value": "7086"
				}, {
				"dependents": "7",
				"value": "7398"
				}, {
				"dependents": "8",
				"value": "7878"
				}, {
				"dependents": "9",
				"value": "8357"
				}, {
				"dependents": "10",
				"value": "8837"
				}]
			}, {
			"incomeThreshold": "328001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "6038"
				}, {
				"dependents": "1",
				"value": "6445"
				}, {
				"dependents": "2",
				"value": "6708"
				}, {
				"dependents": "3",
				"value": "6989"
				}, {
				"dependents": "4",
				"value": "7271"
				}, {
				"dependents": "5",
				"value": "7552"
				}, {
				"dependents": "6",
				"value": "7833"
				}, {
				"dependents": "7",
				"value": "8137"
				}, {
				"dependents": "8",
				"value": "8616"
				}, {
				"dependents": "9",
				"value": "9095"
				}, {
				"dependents": "10",
				"value": "9573"
				}]
			}, {
			"incomeThreshold": "394001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "6103"
				}, {
				"dependents": "1",
				"value": "6509"
				}, {
				"dependents": "2",
				"value": "6773"
				}, {
				"dependents": "3",
				"value": "7054"
				}, {
				"dependents": "4",
				"value": "7335"
				}, {
				"dependents": "5",
				"value": "7616"
				}, {
				"dependents": "6",
				"value": "7897"
				}, {
				"dependents": "7",
				"value": "8201"
				}, {
				"dependents": "8",
				"value": "8679"
				}, {
				"dependents": "9",
				"value": "9158"
				}, {
				"dependents": "10",
				"value": "9636"
				}]
			}]
	},
	"X193": {
		"includeThreshold": false,
			"entries": [{
			"incomeThreshold": "0",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "1352"
				}, {
				"dependents": "1",
				"value": "1848"
				}, {
				"dependents": "2",
				"value": "2331"
				}, {
				"dependents": "3",
				"value": "2878"
				}, {
				"dependents": "4",
				"value": "3425"
				}, {
				"dependents": "5",
				"value": "3972"
				}, {
				"dependents": "6",
				"value": "4519"
				}, {
				"dependents": "7",
				"value": "5066"
				}, {
				"dependents": "8",
				"value": "5613"
				}, {
				"dependents": "9",
				"value": "6160"
				}, {
				"dependents": "10",
				"value": "6707"
				}]
			}, {
			"incomeThreshold": "26001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "1419"
				}, {
				"dependents": "1",
				"value": "1848"
				}, {
				"dependents": "2",
				"value": "2331"
				}, {
				"dependents": "3",
				"value": "2878"
				}, {
				"dependents": "4",
				"value": "3425"
				}, {
				"dependents": "5",
				"value": "3972"
				}, {
				"dependents": "6",
				"value": "4519"
				}, {
				"dependents": "7",
				"value": "5066"
				}, {
				"dependents": "8",
				"value": "5613"
				}, {
				"dependents": "9",
				"value": "6160"
				}, {
				"dependents": "10",
				"value": "6707"
				}]
			}, {
			"incomeThreshold": "39001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "1483"
				}, {
				"dependents": "1",
				"value": "1911"
				}, {
				"dependents": "2",
				"value": "2395"
				}, {
				"dependents": "3",
				"value": "2878"
				}, {
				"dependents": "4",
				"value": "3361"
				}, {
				"dependents": "5",
				"value": "3845"
				}, {
				"dependents": "6",
				"value": "4328"
				}, {
				"dependents": "7",
				"value": "4812"
				}, {
				"dependents": "8",
				"value": "5295"
				}, {
				"dependents": "9",
				"value": "5778"
				}, {
				"dependents": "10",
				"value": "6262"
				}]
			}, {
			"incomeThreshold": "52001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "1591"
				}, {
				"dependents": "1",
				"value": "2019"
				}, {
				"dependents": "2",
				"value": "2502"
				}, {
				"dependents": "3",
				"value": "2985"
				}, {
				"dependents": "4",
				"value": "3469"
				}, {
				"dependents": "5",
				"value": "3952"
				}, {
				"dependents": "6",
				"value": "4435"
				}, {
				"dependents": "7",
				"value": "4918"
				}, {
				"dependents": "8",
				"value": "5401"
				}, {
				"dependents": "9",
				"value": "5885"
				}, {
				"dependents": "10",
				"value": "6368"
				}]
			}, {
			"incomeThreshold": "66001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "1768"
				}, {
				"dependents": "1",
				"value": "2195"
				}, {
				"dependents": "2",
				"value": "2678"
				}, {
				"dependents": "3",
				"value": "3161"
				}, {
				"dependents": "4",
				"value": "3644"
				}, {
				"dependents": "5",
				"value": "4127"
				}, {
				"dependents": "6",
				"value": "4610"
				}, {
				"dependents": "7",
				"value": "5093"
				}, {
				"dependents": "8",
				"value": "5576"
				}, {
				"dependents": "9",
				"value": "6059"
				}, {
				"dependents": "10",
				"value": "6542"
				}]
			}, {
			"incomeThreshold": "79001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2043"
				}, {
				"dependents": "1",
				"value": "2467"
				}, {
				"dependents": "2",
				"value": "2950"
				}, {
				"dependents": "3",
				"value": "3432"
				}, {
				"dependents": "4",
				"value": "3915"
				}, {
				"dependents": "5",
				"value": "4398"
				}, {
				"dependents": "6",
				"value": "4880"
				}, {
				"dependents": "7",
				"value": "5363"
				}, {
				"dependents": "8",
				"value": "5845"
				}, {
				"dependents": "9",
				"value": "6328"
				}, {
				"dependents": "10",
				"value": "6810"
				}]
			}, {
			"incomeThreshold": "105001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2423"
				}, {
				"dependents": "1",
				"value": "2845"
				}, {
				"dependents": "2",
				"value": "3327"
				}, {
				"dependents": "3",
				"value": "3809"
				}, {
				"dependents": "4",
				"value": "4291"
				}, {
				"dependents": "5",
				"value": "4773"
				}, {
				"dependents": "6",
				"value": "5255"
				}, {
				"dependents": "7",
				"value": "5737"
				}, {
				"dependents": "8",
				"value": "6219"
				}, {
				"dependents": "9",
				"value": "6701"
				}, {
				"dependents": "10",
				"value": "7183"
				}]
			}, {
			"incomeThreshold": "131001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "2745"
				}, {
				"dependents": "1",
				"value": "3165"
				}, {
				"dependents": "2",
				"value": "3647"
				}, {
				"dependents": "3",
				"value": "4128"
				}, {
				"dependents": "4",
				"value": "4610"
				}, {
				"dependents": "5",
				"value": "5091"
				}, {
				"dependents": "6",
				"value": "5573"
				}, {
				"dependents": "7",
				"value": "6054"
				}, {
				"dependents": "8",
				"value": "6536"
				}, {
				"dependents": "9",
				"value": "7018"
				}, {
				"dependents": "10",
				"value": "7499"
				}]
			}, {
			"incomeThreshold": "157001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3104"
				}, {
				"dependents": "1",
				"value": "3521"
				}, {
				"dependents": "2",
				"value": "4002"
				}, {
				"dependents": "3",
				"value": "4483"
				}, {
				"dependents": "4",
				"value": "4964"
				}, {
				"dependents": "5",
				"value": "5445"
				}, {
				"dependents": "6",
				"value": "5927"
				}, {
				"dependents": "7",
				"value": "6408"
				}, {
				"dependents": "8",
				"value": "6889"
				}, {
				"dependents": "9",
				"value": "7370"
				}, {
				"dependents": "10",
				"value": "7851"
				}]
			}, {
			"incomeThreshold": "184001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3314"
				}, {
				"dependents": "1",
				"value": "3731"
				}, {
				"dependents": "2",
				"value": "4211"
				}, {
				"dependents": "3",
				"value": "4692"
				}, {
				"dependents": "4",
				"value": "5173"
				}, {
				"dependents": "5",
				"value": "5654"
				}, {
				"dependents": "6",
				"value": "6134"
				}, {
				"dependents": "7",
				"value": "6615"
				}, {
				"dependents": "8",
				"value": "7096"
				}, {
				"dependents": "9",
				"value": "7577"
				}, {
				"dependents": "10",
				"value": "8057"
				}]
			}, {
			"incomeThreshold": "210001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "3602"
				}, {
				"dependents": "1",
				"value": "4016"
				}, {
				"dependents": "2",
				"value": "4497"
				}, {
				"dependents": "3",
				"value": "4977"
				}, {
				"dependents": "4",
				"value": "5457"
				}, {
				"dependents": "5",
				"value": "5938"
				}, {
				"dependents": "6",
				"value": "6418"
				}, {
				"dependents": "7",
				"value": "6898"
				}, {
				"dependents": "8",
				"value": "7379"
				}, {
				"dependents": "9",
				"value": "7859"
				}, {
				"dependents": "10",
				"value": "8339"
				}]
			}, {
			"incomeThreshold": "262001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4109"
				}, {
				"dependents": "1",
				"value": "4520"
				}, {
				"dependents": "2",
				"value": "5000"
				}, {
				"dependents": "3",
				"value": "5480"
				}, {
				"dependents": "4",
				"value": "5959"
				}, {
				"dependents": "5",
				"value": "6439"
				}, {
				"dependents": "6",
				"value": "6919"
				}, {
				"dependents": "7",
				"value": "7398"
				}, {
				"dependents": "8",
				"value": "7878"
				}, {
				"dependents": "9",
				"value": "8357"
				}, {
				"dependents": "10",
				"value": "8837"
				}]
			}, {
			"incomeThreshold": "328001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4860"
				}, {
				"dependents": "1",
				"value": "5266"
				}, {
				"dependents": "2",
				"value": "5745"
				}, {
				"dependents": "3",
				"value": "6223"
				}, {
				"dependents": "4",
				"value": "6702"
				}, {
				"dependents": "5",
				"value": "7180"
				}, {
				"dependents": "6",
				"value": "7659"
				}, {
				"dependents": "7",
				"value": "8137"
				}, {
				"dependents": "8",
				"value": "8616"
				}, {
				"dependents": "9",
				"value": "9095"
				}, {
				"dependents": "10",
				"value": "9573"
				}]
			}, {
			"incomeThreshold": "394001",
			"includeThreshold": false,
			"entries": [{
				"dependents": "0",
				"value": "4925"
				}, {
				"dependents": "1",
				"value": "5330"
				}, {
				"dependents": "2",
				"value": "5809"
				}, {
				"dependents": "3",
				"value": "6287"
				}, {
				"dependents": "4",
				"value": "6766"
				}, {
				"dependents": "5",
				"value": "7244"
				}, {
				"dependents": "6",
				"value": "7723"
				}, {
				"dependents": "7",
				"value": "8201"
				}, {
				"dependents": "8",
				"value": "8679"
				}, {
				"dependents": "9",
				"value": "9158"
				}, {
				"dependents": "10",
				"value": "9636"
				}]
			}]
	},
	"X101": [{
		"expenseId": "1",
		"expenseName": "Childcare/ Public Education",
		"expenseDescription": "Childcare including nannies. Public education fees and associated costs (preschool, primary, secondary) including books and uniforms"
		}, {
		"expenseId": "2",
		"expenseName": "Clothing and Personal Care",
		"expenseDescription": "Clothing, footwear, cosmetics, personal care"
		}, {
		"expenseId": "3",
		"expenseName": "Groceries",
		"expenseDescription": "Typical supermarket shop for groceries including food and toiletries"
		}, {
		"expenseId": "4",
		"expenseName": "Medical and Health",
		"expenseDescription": "Medical and health costs including doctor, dental, optical and pharmaceutical"
		}, {
		"expenseId": "5",
		"expenseName": "Home utilities, rates & costs",
		"expenseDescription": "Housing and property expenses on owner occupied property including rates, taxes, levies, body corporate and strata fees, repairs and maintenance, home and contents insurance, other household items and utilities"
		}, {
		"expenseId": "6",
		"expenseName": "Recreation and Entertainment",
		"expenseDescription": "Recreation and entertainment including alcohol, tobacco, gambling, restaurants, membership fees, pet care and holidays"
		}, {
		"expenseId": "7",
		"expenseName": "Phone, Internet & Pay TV",
		"expenseDescription": "Telephone accounts (home and mobile), internet, pay TV and media streaming subscriptions (such as Netflix and Spotify)"
		}, {
		"expenseId": "8",
		"expenseName": "Transport",
		"expenseDescription": "Public transport, motor vehicle running costs including fuel, motor vehicle insurance, servicing, parking and tolls"
		}],
	"X102": [{
		"expenseId": "0",
		"expenseName": "Rent/Board (if continuing)",
		"expenseDescription": "Rent or board expense if continuing at drawdown of loan"
		}, {
		"expenseId": "6",
		"expenseName": "Child Maintainence",
		"expenseDescription": "Child Maintenance/Child Support payments"
		}, {
		"expenseId": "4",
		"expenseName": "Health Insurance",
		"expenseDescription": "Health Insurance payments"
		}, {
		"expenseId": "5",
		"expenseName": "Life Insurance",
		"expenseDescription": "Life Insurance payments"
		}, {
		"expenseId": "1",
		"expenseName": "Other Insurance",
		"expenseDescription": "Other Insurance payments"
		}, {
		"expenseId": "7",
		"expenseName": "Private Education",
		"expenseDescription": "Private education fees and associated costs (preschool, primary, secondary and tertiary) including books and uniforms etc."
		}, {
		"expenseId": "2",
		"expenseName": "Other Expenses",
		"expenseDescription": "Unique items not covered in above categories (e.g Cleaner, Gardener, Gifts, Overseas Travel, Donations)"
		}],
	"X060": [{
		"housingSituationCustomer1": ["Rent"],
		"currentlyOO": false,
		"applicationHousingExpenseCategory": "Rent"
		}, {
		"housingSituationCustomer2": ["Rent"],
		"currentlyOO": false,
		"applicationHousingExpenseCategory": "Rent"
		}, {
		"housingSituationCustomer1": ["Board", "Living with parents", "Other"],
		"currentlyOO": false,
		"applicationHousingExpenseCategory": "Board"
		}, {
		"housingSituationCustomer2": ["Board", "Living with parents", "Other"],
		"currentlyOO": false,
		"applicationHousingExpenseCategory": "Board"
		}, {
		"housingSituationCustomer1": ["Own outright", "Own with lending", "Caravan"],
		"currentlyOO": true,
		"applicationHousingExpenseCategory": "Own"
		}, {
		"housingSituationCustomer2": ["Own outright", "Own with lending", "Caravan"],
		"currentlyOO": true,
		"applicationHousingExpenseCategory": "Own"
		}, {
		"financePropertyWithoutRent": true,
		"currentlyOO": true,
		"applicationHousingExpenseCategory": "Own"
		}, {
		"financePropertyWithoutRent": false,
		"currentlyOO": false,
		"applicationHousingExpenseCategory": "Rent"
		}],
	"X061": [{
		"predominantPurposeInvestment": true,
		"currentlyOO": false
		}, {
		"predominantPurposeInvestment": false,
		"currentlyOO": true
		}, {
		"currentlyOO": false
		}],
	"X062": [{
		"X060": true,
		"sensitiseHE": false
		}, {
		"X060": false,
		"X061": true,
		"sensitiseHE": false
		}, {
		"X060": false,
		"sensitiseHE": true
		}],
	"X063": [{
		"X073": "Metropolitan",
		"priority": "1"
		}, {
		"X073": "Non-Metro",
		"priority": "2"
		}],
	"X064": [{
		"sopType": ["Single"],
		"minDependants": "1",
		"housingExpensePostcodeCategory": ["Metropolitan"],
		"applicationHousingExpenseCategory": ["Rent"],
		"value": "590"
		}, {
		"sopType": ["Single"],
		"minDependants": "1",
		"housingExpensePostcodeCategory": ["Metropolitan"],
		"applicationHousingExpenseCategory": ["Board"],
		"value": "590"
		}, {
		"sopType": ["Single"],
		"minDependants": "1",
		"housingExpensePostcodeCategory": ["Non-Metro"],
		"applicationHousingExpenseCategory": ["Rent"],
		"value": "590"
		}, {
		"sopType": ["Single"],
		"minDependants": "1",
		"housingExpensePostcodeCategory": ["Non-Metro"],
		"applicationHousingExpenseCategory": ["Board"],
		"value": "590"
		}, {
		"sopType": ["Couple"],
		"minDependants": "1",
		"housingExpensePostcodeCategory": ["Metropolitan"],
		"applicationHousingExpenseCategory": ["Rent"],
		"value": "590"
		}, {
		"sopType": ["Couple"],
		"minDependants": "1",
		"housingExpensePostcodeCategory": ["Metropolitan"],
		"applicationHousingExpenseCategory": ["Board"],
		"value": "590"
		}, {
		"sopType": ["Couple"],
		"minDependants": "1",
		"housingExpensePostcodeCategory": ["Non-Metro"],
		"applicationHousingExpenseCategory": ["Rent"],
		"value": "590"
		}, {
		"sopType": ["Couple"],
		"minDependants": "1",
		"housingExpensePostcodeCategory": ["Non-Metro"],
		"applicationHousingExpenseCategory": ["Board"],
		"value": "590"
		}, {
		"sopType": ["Single"],
		"minDependants": "0",
		"housingExpensePostcodeCategory": ["Metropolitan"],
		"applicationHousingExpenseCategory": ["Rent"],
		"value": "590"
		}, {
		"sopType": ["Single"],
		"minDependants": "0",
		"housingExpensePostcodeCategory": ["Metropolitan"],
		"applicationHousingExpenseCategory": ["Board"],
		"value": "590"
		}, {
		"sopType": ["Single"],
		"minDependants": "0",
		"housingExpensePostcodeCategory": ["Non-Metro"],
		"applicationHousingExpenseCategory": ["Rent"],
		"value": "590"
		}, {
		"sopType": ["Single"],
		"minDependants": "0",
		"housingExpensePostcodeCategory": ["Non-Metro"],
		"applicationHousingExpenseCategory": ["Board"],
		"value": "590"
		}, {
		"sopType": ["Couple"],
		"minDependants": "0",
		"housingExpensePostcodeCategory": ["Metropolitan"],
		"applicationHousingExpenseCategory": ["Rent"],
		"value": "590"
		}, {
		"sopType": ["Couple"],
		"minDependants": "0",
		"housingExpensePostcodeCategory": ["Metropolitan"],
		"applicationHousingExpenseCategory": ["Board"],
		"value": "590"
		}, {
		"sopType": ["Couple"],
		"minDependants": "0",
		"housingExpensePostcodeCategory": ["Non-Metro"],
		"applicationHousingExpenseCategory": ["Rent"],
		"value": "590"
		}, {
		"sopType": ["Couple"],
		"minDependants": "0",
		"housingExpensePostcodeCategory": ["Non-Metro"],
		"applicationHousingExpenseCategory": ["Board"],
		"value": "590"
		}],
	"X255": "5.99",
	"X256": "7.5",
	"X257": "8",
	"taxSchedule": [{
		"amountThreshold": "18200.01",
		"baseValue": "0",
		"rate": "0.16"
		}, {
		"amountThreshold": "45000.01",
		"baseValue": "4288",
		"rate": "0.3"
		}, {
		"amountThreshold": "135000.01",
		"baseValue": "31288",
		"rate": "0.37"
		}, {
		"amountThreshold": "190000.01",
		"baseValue": "51638",
		"rate": "0.45"
		}],
	"debtLevySchedule": [{
		"amountThreshold": "180000.01",
		"baseValue": "0",
		"rate": "0"
		}],
	"medicareLevySchedule": [{
		"amountThreshold": "27222",
		"baseValue": "0",
		"rate": "0.1"
		}, {
		"amountThreshold": "34027.01",
		"rate": "0.02"
		}],
	"medicareLevySurchargeScheduleSingle": [{
		"amountThreshold": "97000.01",
		"rate": "0.01"
		}, {
		"amountThreshold": "113000.01",
		"rate": "0.0125"
		}, {
		"amountThreshold": "151000.01",
		"rate": "0.015"
		}],
	"medicareLevySurchargeScheduleFamily": [{
		"amountThreshold": "194000.01",
		"rate": "0.01"
		}, {
		"amountThreshold": "226000.01",
		"rate": "0.0125"
		}, {
		"amountThreshold": "302000.01",
		"rate": "0.015"
		}],
	"X315": [{
		"X316": "ARS",
		"X319": "224.016",
		"X320": "206.4663594"
		}, {
		"X316": "AUD",
		"X319": "1",
		"X320": "0.921658986"
		}, {
		"X316": "BSD",
		"X319": "0.64",
		"X320": "0.589861751"
		}, {
		"X316": "BHD",
		"X319": "0.2412832",
		"X320": "0.222380829"
		}, {
		"X316": "BDT",
		"X319": "70.56",
		"X320": "65.03225806"
		}, {
		"X316": "BBD",
		"X319": "1.292224",
		"X320": "1.190989862"
		}, {
		"X316": "BMD",
		"X319": "0.64",
		"X320": "0.589861751"
		}, {
		"X316": "BWP",
		"X319": "8.845888044",
		"X320": "8.152892207"
		}, {
		"X316": "BRL",
		"X319": "3.28752",
		"X320": "3.02997235"
		}, {
		"X316": "BND",
		"X319": "0.874464",
		"X320": "0.805957604"
		}, {
		"X316": "BGN",
		"X319": "1.184896",
		"X320": "1.092070046"
		}, {
		"X316": "KHR",
		"X319": "2643.2",
		"X320": "2436.129032"
		}, {
		"X316": "CAD",
		"X319": "0.869216",
		"X320": "0.801120737"
		}, {
		"X316": "CLP",
		"X319": "588.1536",
		"X320": "542.0770507"
		}, {
		"X316": "CNH",
		"X319": "4.663936",
		"X320": "4.298558525"
		}, {
		"X316": "CNY",
		"X319": "4.664576",
		"X320": "4.299148387"
		}, {
		"X316": "COP",
		"X319": "2762.88",
		"X320": "2546.43318"
		}, {
		"X316": "HRK",
		"X319": "4.506976",
		"X320": "4.153894931"
		}, {
		"X316": "CZK",
		"X319": "14.81504",
		"X320": "13.65441475"
		}, {
		"X316": "CDF",
		"X319": "1584",
		"X320": "1459.907834"
		}, {
		"X316": "DKK",
		"X319": "4.51728",
		"X320": "4.163391705"
		}, {
		"X316": "EGP",
		"X319": "19.776",
		"X320": "18.22672811"
		}, {
		"X316": "EUR",
		"X319": "0.605773781",
		"X320": "0.558316849"
		}, {
		"X316": "FJD",
		"X319": "1.472279733",
		"X320": "1.356939846"
		}, {
		"X316": "XPF",
		"X319": "72.3936",
		"X320": "66.72221198"
		}, {
		"X316": "XAU",
		"X319": "2909.296875",
		"X320": "3156.587109"
		}, {
		"X316": "HKD",
		"X319": "5.007072",
		"X320": "4.614812903"
		}, {
		"X316": "HUF",
		"X319": "235.4464",
		"X320": "217.0012903"
		}, {
		"X316": "INR",
		"X319": "53.2816",
		"X320": "49.10746544"
		}, {
		"X316": "IDR",
		"X319": "10061.76",
		"X320": "9273.511521"
		}, {
		"X316": "IQD",
		"X319": "837.76",
		"X320": "772.1290323"
		}, {
		"X316": "ILS",
		"X319": "2.504832",
		"X320": "2.308600922"
		}, {
		"X316": "XOF",
		"X319": "398.88",
		"X320": "367.6313364"
		}, {
		"X316": "JPY",
		"X319": "95.152",
		"X320": "87.69769585"
		}, {
		"X316": "JOD",
		"X319": "0.453824",
		"X320": "0.418270968"
		}, {
		"X316": "KES",
		"X319": "95.296",
		"X320": "87.83041475"
		}, {
		"X316": "KWD",
		"X319": "0.1978176",
		"X320": "0.182320369"
		}, {
		"X316": "LAK",
		"X319": "13102.9632",
		"X320": "12076.46378"
		}, {
		"X316": "MOP",
		"X319": "5.16096",
		"X320": "4.756645161"
		}, {
		"X316": "MWK",
		"X319": "737.2096",
		"X320": "679.4558525"
		}, {
		"X316": "MYR",
		"X319": "3.0304",
		"X320": "2.792995392"
		}, {
		"X316": "MUR",
		"X319": "28.288",
		"X320": "26.0718894"
		}, {
		"X316": "MXN",
		"X319": "11.6512",
		"X320": "10.73843318"
		}, {
		"X316": "MMK",
		"X319": "1344",
		"X320": "1238.709677"
		}, {
		"X316": "NPR",
		"X319": "85.2512",
		"X320": "78.57253456"
		}, {
		"X316": "NZD",
		"X319": "1.085",
		"X320": "1"
		}, {
		"X316": "NGN",
		"X319": "485.8944",
		"X320": "447.8289401"
		}, {
		"X316": "NOK",
		"X319": "6.913792",
		"X320": "6.372158525"
		}, {
		"X316": "OMR",
		"X319": "0.2464",
		"X320": "0.227096774"
		}, {
		"X316": "PKR",
		"X319": "179.52",
		"X320": "165.4562212"
		}, {
		"X316": "XPD",
		"X319": "1796.135547",
		"X320": "1948.807068"
		}, {
		"X316": "PGK",
		"X319": "2.361623616",
		"X320": "2.176611628"
		}, {
		"X316": "PEN",
		"X319": "2.457152",
		"X320": "2.264656221"
		}, {
		"X316": "PHP",
		"X319": "36.3968",
		"X320": "33.54543779"
		}, {
		"X316": "XPT",
		"X319": "1395.163281",
		"X320": "1513.75216"
		}, {
		"X316": "PLN",
		"X319": "2.766016",
		"X320": "2.549323502"
		}, {
		"X316": "QAR",
		"X319": "2.3336",
		"X320": "2.15078341"
		}, {
		"X316": "RON",
		"X319": "3.007776",
		"X320": "2.772143779"
		}, {
		"X316": "RUB",
		"X319": "64.056",
		"X320": "59.03778802"
		}, {
		"X316": "WST",
		"X319": "1.775804661",
		"X320": "1.636686324"
		}, {
		"X316": "SAR",
		"X319": "2.40064",
		"X320": "2.212571429"
		}, {
		"X316": "SCR",
		"X319": "8.716832",
		"X320": "8.033946544"
		}, {
		"X316": "SLL",
		"X319": "14249.28",
		"X320": "13132.97696"
		}, {
		"X316": "XAG",
		"X319": "0.029391504",
		"X320": "0.027088944"
		}, {
		"X316": "SGD",
		"X319": "0.874464",
		"X320": "0.805957604"
		}, {
		"X316": "SBD",
		"X319": "5.423728814",
		"X320": "4.9988284"
		}, {
		"X316": "ZAR",
		"X319": "12.381984",
		"X320": "11.41196682"
		}, {
		"X316": "KRW",
		"X319": "863.68",
		"X320": "796.0184332"
		}, {
		"X316": "LKR",
		"X319": "206.96",
		"X320": "190.7465438"
		}, {
		"X316": "SEK",
		"X319": "7.014368",
		"X320": "6.4648553"
		}, {
		"X316": "CHF",
		"X319": "0.579936",
		"X320": "0.534503226"
		}, {
		"X316": "TWD",
		"X319": "20.63136",
		"X320": "19.01507834"
		}, {
		"X316": "TZS",
		"X319": "1603.2",
		"X320": "1477.603687"
		}, {
		"X316": "THB",
		"X319": "23.6192",
		"X320": "21.76884793"
		}, {
		"X316": "TOP",
		"X319": "1.52817574",
		"X320": "1.408456903"
		}, {
		"X316": "TND",
		"X319": "2.02976",
		"X320": "1.870746544"
		}, {
		"X316": "TRY",
		"X319": "17.746208",
		"X320": "16.35595207"
		}, {
		"X316": "UGX",
		"X319": "2399.36",
		"X320": "2211.391705"
		}, {
		"X316": "UAH",
		"X319": "23.4112",
		"X320": "21.57714286"
		}, {
		"X316": "AED",
		"X319": "2.350528",
		"X320": "2.166385253"
		}, {
		"X316": "GBP",
		"X319": "0.523260567",
		"X320": "0.482267804"
		}, {
		"X316": "USD",
		"X319": "0.64",
		"X320": "0.589861751"
		}, {
		"X316": "UYU",
		"X319": "25.3536",
		"X320": "23.36737327"
		}, {
		"X316": "VUV",
		"X319": "77.4528",
		"X320": "71.38506912"
		}, {
		"X316": "VND",
		"X319": "15617.6",
		"X320": "14394.10138"
		}, {
		"X316": "ZMW",
		"X319": "13.744",
		"X320": "12.66728111"
		}, {
		"X316": "ZWL",
		"X319": "3400.5216",
		"X320": "3134.12129"
		}],
	"effectiveDateGovFee": "2025-02-25T00:00:00Z",
	"registrationOfTransferOfLand": {
		"act": [{
			"amountThreshold": "0",
			"amountThresholdMax": "99999999999",
			"baseValue": "479",
			"rate": "0"
			}],
		"nsw": [{
			"amountThreshold": "0",
			"amountThresholdMax": "99999999999",
			"baseValue": "175.7",
			"rate": "0"
			}],
		"nt": [{
			"amountThreshold": "0",
			"amountThresholdMax": "99999999999",
			"baseValue": "176",
			"rate": "0"
			}],
		"qld": [{
			"amountThreshold": "0",
			"amountThresholdMax": "180000",
			"baseValue": "238.14",
			"rate": "0"
			}, {
			"amountThreshold": "180000",
			"amountThresholdMax": "99999999999",
			"amountRoundingGranularity": "10000",
			"amountRoundingDirection": "up",
			"baseValue": "238.14",
			"rate": "0.004471"
			}],
		"sa": [{
			"amountThreshold": "0",
			"amountThresholdMax": "5000",
			"baseValue": "198",
			"rate": "0"
			}, {
			"amountThreshold": "5000",
			"amountThresholdMax": "20000",
			"baseValue": "221",
			"rate": "0"
			}, {
			"amountThreshold": "20000",
			"amountThresholdMax": "40000",
			"baseValue": "243",
			"rate": "0"
			}, {
			"amountThreshold": "40000",
			"amountThresholdMax": "50000",
			"baseValue": "342",
			"rate": "0"
			}, {
			"amountThreshold": "50000",
			"amountThresholdMax": "99999999999",
			"amountRoundingGranularity": "10000",
			"amountRoundingDirection": "up",
			"baseValue": "342",
			"rate": "0.0102"
			}],
		"tas": [{
			"amountThreshold": "0",
			"amountThresholdMax": "99999999999",
			"baseValue": "250.21",
			"rate": "0"
			}],
		"vic": [{
			"amountThreshold": "0",
			"amountThresholdMax": "1500170.94",
			"amountRoundingGranularity": "1000",
			"amountRoundingDirection": "down",
			"baseValue": "111.8",
			"rate": "0.00234",
			"resultRoundingGranularity": "1",
			"resultRoundingDirection": "up"
			}, {
			"amountThreshold": "1500170.95",
			"amountThresholdMax": "99999999999",
			"baseValue": "3621",
			"rate": "0"
			}],
		"wa": [{
			"amountThreshold": "0",
			"amountThresholdMax": "85000",
			"baseValue": "216.6",
			"rate": "0"
			}, {
			"amountThreshold": "85000",
			"amountThresholdMax": "120000",
			"baseValue": "226.6",
			"rate": "0"
			}, {
			"amountThreshold": "120000",
			"amountThresholdMax": "200000",
			"baseValue": "246.6",
			"rate": "0"
			}, {
			"amountThreshold": "200000",
			"amountThresholdMax": "300000",
			"baseValue": "266.6",
			"rate": "0"
			}, {
			"amountThreshold": "300000",
			"amountThresholdMax": "400000",
			"baseValue": "286.6",
			"rate": "0"
			}, {
			"amountThreshold": "400000",
			"amountThresholdMax": "500000",
			"baseValue": "306.6",
			"rate": "0"
			}, {
			"amountThreshold": "500000",
			"amountThresholdMax": "600000",
			"baseValue": "326.6",
			"rate": "0"
			}, {
			"amountThreshold": "600000",
			"amountThresholdMax": "700000",
			"baseValue": "346.6",
			"rate": "0"
			}, {
			"amountThreshold": "700000",
			"amountThresholdMax": "800000",
			"baseValue": "366.6",
			"rate": "0"
			}, {
			"amountThreshold": "800000",
			"amountThresholdMax": "900000",
			"baseValue": "386.6",
			"rate": "0"
			}, {
			"amountThreshold": "900000",
			"amountThresholdMax": "1000000",
			"baseValue": "406.6",
			"rate": "0"
			}, {
			"amountThreshold": "1000000",
			"amountThresholdMax": "1100000",
			"baseValue": "426.6",
			"rate": "0"
			}, {
			"amountThreshold": "1100000",
			"amountThresholdMax": "1200000",
			"baseValue": "446.6",
			"rate": "0"
			}, {
			"amountThreshold": "1200000",
			"amountThresholdMax": "1300000",
			"baseValue": "466.6",
			"rate": "0"
			}, {
			"amountThreshold": "1300000",
			"amountThresholdMax": "1400000",
			"baseValue": "486.6",
			"rate": "0"
			}, {
			"amountThreshold": "1400000",
			"amountThresholdMax": "1500000",
			"baseValue": "506.6",
			"rate": "0"
			}, {
			"amountThreshold": "1500000",
			"amountThresholdMax": "1600000",
			"baseValue": "526.6",
			"rate": "0"
			}, {
			"amountThreshold": "1600000",
			"amountThresholdMax": "1700000",
			"baseValue": "546.6",
			"rate": "0"
			}, {
			"amountThreshold": "1700000",
			"amountThresholdMax": "1800000",
			"baseValue": "566.6",
			"rate": "0"
			}, {
			"amountThreshold": "1800000",
			"amountThresholdMax": "1900000",
			"baseValue": "586.6",
			"rate": "0"
			}, {
			"amountThreshold": "1900000",
			"amountThresholdMax": "2000000",
			"baseValue": "606.6",
			"rate": "0"
			}, {
			"amountThreshold": "2000000",
			"amountThresholdMax": "99999999999",
			"amountRoundingGranularity": "100000",
			"amountRoundingDirection": "up",
			"baseValue": "606.6",
			"rate": "0.0002"
			}]
	},
	"dependents": {
		"act": [{
			"noOfDependent": "0",
			"grossIncomeThreshold": "250000"
			}, {
			"noOfDependent": "1",
			"grossIncomeThreshold": "254600"
			}, {
			"noOfDependent": "2",
			"grossIncomeThreshold": "259200"
			}, {
			"noOfDependent": "3",
			"grossIncomeThreshold": "263800"
			}, {
			"noOfDependent": "4",
			"grossIncomeThreshold": "268400"
			}, {
			"noOfDependent": "5",
			"grossIncomeThreshold": "273000"
			}, {
			"noOfDependent": "6 or above",
			"grossIncomeThreshold": "277600"
			}]
	},
	"landTransferStampDuty": {
		"act": [{
			"index": "1",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"incomeThreshold": true,
			"contractAmountThreshold": "0",
			"contractAmountThresholdMax": "1000000",
			"groupIdentifier": "ACT_GROUP_1",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "3",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"incomeThreshold": true,
			"contractAmountThreshold": "1000000",
			"contractAmountThresholdMax": "1455000",
			"groupIdentifier": "ACT_GROUP_1",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.064",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "4",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"incomeThreshold": true,
			"contractAmountThreshold": "1455000",
			"contractAmountThresholdMax": "99999999",
			"groupIdentifier": "ACT_GROUP_1",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "31553",
			"rate": "0.0454",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "5",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"contractAmountThreshold": "0",
			"contractAmountThresholdMax": "1600",
			"groupIdentifier": "ACT_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "11.4",
			"rate": "0",
			"concession_applied": "Owner Occupier",
			"X263": false
			}, {
			"index": "6",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"contractAmountThreshold": "0",
			"contractAmountThresholdMax": "260000",
			"groupIdentifier": "ACT_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.0049",
			"concession_applied": "Owner Occupier",
			"X263": false
			}, {
			"index": "7",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"contractAmountThreshold": "260000",
			"contractAmountThresholdMax": "300000",
			"groupIdentifier": "ACT_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "1274",
			"rate": "0.022",
			"concession_applied": "Owner Occupier",
			"X263": false
			}, {
			"index": "8",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"contractAmountThreshold": "300000",
			"contractAmountThresholdMax": "500000",
			"groupIdentifier": "ACT_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "2154",
			"rate": "0.034",
			"concession_applied": "Owner Occupier",
			"X263": false
			}, {
			"index": "9",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"contractAmountThreshold": "500000",
			"contractAmountThresholdMax": "750000",
			"groupIdentifier": "ACT_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "8954",
			"rate": "0.0432",
			"concession_applied": "Owner Occupier",
			"X263": false
			}, {
			"index": "10",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"contractAmountThreshold": "750000",
			"contractAmountThresholdMax": "1000000",
			"groupIdentifier": "ACT_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "19754",
			"rate": "0.059",
			"concession_applied": "Owner Occupier",
			"X263": false
			}, {
			"index": "11",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"contractAmountThreshold": "1000000",
			"contractAmountThresholdMax": "1455000",
			"groupIdentifier": "ACT_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "34504",
			"rate": "0.064",
			"concession_applied": "Owner Occupier",
			"X263": false
			}, {
			"index": "12",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"contractAmountThreshold": "1455000",
			"contractAmountThresholdMax": "99999999",
			"groupIdentifier": "ACT_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "66057",
			"rate": "0.0454",
			"X263": false
			}, {
			"index": "13",
			"contractAmountThreshold": "0",
			"contractAmountThresholdMax": "1600",
			"groupIdentifier": "ACT_GROUP_3",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "20",
			"rate": "0",
			"X263": false
			}, {
			"index": "14",
			"contractAmountThreshold": "0",
			"contractAmountThresholdMax": "200000",
			"groupIdentifier": "ACT_GROUP_3",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.012",
			"X263": false
			}, {
			"index": "15",
			"contractAmountThreshold": "200000",
			"contractAmountThresholdMax": "300000",
			"groupIdentifier": "ACT_GROUP_3",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "2400",
			"rate": "0.022",
			"X263": false
			}, {
			"index": "16",
			"contractAmountThreshold": "300000",
			"contractAmountThresholdMax": "500000",
			"groupIdentifier": "ACT_GROUP_3",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "4600",
			"rate": "0.034",
			"X263": false
			}, {
			"index": "17",
			"contractAmountThreshold": "500000",
			"contractAmountThresholdMax": "750000",
			"groupIdentifier": "ACT_GROUP_3",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "11400",
			"rate": "0.0432",
			"X263": false
			}, {
			"index": "18",
			"contractAmountThreshold": "750000",
			"contractAmountThresholdMax": "1000000",
			"groupIdentifier": "ACT_GROUP_3",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "22200",
			"rate": "0.059",
			"X263": false
			}, {
			"index": "19",
			"contractAmountThreshold": "1000000",
			"contractAmountThresholdMax": "1455000",
			"groupIdentifier": "ACT_GROUP_3",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "36950",
			"rate": "0.064",
			"X263": false
			}, {
			"index": "20",
			"contractAmountThreshold": "1455000",
			"contractAmountThresholdMax": "99999999",
			"groupIdentifier": "ACT_GROUP_3",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "66057",
			"rate": "0.0454",
			"X263": false
			}],
		"nsw": [{
			"index": "21",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "0",
			"amountThresholdMax": "800000",
			"groupIdentifier": "NSW_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "22",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "800000",
			"amountThresholdMax": "1000000",
			"groupIdentifier": "NSW_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.197645",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "23",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "1000000",
			"amountThresholdMax": "1240000",
			"groupIdentifier": "NSW_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "39412",
			"rate": "0.045",
			"X263": false
			}, {
			"index": "25",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "1240000",
			"amountThresholdMax": "3721000",
			"groupIdentifier": "NSW_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "50212",
			"rate": "0.055",
			"X263": false
			}, {
			"index": "26",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "3721000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "NSW_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "186667",
			"rate": "0.07",
			"X263": false
			}, {
			"index": "27",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "0",
			"amountThresholdMax": "350000",
			"groupIdentifier": "NSW_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false,
			"formula": "LandTransferStampDutyNSW2"
			}, {
			"index": "28",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "350000",
			"amountThresholdMax": "450000",
			"groupIdentifier": "NSW_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "-10",
			"rate": "0.14882",
			"concession_applied": "First Home Buyer",
			"X263": false,
			"formula": "LandTransferStampDutyNSW2"
			}, {
			"index": "30",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "450000",
			"amountThresholdMax": "1240000",
			"groupIdentifier": "NSW_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "14662",
			"rate": "0.045",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "31",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "1240000",
			"amountThresholdMax": "3721000",
			"groupIdentifier": "NSW_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "50212",
			"rate": "0.055",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "32",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "3721000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "NSW_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "186667",
			"rate": "0.07",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "33",
			"amountThreshold": "0",
			"amountThresholdMax": "1600",
			"groupIdentifier": "NSW_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "20",
			"rate": "0",
			"X263": false
			}, {
			"index": "34",
			"amountThreshold": "1600",
			"amountThresholdMax": "17000",
			"groupIdentifier": "NSW_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "20",
			"rate": "0.0125",
			"X263": false
			}, {
			"index": "35",
			"amountThreshold": "17000",
			"amountThresholdMax": "37000",
			"groupIdentifier": "NSW_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "212",
			"rate": "0.015",
			"X263": false
			}, {
			"index": "36",
			"amountThreshold": "37000",
			"amountThresholdMax": "99000",
			"groupIdentifier": "NSW_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "512",
			"rate": "0.0175",
			"X263": false
			}, {
			"index": "37",
			"amountThreshold": "99000",
			"amountThresholdMax": "372000",
			"groupIdentifier": "NSW_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "1597",
			"rate": "0.035",
			"X263": false
			}, {
			"index": "38",
			"amountThreshold": "372000",
			"amountThresholdMax": "1240000",
			"groupIdentifier": "NSW_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "11152",
			"rate": "0.045",
			"X263": false
			}, {
			"index": "39",
			"amountThreshold": "1240000",
			"amountThresholdMax": "3721000",
			"groupIdentifier": "NSW_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "50212",
			"rate": "0.055",
			"X263": false
			}, {
			"index": "40",
			"amountThreshold": "3721000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "NSW_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "186667",
			"rate": "0.07",
			"X263": false
			}],
		"nt": [{
			"index": "41",
			"amountThreshold": "0",
			"amountThresholdMax": "525000",
			"groupIdentifier": "NT_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "1000",
			"baseValue": "0",
			"rate": "0.06571441",
			"X263": false,
			"formula": "LandTransferStampDutyNT1"
			}, {
			"index": "42",
			"amountThreshold": "525000",
			"amountThresholdMax": "2999999.99",
			"groupIdentifier": "NT_GROUP_3",
			"amountToUse": "dutiable",
			"baseValue": "25987.5",
			"rate": "0.0495",
			"X263": false
			}, {
			"index": "43",
			"amountThreshold": "3000000",
			"amountThresholdMax": "4999999.99",
			"groupIdentifier": "NT_GROUP_3",
			"amountToUse": "dutiable",
			"baseValue": "172500",
			"rate": "0.0575",
			"X263": false
			}, {
			"index": "44",
			"amountThreshold": "5000000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "NT_GROUP_3",
			"amountToUse": "dutiable",
			"baseValue": "297500",
			"rate": "0.0595",
			"X263": false
			}],
		"qld": [{
			"index": "45",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"vacantLand": false,
			"amountThreshold": "0",
			"amountThresholdMax": "350000",
			"groupIdentifier": "QLD_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.01",
			"concession_applied": "Home",
			"X263": false
			}, {
			"index": "46",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"vacantLand": false,
			"amountThreshold": "350000",
			"amountThresholdMax": "540000",
			"groupIdentifier": "QLD_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "3500",
			"rate": "0.035",
			"concession_applied": "Home",
			"X263": false
			}, {
			"index": "47",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"vacantLand": false,
			"amountThreshold": "540000",
			"amountThresholdMax": "1000000",
			"groupIdentifier": "QLD_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "10150",
			"rate": "0.045",
			"concession_applied": "Home",
			"X263": false
			}, {
			"index": "48",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"vacantLand": false,
			"amountThreshold": "1000000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "QLD_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "30850",
			"rate": "0.0575",
			"concession_applied": "Home",
			"X263": false
			}, {
			"index": "49",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "0",
			"amountThresholdMax": "699999.99",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "50",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "700000",
			"amountThresholdMax": "709999.99",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.045",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "51",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "710000",
			"amountThresholdMax": "719999.99",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "2185",
			"rate": "0.045",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "52",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "720000",
			"amountThresholdMax": "729999.99",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "4370",
			"rate": "0.045",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "53",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "730000",
			"amountThresholdMax": "739999.99",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "6555",
			"rate": "0.045",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "54",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "740000",
			"amountThresholdMax": "749999.99",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "8740",
			"rate": "0.045",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "55",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "750000",
			"amountThresholdMax": "759999.99",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "10925",
			"rate": "0.045",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "56",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "760000",
			"amountThresholdMax": "769999.99",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "13110",
			"rate": "0.045",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "57",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "770000",
			"amountThresholdMax": "779999.99",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "15295",
			"rate": "0.045",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "58",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "780000",
			"amountThresholdMax": "789999.99",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "17480",
			"rate": "0.045",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "59",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "790000",
			"amountThresholdMax": "799999.99",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "19665",
			"rate": "0.045",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "60",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "800000",
			"amountThresholdMax": "1000000",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "21850",
			"rate": "0.045",
			"concession_applied": "Home",
			"X263": false
			}, {
			"index": "61",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "1000000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "QLD_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "30850",
			"rate": "0.0575",
			"concession_applied": "Home",
			"X263": false
			}, {
			"index": "62",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "0",
			"amountThresholdMax": "359999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "63",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "360000",
			"amountThresholdMax": "369999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "64",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "370000",
			"amountThresholdMax": "379999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "65",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "380000",
			"amountThresholdMax": "389999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "66",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "390000",
			"amountThresholdMax": "399999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "67",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "400000",
			"amountThresholdMax": "409999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "68",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "410000",
			"amountThresholdMax": "419999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "69",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "420000",
			"amountThresholdMax": "429999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "70",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "430000",
			"amountThresholdMax": "439999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "71",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "440000",
			"amountThresholdMax": "449999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "72",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "450000",
			"amountThresholdMax": "459999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "73",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "460000",
			"amountThresholdMax": "469999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "74",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "470000",
			"amountThresholdMax": "479999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "75",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "480000",
			"amountThresholdMax": "489999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "76",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "490000",
			"amountThresholdMax": "499999.99",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "77",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "500000",
			"amountThresholdMax": "540000",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "79",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "540000",
			"amountThresholdMax": "1000000",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "17325",
			"rate": "0.045",
			"X263": false
			}, {
			"index": "80",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "1000000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "38025",
			"rate": "0.0575",
			"X263": false
			}, {
			"index": "81",
			"amountThreshold": "0",
			"amountThresholdMax": "5000",
			"groupIdentifier": "QLD_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"X263": false
			}, {
			"index": "82",
			"amountThreshold": "5000",
			"amountThresholdMax": "75000",
			"groupIdentifier": "QLD_GROUP_4",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.015",
			"X263": false
			}, {
			"index": "83",
			"amountThreshold": "75000",
			"amountThresholdMax": "540000",
			"groupIdentifier": "QLD_GROUP_4",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "1050",
			"rate": "0.035",
			"X263": false
			}, {
			"index": "84",
			"amountThreshold": "540000",
			"amountThresholdMax": "1000000",
			"groupIdentifier": "QLD_GROUP_4",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "17325",
			"rate": "0.045",
			"X263": false
			}, {
			"index": "85",
			"amountThreshold": "1000000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "QLD_GROUP_4",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "38025",
			"rate": "0.0575",
			"X263": false
			}],
		"sa": [{
			"index": "86",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"buyingEstablishedHouse": false,
			"amountThreshold": "0",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "SA_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "93",
			"amountThreshold": "0",
			"amountThresholdMax": "12000",
			"groupIdentifier": "SA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.01",
			"X263": false
			}, {
			"index": "94",
			"amountThreshold": "12000",
			"amountThresholdMax": "30000",
			"groupIdentifier": "SA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "120",
			"rate": "0.02",
			"X263": false
			}, {
			"index": "95",
			"amountThreshold": "30000",
			"amountThresholdMax": "50000",
			"groupIdentifier": "SA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "480",
			"rate": "0.03",
			"X263": false
			}, {
			"index": "96",
			"amountThreshold": "50000",
			"amountThresholdMax": "100000",
			"groupIdentifier": "SA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "1080",
			"rate": "0.035",
			"X263": false
			}, {
			"index": "97",
			"amountThreshold": "100000",
			"amountThresholdMax": "200000",
			"groupIdentifier": "SA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "2830",
			"rate": "0.04",
			"X263": false
			}, {
			"index": "98",
			"amountThreshold": "200000",
			"amountThresholdMax": "250000",
			"groupIdentifier": "SA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "6830",
			"rate": "0.0425",
			"X263": false
			}, {
			"index": "99",
			"amountThreshold": "250000",
			"amountThresholdMax": "300000",
			"groupIdentifier": "SA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "8955",
			"rate": "0.0475",
			"X263": false
			}, {
			"index": "100",
			"amountThreshold": "300000",
			"amountThresholdMax": "500000",
			"groupIdentifier": "SA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "11330",
			"rate": "0.05",
			"X263": false
			}, {
			"index": "101",
			"amountThreshold": "500000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "SA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "21330",
			"rate": "0.055",
			"X263": false
			}],
		"tas": [{
			"index": "102",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"buyingEstablishedHouse": true,
			"vacantLand": false,
			"contractAmountThreshold": "0",
			"contractAmountThresholdMax": "750000",
			"groupIdentifier": "TAS_GROUP_1",
			"amountToUse": "contract",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "109",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"buyingEstablishedHouse": true,
			"vacantLand": false,
			"contractAmountThreshold": "750000",
			"contractAmountThresholdMax": "99999999",
			"groupIdentifier": "TAS_GROUP_1",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "28935",
			"rate": "0.045",
			"X263": false
			}, {
			"index": "110",
			"contractAmountThreshold": "0",
			"contractAmountThresholdMax": "3000",
			"groupIdentifier": "TAS_GROUP_2",
			"amountToUse": "contract",
			"baseValue": "50",
			"rate": "0",
			"X263": false
			}, {
			"index": "111",
			"contractAmountThreshold": "3000",
			"contractAmountThresholdMax": "25000",
			"groupIdentifier": "TAS_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "50",
			"rate": "0.0175",
			"X263": false
			}, {
			"index": "112",
			"contractAmountThreshold": "25000",
			"contractAmountThresholdMax": "75000",
			"groupIdentifier": "TAS_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "435",
			"rate": "0.0225",
			"X263": false
			}, {
			"index": "113",
			"contractAmountThreshold": "75000",
			"contractAmountThresholdMax": "200000",
			"groupIdentifier": "TAS_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "1560",
			"rate": "0.035",
			"X263": false
			}, {
			"index": "114",
			"contractAmountThreshold": "200000",
			"contractAmountThresholdMax": "375000",
			"groupIdentifier": "TAS_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "5935",
			"rate": "0.04",
			"X263": false
			}, {
			"index": "115",
			"contractAmountThreshold": "375000",
			"contractAmountThresholdMax": "725000",
			"groupIdentifier": "TAS_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "12935",
			"rate": "0.0425",
			"X263": false
			}, {
			"index": "116",
			"contractAmountThreshold": "725000",
			"contractAmountThresholdMax": "99999999",
			"groupIdentifier": "TAS_GROUP_2",
			"amountToUse": "contract",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "27810",
			"rate": "0.045",
			"X263": false
			}],
		"vic": [{
			"index": "117",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "0",
			"amountThresholdMax": "25000",
			"groupIdentifier": "VIC_GROUP_1",
			"amountToUse": "dutiable",
			"baseValue": "0",
			"rate": "0.014",
			"X263": false
			}, {
			"index": "118",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "25000",
			"amountThresholdMax": "130000",
			"groupIdentifier": "VIC_GROUP_1",
			"amountToUse": "dutiable",
			"baseValue": "350",
			"rate": "0.024",
			"X263": false
			}, {
			"index": "119",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "130000",
			"amountThresholdMax": "440000",
			"groupIdentifier": "VIC_GROUP_1",
			"amountToUse": "dutiable",
			"baseValue": "2870",
			"rate": "0.05",
			"concession_applied": "Principle Place of Residence",
			"X263": false
			}, {
			"index": "120",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "440000",
			"amountThresholdMax": "550000",
			"groupIdentifier": "VIC_GROUP_1",
			"amountToUse": "dutiable",
			"baseValue": "18370",
			"rate": "0.06",
			"concession_applied": "Principle Place of Residence",
			"X263": false
			}, {
			"index": "121",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "550000",
			"amountThresholdMax": "960000",
			"contractAmountThreshold": "550000",
			"contractAmountThresholdMax": "960000",
			"groupIdentifier": "VIC_GROUP_1",
			"amountToUse": "contract",
			"baseValue": "28070",
			"rate": "0.06",
			"X263": false
			}, {
			"index": "122",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "960000",
			"amountThresholdMax": "2000000",
			"contractAmountThreshold": "960000",
			"contractAmountThresholdMax": "2000000",
			"groupIdentifier": "VIC_GROUP_1",
			"amountToUse": "contract",
			"baseValue": "52800",
			"rate": "0.055",
			"X263": false
			}, {
			"index": "123",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "2000000",
			"amountThresholdMax": "99999999",
			"contractAmountThreshold": "2000000",
			"contractAmountThresholdMax": "99999999",
			"groupIdentifier": "VIC_GROUP_1",
			"amountToUse": "contract",
			"baseValue": "110000",
			"rate": "0.065",
			"X263": false
			}, {
			"index": "132",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"amountThreshold": "0",
			"amountThresholdMax": "600000",
			"groupIdentifier": "VIC_GROUP_3",
			"amountToUse": "dutiable",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "133",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"amountThreshold": "600000",
			"amountThresholdMax": "749999.99",
			"groupIdentifier": "VIC_GROUP_3",
			"amountToUse": "dutiable",
			"baseValue": "31070",
			"rate": "0.06",
			"concession_applied": "First Home Buyer",
			"X263": false,
			"formula": "LandTransferStampDutyVIC1"
			}, {
			"index": "134",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"amountThreshold": "750000",
			"amountThresholdMax": "960000",
			"contractAmountThreshold": "750000",
			"contractAmountThresholdMax": "960000",
			"groupIdentifier": "VIC_GROUP_3",
			"amountToUse": "contract",
			"baseValue": "40070",
			"rate": "0.06",
			"X263": false
			}, {
			"index": "135",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"amountThreshold": "960000",
			"amountThresholdMax": "2000000",
			"contractAmountThreshold": "960000",
			"contractAmountThresholdMax": "2000000",
			"groupIdentifier": "VIC_GROUP_3",
			"amountToUse": "contract",
			"baseValue": "52800",
			"rate": "0.055",
			"X263": false
			}, {
			"index": "136",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"amountThreshold": "2000000",
			"amountThresholdMax": "99999999",
			"contractAmountThreshold": "2000000",
			"contractAmountThresholdMax": "99999999",
			"groupIdentifier": "VIC_GROUP_3",
			"amountToUse": "contract",
			"baseValue": "110000",
			"rate": "0.065",
			"X263": false
			}, {
			"index": "137",
			"contractAmountThreshold": "0",
			"contractAmountThresholdMax": "25000",
			"groupIdentifier": "VIC_GROUP_4",
			"amountToUse": "contract",
			"baseValue": "0",
			"rate": "0.014",
			"X263": false
			}, {
			"index": "138",
			"contractAmountThreshold": "25000",
			"contractAmountThresholdMax": "130000",
			"groupIdentifier": "VIC_GROUP_4",
			"amountToUse": "contract",
			"baseValue": "350",
			"rate": "0.024",
			"X263": false
			}, {
			"index": "139",
			"contractAmountThreshold": "130000",
			"contractAmountThresholdMax": "960000",
			"groupIdentifier": "VIC_GROUP_4",
			"amountToUse": "contract",
			"baseValue": "2870",
			"rate": "0.06",
			"X263": false
			}, {
			"index": "140",
			"contractAmountThreshold": "960000",
			"contractAmountThresholdMax": "2000000",
			"groupIdentifier": "VIC_GROUP_4",
			"amountToUse": "contract",
			"baseValue": "52800",
			"rate": "0.055",
			"X263": false
			}, {
			"index": "141",
			"contractAmountThreshold": "2000000",
			"contractAmountThresholdMax": "99999999",
			"groupIdentifier": "VIC_GROUP_4",
			"amountToUse": "contract",
			"baseValue": "110000",
			"rate": "0.065",
			"X263": false
			}],
		"wa": [{
			"index": "142",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "0",
			"amountThresholdMax": "120000",
			"groupIdentifier": "WA_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.015",
			"concession_applied": "Concessional Rate",
			"X263": false
			}, {
			"index": "143",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "120000",
			"amountThresholdMax": "200000",
			"groupIdentifier": "WA_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "1800",
			"rate": "0.0404",
			"concession_applied": "Concessional Rate",
			"X263": false
			}, {
			"index": "144",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "200000",
			"amountThresholdMax": "360000",
			"groupIdentifier": "WA_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "3135",
			"rate": "0.038",
			"X263": false
			}, {
			"index": "145",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "360000",
			"amountThresholdMax": "725000",
			"groupIdentifier": "WA_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "11115",
			"rate": "0.0475",
			"X263": false
			}, {
			"index": "146",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": false,
			"amountThreshold": "725000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "WA_GROUP_1",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "28453",
			"rate": "0.0515",
			"X263": false
			}, {
			"index": "147",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "0",
			"amountThresholdMax": "500000",
			"groupIdentifier": "WA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "148",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "500000",
			"amountThresholdMax": "700000",
			"groupIdentifier": "WA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.1501",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "149",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "700000",
			"amountThresholdMax": "725000",
			"groupIdentifier": "WA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "22515",
			"rate": "0.0475",
			"X263": false
			}, {
			"index": "150",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": false,
			"amountThreshold": "725000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "WA_GROUP_2",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "28453",
			"rate": "0.0515",
			"X263": false
			}, {
			"index": "151",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "0",
			"amountThresholdMax": "350000",
			"groupIdentifier": "WA_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "152",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "350000",
			"amountThresholdMax": "450000",
			"groupIdentifier": "WA_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.1539",
			"concession_applied": "First Home Buyer",
			"X263": false
			}, {
			"index": "153",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "450000",
			"amountThresholdMax": "725000",
			"groupIdentifier": "WA_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "11115",
			"rate": "0.0475",
			"X263": false
			}, {
			"index": "154",
			"fullStampDuty": false,
			"investment": false,
			"firstHomeBuyer": true,
			"vacantLand": true,
			"amountThreshold": "725000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "WA_GROUP_3",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "28453",
			"rate": "0.0515",
			"X263": false
			}, {
			"index": "155",
			"amountThreshold": "0",
			"amountThresholdMax": "120000",
			"groupIdentifier": "WA_GROUP_4",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "0",
			"rate": "0.019",
			"X263": false
			}, {
			"index": "156",
			"amountThreshold": "120000",
			"amountThresholdMax": "150000",
			"groupIdentifier": "WA_GROUP_4",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "2280",
			"rate": "0.0285",
			"X263": false
			}, {
			"index": "157",
			"amountThreshold": "150000",
			"amountThresholdMax": "360000",
			"groupIdentifier": "WA_GROUP_4",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "3135",
			"rate": "0.038",
			"X263": false
			}, {
			"index": "158",
			"amountThreshold": "360000",
			"amountThresholdMax": "725000",
			"groupIdentifier": "WA_GROUP_4",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "11115",
			"rate": "0.0475",
			"X263": false
			}, {
			"index": "159",
			"amountThreshold": "725000",
			"amountThresholdMax": "99999999",
			"groupIdentifier": "WA_GROUP_4",
			"amountToUse": "dutiable",
			"amountRoundingGranularity": "100",
			"amountRoundingDirection": "up",
			"baseValue": "28453",
			"rate": "0.0515",
			"X263": false
			}]
	},
	"mortgageRegistrationFee": {
		"act": "178",
		"nsw": "175.7",
		"nt": "176",
		"qld": "238.14",
		"sa": "198",
		"tas": "163.3",
		"vic": "135.8",
		"wa": "216.6"
	},
	"mortgageDischargeFee": {
		"act": [{
			"baseValue": "178"
			}],
		"nsw": [{
			"baseValue": "175.7",
			"X188": true
			}],
		"nt": [{
			"baseValue": "176"
			}],
		"qld": [{
			"baseValue": "238.14",
			"X188": true
			}],
		"sa": [{
			"baseValue": "198"
			}],
		"tas": [{
			"baseValue": "202.46"
			}],
		"vic": [{
			"baseValue": "135.8",
			"X188": true
			}],
		"wa": [{
			"baseValue": "216.6"
			}]
	},
	"landTitleSearchFee": {
		"act": "35",
		"nsw": "18",
		"nt": "42",
		"qld": "49.38",
		"sa": "35.5",
		"tas": "38.2",
		"vic": "19.3",
		"wa": "48.9"
	},
	"stampDutyOfLandLabel": {
		"act": "Conveyance Duty",
		"nsw": "Transfer Duty",
		"nt": "Stamp Duty Transfer of Land",
		"qld": "Transfer Duty",
		"sa": "Stamp Duty Transfer of Land",
		"tas": "Property Transfer Duty",
		"vic": "Land Transfer Duty",
		"wa": "Transfer Duty"
	},
	"X201": {
		"act": [{
			"X202": true,
			"X204": "0"
			}, {
			"X202": false,
			"X204": "0"
			}],
		"nsw": [{
			"X204": "0.08"
			}],
		"nt": [{
			"X204": "0"
			}],
		"qld": [{
			"X204": "0.07"
			}],
		"sa": [{
			"X204": "0.07"
			}],
		"tas": [{
			"X204": "0.08"
			}],
		"vic": [{
			"X204": "0.08"
			}],
		"wa": [{
			"X204": "0.07"
			}]
	},
	"effectiveDateLMI": "2022-07-24T00:00:00Z",
	"X293": false,
	"X023": {
		"includeThreshold": false,
			"entries": [{
			"threshold": "0",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "0.36"
				}, {
				"threshold": "300000",
				"value": "0.48"
				}, {
				"threshold": "500000",
				"value": "0.48"
				}, {
				"threshold": "600000",
				"value": "0.71"
				}, {
				"threshold": "750000",
				"value": "0.71"
				}, {
				"threshold": "1000000",
				"value": "0.73"
				}, {
				"threshold": "1500000",
				"value": "0.75"
				}, {
				"threshold": "2000000",
				"value": "0.77"
				}]
			}, {
			"threshold": "80.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "0.44"
				}, {
				"threshold": "300000",
				"value": "0.56"
				}, {
				"threshold": "500000",
				"value": "0.56"
				}, {
				"threshold": "600000",
				"value": "0.74"
				}, {
				"threshold": "750000",
				"value": "0.74"
				}, {
				"threshold": "1000000",
				"value": "0.98"
				}, {
				"threshold": "1500000",
				"value": "1.04"
				}, {
				"threshold": "2000000",
				"value": "1.04"
				}]
			}, {
			"threshold": "81.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "0.44"
				}, {
				"threshold": "300000",
				"value": "0.63"
				}, {
				"threshold": "500000",
				"value": "0.63"
				}, {
				"threshold": "600000",
				"value": "0.86"
				}, {
				"threshold": "750000",
				"value": "0.88"
				}, {
				"threshold": "1000000",
				"value": "0.98"
				}, {
				"threshold": "1500000",
				"value": "1.04"
				}, {
				"threshold": "2000000",
				"value": "1.04"
				}]
			}, {
			"threshold": "82.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "0.62"
				}, {
				"threshold": "300000",
				"value": "0.71"
				}, {
				"threshold": "500000",
				"value": "0.71"
				}, {
				"threshold": "600000",
				"value": "0.98"
				}, {
				"threshold": "750000",
				"value": "1.03"
				}, {
				"threshold": "1000000",
				"value": "1.29"
				}, {
				"threshold": "1500000",
				"value": "1.32"
				}, {
				"threshold": "2000000",
				"value": "1.39"
				}]
			}, {
			"threshold": "83.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "0.64"
				}, {
				"threshold": "300000",
				"value": "0.83"
				}, {
				"threshold": "500000",
				"value": "0.83"
				}, {
				"threshold": "600000",
				"value": "1.07"
				}, {
				"threshold": "750000",
				"value": "1.1"
				}, {
				"threshold": "1000000",
				"value": "1.34"
				}, {
				"threshold": "1500000",
				"value": "1.39"
				}, {
				"threshold": "2000000",
				"value": "1.39"
				}]
			}, {
			"threshold": "84.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "0.75"
				}, {
				"threshold": "300000",
				"value": "0.92"
				}, {
				"threshold": "500000",
				"value": "0.92"
				}, {
				"threshold": "600000",
				"value": "1.17"
				}, {
				"threshold": "750000",
				"value": "1.26"
				}, {
				"threshold": "1000000",
				"value": "1.57"
				}, {
				"threshold": "1500000",
				"value": "1.6"
				}, {
				"threshold": "2000000",
				"value": "1.7"
				}]
			}, {
			"threshold": "85.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "0.96"
				}, {
				"threshold": "300000",
				"value": "1.07"
				}, {
				"threshold": "500000",
				"value": "1.07"
				}, {
				"threshold": "600000",
				"value": "1.29"
				}, {
				"threshold": "750000",
				"value": "1.42"
				}, {
				"threshold": "1000000",
				"value": "1.68"
				}, {
				"threshold": "1500000",
				"value": "1.89"
				}, {
				"threshold": "2000000",
				"value": "1.93"
				}]
			}, {
			"threshold": "86.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "1.04"
				}, {
				"threshold": "300000",
				"value": "1.18"
				}, {
				"threshold": "500000",
				"value": "1.18"
				}, {
				"threshold": "600000",
				"value": "1.45"
				}, {
				"threshold": "750000",
				"value": "1.58"
				}, {
				"threshold": "1000000",
				"value": "1.88"
				}, {
				"threshold": "1500000",
				"value": "2.08"
				}, {
				"threshold": "2000000",
				"value": "2.08"
				}]
			}, {
			"threshold": "87.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "1.19"
				}, {
				"threshold": "300000",
				"value": "1.26"
				}, {
				"threshold": "500000",
				"value": "1.26"
				}, {
				"threshold": "600000",
				"value": "1.6"
				}, {
				"threshold": "750000",
				"value": "1.71"
				}, {
				"threshold": "1000000",
				"value": "1.94"
				}, {
				"threshold": "1500000",
				"value": "2.08"
				}, {
				"threshold": "2000000",
				"value": "2.08"
				}]
			}, {
			"threshold": "88.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "1.36"
				}, {
				"threshold": "300000",
				"value": "1.51"
				}, {
				"threshold": "500000",
				"value": "1.51"
				}, {
				"threshold": "600000",
				"value": "1.96"
				}, {
				"threshold": "750000",
				"value": "2.02"
				}, {
				"threshold": "1000000",
				"value": "2.43"
				}, {
				"threshold": "1500000",
				"value": "2.54"
				}, {
				"threshold": "2000000",
				"value": "2.71"
				}]
			}, {
			"threshold": "89.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "1.53"
				}, {
				"threshold": "300000",
				"value": "1.81"
				}, {
				"threshold": "500000",
				"value": "1.81"
				}, {
				"threshold": "600000",
				"value": "2.22"
				}, {
				"threshold": "750000",
				"value": "2.24"
				}, {
				"threshold": "1000000",
				"value": "2.61"
				}, {
				"threshold": "1500000",
				"value": "2.63"
				}, {
				"threshold": "2000000",
				"value": "2.76"
				}]
			}, {
			"threshold": "90.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "2.05"
				}, {
				"threshold": "300000",
				"value": "2.45"
				}, {
				"threshold": "500000",
				"value": "2.45"
				}, {
				"threshold": "600000",
				"value": "3.11"
				}, {
				"threshold": "750000",
				"value": "3.14"
				}, {
				"threshold": "1000000",
				"value": "3.83"
				}, {
				"threshold": "1500000",
				"value": "3.98"
				}, {
				"threshold": "2000000",
				"value": "4.45"
				}]
			}, {
			"threshold": "91.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "2.05"
				}, {
				"threshold": "300000",
				"value": "2.62"
				}, {
				"threshold": "500000",
				"value": "2.62"
				}, {
				"threshold": "600000",
				"value": "3.17"
				}, {
				"threshold": "750000",
				"value": "3.28"
				}, {
				"threshold": "1000000",
				"value": "3.85"
				}, {
				"threshold": "1500000",
				"value": "3.98"
				}, {
				"threshold": "2000000",
				"value": "4.45"
				}]
			}, {
			"threshold": "92.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "2.32"
				}, {
				"threshold": "300000",
				"value": "2.78"
				}, {
				"threshold": "500000",
				"value": "2.78"
				}, {
				"threshold": "600000",
				"value": "3.35"
				}, {
				"threshold": "750000",
				"value": "3.56"
				}, {
				"threshold": "1000000",
				"value": "4.34"
				}, {
				"threshold": "1500000",
				"value": "4.57"
				}, {
				"threshold": "2000000",
				"value": "4.74"
				}]
			}, {
			"threshold": "93.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "2.46"
				}, {
				"threshold": "300000",
				"value": "2.81"
				}, {
				"threshold": "500000",
				"value": "2.81"
				}, {
				"threshold": "600000",
				"value": "3.67"
				}, {
				"threshold": "750000",
				"value": "3.67"
				}, {
				"threshold": "1000000",
				"value": "4.34"
				}, {
				"threshold": "1500000",
				"value": "4.57"
				}, {
				"threshold": "2000000",
				"value": "4.74"
				}]
			}, {
			"threshold": "94.01",
			"includeThreshold": false,
			"entries": [{
				"threshold": "0",
				"value": "2.67"
				}, {
				"threshold": "300000",
				"value": "3.11"
				}, {
				"threshold": "500000",
				"value": "3.11"
				}, {
				"threshold": "600000",
				"value": "3.87"
				}, {
				"threshold": "750000",
				"value": "3.87"
				}, {
				"threshold": "1000000",
				"value": "4.43"
				}, {
				"threshold": "1500000",
				"value": "4.57"
				}, {
				"threshold": "2000000",
				"value": "5.03"
				}]
			}]
	},
	"X055": [{
		"typeCode": "Medico 1",
		"X211": "0.8",
		"Limit": "0.9",
		"X212": "0.9",
		"X213": "0.9",
		"X214": "0.8",
		"X218": "0.8",
		"X219": "0.9",
		"X220": "0.9",
		"X221": "0.9",
		"X310": true
		}, {
		"typeCode": "Medico 2",
		"X211": "0.8",
		"Limit": "0.95",
		"X212": "0.9",
		"X213": "0.9",
		"X214": "0.8",
		"X218": "0.8",
		"X219": "0.95",
		"X220": "0.95",
		"X221": "0.95",
		"X310": true
		}, {
		"typeCode": "Professional",
		"X211": "0.8",
		"Limit": "0.9",
		"X212": "0.9",
		"X213": "0.9",
		"X214": "0.8",
		"X218": "0.8",
		"X219": "0.9",
		"X220": "0.9",
		"X221": "0.9",
		"X310": true
		}, {
		"typeCode": "Staff",
		"X211": "0.8",
		"Limit": "0.9",
		"X212": "0.9",
		"X213": "0.9",
		"X214": "0.9",
		"X218": "0.8",
		"X219": "0.9",
		"X220": "0.9",
		"X221": "0.9",
		"X289": "1800000",
		"X290": "2000000",
		"X310": true
		}, {
		"typeCode": "Craca",
		"X211": "0.8",
		"Limit": "0.95",
		"X212": "0.9",
		"X213": "0.9",
		"X214": "0.9",
		"X218": "0.8",
		"X219": "0.95",
		"X220": "0.95",
		"X221": "0.95",
		"X291": true,
		"X292": "2000000",
		"X310": false
		}],
	"lmiStampDutyRate": {
		"act": "0",
		"nsw": "0",
		"nt": "0.1",
		"qld": "0.09",
		"sa": "0.11",
		"tas": "0.1",
		"vic": "0.1",
		"wa": "0.1"
	},
	"X050": [{
		"repaymentTypeCode": "interestOnly",
		"repaymentRate": "0"
		}, {
		"repaymentTypeCode": "interestInAdvance",
		"repaymentRate": "0"
		}, {
		"repaymentTypeCode": "principalAndInterest",
		"repaymentRate": "0"
		}, {
		"repaymentTypeCode": "lineOfCredit",
		"repaymentRate": "0"
		}],
	"X051": [{
		"predominantPurpose": "New Motor Car",
		"purposeCode": "100",
		"additionalFund": true,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Used Motor Car",
		"purposeCode": "101",
		"additionalFund": true,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Motor Cycles",
		"purposeCode": "103",
		"additionalFund": true,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Boats or Caravans",
		"purposeCode": "104",
		"additionalFund": true,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Residential Land",
		"purposeCode": "120",
		"additionalFund": false,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Household/Personal",
		"purposeCode": "140",
		"additionalFund": true,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Travel Holidays",
		"purposeCode": "160",
		"additionalFund": true,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Refinance Existing ANZ Loan",
		"purposeCode": "371",
		"additionalFund": false,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Purch Estab - Investment Property",
		"purposeCode": "180",
		"additionalFund": false,
		"investment": true,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Purch New - Investment Property",
		"purposeCode": "180",
		"additionalFund": false,
		"investment": true,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Investment Land",
		"purposeCode": "180",
		"additionalFund": false,
		"investment": true,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Investment Property - Improvements",
		"purposeCode": "180",
		"additionalFund": true,
		"investment": true,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Construction Investment Property",
		"purposeCode": "180",
		"additionalFund": false,
		"investment": true,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Refinance Investment Loan",
		"purposeCode": "180",
		"additionalFund": false,
		"investment": true,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Investments",
		"purposeCode": "185",
		"additionalFund": true,
		"investment": true,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Refinance Non-ANZ investment loan",
		"purposeCode": "190",
		"additionalFund": false,
		"investment": true,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Construction-Not 1st Home",
		"purposeCode": "300",
		"additionalFund": false,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Construction-1st Home",
		"purposeCode": "301",
		"additionalFund": false,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Purch New Home-Not 1st Home",
		"purposeCode": "320",
		"additionalFund": false,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Purch New Home-1st Home",
		"purposeCode": "321",
		"additionalFund": false,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Purch Estab Home-Not 1st Home",
		"purposeCode": "340",
		"additionalFund": false,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Purch Estab Home-1st Home",
		"purposeCode": "341",
		"additionalFund": false,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Home - Improvements",
		"purposeCode": "360",
		"additionalFund": true,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}, {
		"predominantPurpose": "Refinance Non-ANZ Loan",
		"purposeCode": "370",
		"additionalFund": false,
		"investment": false,
		"investmentRate": "0",
		"purposeRate": "0"
		}],
	"X052": [{
		"employmentStatus": "Full Time",
		"employmentRate": "0"
		}, {
		"employmentStatus": "Part Time",
		"employmentRate": "0"
		}, {
		"employmentStatus": "Temp",
		"employmentRate": "0"
		}, {
		"employmentStatus": "Contractor",
		"employmentRate": "0"
		}, {
		"employmentStatus": "Casual",
		"employmentRate": "0"
		}, {
		"employmentStatus": "SE - Sole Trader",
		"employmentRate": "0"
		}, {
		"employmentStatus": "SE - Partnership",
		"employmentRate": "0"
		}, {
		"employmentStatus": "SE - Trust",
		"employmentRate": "0"
		}, {
		"employmentStatus": "SE - Company",
		"employmentRate": "0"
		}, {
		"employmentStatus": "SE - Multi Entity",
		"employmentRate": "0"
		}, {
		"employmentStatus": "Not Employed",
		"employmentRate": "0"
		}],
	"X057": [{
		"SYSTEM": "HOLMES",
		"PREVIOUS COVER": "FULL",
		"LOCATION_RATE": "0"
		}, {
		"SYSTEM": "HOLMES",
		"PREVIOUS COVER": "TOP",
		"INVESTMENT": false,
		"POSTCODE_MIN": "2000",
		"POSTCODE_MAX": "2999",
		"LVR_MAX": "0.85",
		"LOCATION_RATE": "0"
		}, {
		"SYSTEM": "HOLMES",
		"PREVIOUS COVER": "NONE",
		"INVESTMENT": false,
		"POSTCODE_MIN": "2000",
		"POSTCODE_MAX": "2999",
		"LVR_MAX": "0.85",
		"LOCATION_RATE": "0"
		}, {
		"SYSTEM": "HOLMES",
		"LOCATION_RATE": "0"
		}, {
		"SYSTEM": "SHERLOCK",
		"LOCATION_RATE": "0"
		}],
	"effectiveDatePostcodes": "2024-12-08T00:00:00Z",
	"X054": [{
		"postcode": "0800",
		"state": "NT",
		"locality": "DARWIN",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "0810",
		"state": "NT",
		"locality": "ALAWA",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "0812",
		"state": "NT",
		"locality": "ANULA",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "0820",
		"state": "NT",
		"locality": "BAYVIEW",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "0822",
		"state": "NT",
		"locality": "LAMBELLS LAGOON",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "0828",
		"state": "NT",
		"locality": "BERRIMAH",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "0829",
		"state": "NT",
		"locality": "HOLTZE",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "0830",
		"state": "NT",
		"locality": "ARCHER",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "0832",
		"state": "NT",
		"locality": "BAKEWELL",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "0834",
		"state": "NT",
		"locality": "VIRGINIA",
		"X065": "Category 2",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0835",
		"state": "NT",
		"locality": "HOWARD SPRINGS",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0836",
		"state": "NT",
		"locality": "GIRRAWEEN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0837",
		"state": "NT",
		"locality": "MANTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0838",
		"state": "NT",
		"locality": "BERRY SPRINGS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0839",
		"state": "NT",
		"locality": "COOLALINGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "0840",
		"state": "NT",
		"locality": "DUNDEE BEACH",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0841",
		"state": "NT",
		"locality": "DARWIN RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0845",
		"state": "NT",
		"locality": "BATCHELOR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0846",
		"state": "NT",
		"locality": "ADELAIDE RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "0847",
		"state": "NT",
		"locality": "PINE CREEK",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "0850",
		"state": "NT",
		"locality": "COSSACK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0852",
		"state": "NT",
		"locality": "KATHERINE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "0853",
		"state": "NT",
		"locality": "TINDAL",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0854",
		"state": "NT",
		"locality": "BORROLOOLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0860",
		"state": "NT",
		"locality": "TENNANT CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0862",
		"state": "NT",
		"locality": "CALVERT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0870",
		"state": "NT",
		"locality": "ALICE SPRINGS",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0872",
		"state": "NT",
		"locality": "YULARA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0873",
		"state": "NT",
		"locality": "ARUMBERA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0874",
		"state": "NT",
		"locality": "IRLPME",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0875",
		"state": "NT",
		"locality": "FLYNN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "0880",
		"state": "NT",
		"locality": "GAPUWIYAK",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "0885",
		"state": "NT",
		"locality": "ALYANGULA",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "0886",
		"state": "NT",
		"locality": "JABIRU",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2000",
		"state": "NSW",
		"locality": "BARANGAROO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2006",
		"state": "NSW",
		"locality": "SYDNEY UNIVERSITY",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2007",
		"state": "NSW",
		"locality": "BROADWAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2008",
		"state": "NSW",
		"locality": "CHIPPENDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2009",
		"state": "NSW",
		"locality": "PYRMONT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2010",
		"state": "NSW",
		"locality": "DARLINGHURST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2011",
		"state": "NSW",
		"locality": "ELIZABETH BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2015",
		"state": "NSW",
		"locality": "ALEXANDRIA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2016",
		"state": "NSW",
		"locality": "REDFERN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2017",
		"state": "NSW",
		"locality": "WATERLOO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2018",
		"state": "NSW",
		"locality": "EASTLAKES",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2019",
		"state": "NSW",
		"locality": "BANKSMEADOW",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2020",
		"state": "NSW",
		"locality": "MASCOT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2021",
		"state": "NSW",
		"locality": "CENTENNIAL PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2022",
		"state": "NSW",
		"locality": "BONDI JUNCTION",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2023",
		"state": "NSW",
		"locality": "BELLEVUE HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "8",
		"X073": "Metropolitan"
		}, {
		"postcode": "2024",
		"state": "NSW",
		"locality": "BRONTE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "6",
		"X073": "Metropolitan"
		}, {
		"postcode": "2025",
		"state": "NSW",
		"locality": "WOOLLAHRA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "6",
		"X073": "Metropolitan"
		}, {
		"postcode": "2026",
		"state": "NSW",
		"locality": "BONDI",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "6",
		"X073": "Metropolitan"
		}, {
		"postcode": "2027",
		"state": "NSW",
		"locality": "DARLING POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "8",
		"X073": "Metropolitan"
		}, {
		"postcode": "2028",
		"state": "NSW",
		"locality": "DOUBLE BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "8",
		"X073": "Metropolitan"
		}, {
		"postcode": "2029",
		"state": "NSW",
		"locality": "ROSE BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "8",
		"X073": "Metropolitan"
		}, {
		"postcode": "2030",
		"state": "NSW",
		"locality": "DOVER HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "8",
		"X073": "Metropolitan"
		}, {
		"postcode": "2031",
		"state": "NSW",
		"locality": "CLOVELLY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2032",
		"state": "NSW",
		"locality": "DACEYVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2033",
		"state": "NSW",
		"locality": "KENSINGTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2034",
		"state": "NSW",
		"locality": "COOGEE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2035",
		"state": "NSW",
		"locality": "MAROUBRA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2036",
		"state": "NSW",
		"locality": "CHIFLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2037",
		"state": "NSW",
		"locality": "FOREST LODGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2038",
		"state": "NSW",
		"locality": "ANNANDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2039",
		"state": "NSW",
		"locality": "ROZELLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2040",
		"state": "NSW",
		"locality": "LEICHHARDT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2041",
		"state": "NSW",
		"locality": "BALMAIN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2042",
		"state": "NSW",
		"locality": "ENMORE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2043",
		"state": "NSW",
		"locality": "ERSKINEVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2044",
		"state": "NSW",
		"locality": "ST PETERS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2045",
		"state": "NSW",
		"locality": "HABERFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2046",
		"state": "NSW",
		"locality": "ABBOTSFORD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2047",
		"state": "NSW",
		"locality": "DRUMMOYNE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2048",
		"state": "NSW",
		"locality": "STANMORE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2049",
		"state": "NSW",
		"locality": "LEWISHAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2050",
		"state": "NSW",
		"locality": "CAMPERDOWN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2060",
		"state": "NSW",
		"locality": "HMAS PLATYPUS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2061",
		"state": "NSW",
		"locality": "KIRRIBILLI",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2062",
		"state": "NSW",
		"locality": "CAMMERAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2063",
		"state": "NSW",
		"locality": "NORTHBRIDGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "6",
		"X073": "Metropolitan"
		}, {
		"postcode": "2064",
		"state": "NSW",
		"locality": "ARTARMON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2065",
		"state": "NSW",
		"locality": "CROWS NEST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2066",
		"state": "NSW",
		"locality": "LANE COVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2067",
		"state": "NSW",
		"locality": "CHATSWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2068",
		"state": "NSW",
		"locality": "CASTLECRAG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2069",
		"state": "NSW",
		"locality": "CASTLE COVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2070",
		"state": "NSW",
		"locality": "EAST LINDFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2071",
		"state": "NSW",
		"locality": "EAST KILLARA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2072",
		"state": "NSW",
		"locality": "GORDON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2073",
		"state": "NSW",
		"locality": "PYMBLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2074",
		"state": "NSW",
		"locality": "NORTH TURRAMURRA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2075",
		"state": "NSW",
		"locality": "ST IVES",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2076",
		"state": "NSW",
		"locality": "NORMANHURST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2077",
		"state": "NSW",
		"locality": "ASQUITH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2079",
		"state": "NSW",
		"locality": "MOUNT COLAH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2080",
		"state": "NSW",
		"locality": "MOUNT KURING-GAI",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2081",
		"state": "NSW",
		"locality": "BEROWRA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2082",
		"state": "NSW",
		"locality": "BEROWRA CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2083",
		"state": "NSW",
		"locality": "BAR POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2084",
		"state": "NSW",
		"locality": "COTTAGE POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2085",
		"state": "NSW",
		"locality": "BELROSE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2086",
		"state": "NSW",
		"locality": "FRENCHS FOREST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2087",
		"state": "NSW",
		"locality": "FORESTVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2088",
		"state": "NSW",
		"locality": "MOSMAN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "8",
		"X073": "Metropolitan"
		}, {
		"postcode": "2089",
		"state": "NSW",
		"locality": "KURRABA POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2090",
		"state": "NSW",
		"locality": "CREMORNE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "6",
		"X073": "Metropolitan"
		}, {
		"postcode": "2092",
		"state": "NSW",
		"locality": "SEAFORTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2093",
		"state": "NSW",
		"locality": "BALGOWLAH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2094",
		"state": "NSW",
		"locality": "FAIRLIGHT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2095",
		"state": "NSW",
		"locality": "MANLY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "6",
		"X073": "Metropolitan"
		}, {
		"postcode": "2096",
		"state": "NSW",
		"locality": "CURL CURL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2097",
		"state": "NSW",
		"locality": "COLLAROY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2099",
		"state": "NSW",
		"locality": "CROMER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2100",
		"state": "NSW",
		"locality": "ALLAMBIE HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2101",
		"state": "NSW",
		"locality": "ELANORA HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2102",
		"state": "NSW",
		"locality": "WARRIEWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2103",
		"state": "NSW",
		"locality": "MONA VALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2104",
		"state": "NSW",
		"locality": "BAYVIEW",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2105",
		"state": "NSW",
		"locality": "CHURCH POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2106",
		"state": "NSW",
		"locality": "NEWPORT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2107",
		"state": "NSW",
		"locality": "AVALON BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2108",
		"state": "NSW",
		"locality": "COASTERS RETREAT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "8",
		"X073": "Metropolitan"
		}, {
		"postcode": "2110",
		"state": "NSW",
		"locality": "HUNTERS HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "6",
		"X073": "Metropolitan"
		}, {
		"postcode": "2111",
		"state": "NSW",
		"locality": "BORONIA PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2112",
		"state": "NSW",
		"locality": "DENISTONE EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2113",
		"state": "NSW",
		"locality": "BLENHEIM ROAD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2114",
		"state": "NSW",
		"locality": "DENISTONE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2115",
		"state": "NSW",
		"locality": "ERMINGTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2116",
		"state": "NSW",
		"locality": "RYDALMERE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2117",
		"state": "NSW",
		"locality": "DUNDAS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2118",
		"state": "NSW",
		"locality": "CARLINGFORD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2119",
		"state": "NSW",
		"locality": "BEECROFT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2120",
		"state": "NSW",
		"locality": "PENNANT HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2121",
		"state": "NSW",
		"locality": "EPPING",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2122",
		"state": "NSW",
		"locality": "EASTWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2125",
		"state": "NSW",
		"locality": "WEST PENNANT HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2126",
		"state": "NSW",
		"locality": "CHERRYBROOK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2127",
		"state": "NSW",
		"locality": "NEWINGTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2128",
		"state": "NSW",
		"locality": "SILVERWATER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2130",
		"state": "NSW",
		"locality": "SUMMER HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2131",
		"state": "NSW",
		"locality": "ASHFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2132",
		"state": "NSW",
		"locality": "CROYDON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2133",
		"state": "NSW",
		"locality": "CROYDON PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2134",
		"state": "NSW",
		"locality": "BURWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2135",
		"state": "NSW",
		"locality": "STRATHFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2136",
		"state": "NSW",
		"locality": "BURWOOD HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2137",
		"state": "NSW",
		"locality": "BREAKFAST POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2138",
		"state": "NSW",
		"locality": "CONCORD WEST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2140",
		"state": "NSW",
		"locality": "HOMEBUSH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2141",
		"state": "NSW",
		"locality": "BERALA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2142",
		"state": "NSW",
		"locality": "BLAXCELL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2143",
		"state": "NSW",
		"locality": "BIRRONG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2144",
		"state": "NSW",
		"locality": "AUBURN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2145",
		"state": "NSW",
		"locality": "CONSTITUTION HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2146",
		"state": "NSW",
		"locality": "OLD TOONGABBIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2147",
		"state": "NSW",
		"locality": "KINGS LANGLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2148",
		"state": "NSW",
		"locality": "ARNDELL PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2150",
		"state": "NSW",
		"locality": "HARRIS PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2151",
		"state": "NSW",
		"locality": "NORTH PARRAMATTA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2152",
		"state": "NSW",
		"locality": "NORTHMEAD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2153",
		"state": "NSW",
		"locality": "BAULKHAM HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2154",
		"state": "NSW",
		"locality": "CASTLE HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2155",
		"state": "NSW",
		"locality": "BEAUMONT HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2156",
		"state": "NSW",
		"locality": "ANNANGROVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2157",
		"state": "NSW",
		"locality": "CANOELANDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2158",
		"state": "NSW",
		"locality": "DURAL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2159",
		"state": "NSW",
		"locality": "ARCADIA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2160",
		"state": "NSW",
		"locality": "MERRYLANDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2161",
		"state": "NSW",
		"locality": "GUILDFORD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2162",
		"state": "NSW",
		"locality": "CHESTER HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2163",
		"state": "NSW",
		"locality": "CARRAMAR",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2164",
		"state": "NSW",
		"locality": "SMITHFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2165",
		"state": "NSW",
		"locality": "FAIRFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2166",
		"state": "NSW",
		"locality": "CABRAMATTA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2167",
		"state": "NSW",
		"locality": "GLENFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2168",
		"state": "NSW",
		"locality": "ASHCROFT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2170",
		"state": "NSW",
		"locality": "CASULA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2171",
		"state": "NSW",
		"locality": "CARNES HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2172",
		"state": "NSW",
		"locality": "PLEASURE POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2173",
		"state": "NSW",
		"locality": "HOLSWORTHY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2174",
		"state": "NSW",
		"locality": "EDMONDSON PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2175",
		"state": "NSW",
		"locality": "HORSLEY PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2176",
		"state": "NSW",
		"locality": "ABBOTSBURY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2177",
		"state": "NSW",
		"locality": "BONNYRIGG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2178",
		"state": "NSW",
		"locality": "CECIL PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2179",
		"state": "NSW",
		"locality": "AUSTRAL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2190",
		"state": "NSW",
		"locality": "CHULLORA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2191",
		"state": "NSW",
		"locality": "BELFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2192",
		"state": "NSW",
		"locality": "BELMORE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2193",
		"state": "NSW",
		"locality": "ASHBURY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2194",
		"state": "NSW",
		"locality": "CAMPSIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2195",
		"state": "NSW",
		"locality": "LAKEMBA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2196",
		"state": "NSW",
		"locality": "PUNCHBOWL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2197",
		"state": "NSW",
		"locality": "BASS HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2198",
		"state": "NSW",
		"locality": "GEORGES HALL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2199",
		"state": "NSW",
		"locality": "YAGOONA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2200",
		"state": "NSW",
		"locality": "BANKSTOWN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2203",
		"state": "NSW",
		"locality": "DULWICH HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2204",
		"state": "NSW",
		"locality": "MARRICKVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2205",
		"state": "NSW",
		"locality": "ARNCLIFFE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2206",
		"state": "NSW",
		"locality": "CLEMTON PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2207",
		"state": "NSW",
		"locality": "BARDWELL PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2208",
		"state": "NSW",
		"locality": "KINGSGROVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2209",
		"state": "NSW",
		"locality": "BEVERLY HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2210",
		"state": "NSW",
		"locality": "LUGARNO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2211",
		"state": "NSW",
		"locality": "PADSTOW",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2212",
		"state": "NSW",
		"locality": "REVESBY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2213",
		"state": "NSW",
		"locality": "EAST HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2214",
		"state": "NSW",
		"locality": "MILPERRA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2216",
		"state": "NSW",
		"locality": "BANKSIA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2217",
		"state": "NSW",
		"locality": "BEVERLEY PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2218",
		"state": "NSW",
		"locality": "ALLAWAH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2219",
		"state": "NSW",
		"locality": "DOLLS POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2220",
		"state": "NSW",
		"locality": "HURSTVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2221",
		"state": "NSW",
		"locality": "BLAKEHURST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2222",
		"state": "NSW",
		"locality": "PENSHURST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2223",
		"state": "NSW",
		"locality": "MORTDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2224",
		"state": "NSW",
		"locality": "KANGAROO POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2225",
		"state": "NSW",
		"locality": "OYSTER BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2226",
		"state": "NSW",
		"locality": "BONNET BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2227",
		"state": "NSW",
		"locality": "GYMEA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2228",
		"state": "NSW",
		"locality": "MIRANDA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2229",
		"state": "NSW",
		"locality": "CARINGBAH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2230",
		"state": "NSW",
		"locality": "BUNDEENA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2231",
		"state": "NSW",
		"locality": "KURNELL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2232",
		"state": "NSW",
		"locality": "GRAYS POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2233",
		"state": "NSW",
		"locality": "ENGADINE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2234",
		"state": "NSW",
		"locality": "ALFORDS POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2250",
		"state": "NSW",
		"locality": "BUCKETTY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2251",
		"state": "NSW",
		"locality": "AVOCA BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2256",
		"state": "NSW",
		"locality": "BLACKWALL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2257",
		"state": "NSW",
		"locality": "BOOKER BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2258",
		"state": "NSW",
		"locality": "FOUNTAINDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2259",
		"state": "NSW",
		"locality": "ALISON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X069": "Low",
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2260",
		"state": "NSW",
		"locality": "ERINA HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2261",
		"state": "NSW",
		"locality": "BATEAU BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2262",
		"state": "NSW",
		"locality": "BLUE HAVEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2263",
		"state": "NSW",
		"locality": "CANTON BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2264",
		"state": "NSW",
		"locality": "BALCOLYN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2265",
		"state": "NSW",
		"locality": "COORANBONG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2267",
		"state": "NSW",
		"locality": "WANGI WANGI",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2278",
		"state": "NSW",
		"locality": "BARNSLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2280",
		"state": "NSW",
		"locality": "BELMONT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2281",
		"state": "NSW",
		"locality": "BLACKSMITHS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2282",
		"state": "NSW",
		"locality": "ELEEBANA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2283",
		"state": "NSW",
		"locality": "ARCADIA VALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2284",
		"state": "NSW",
		"locality": "ARGENTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2285",
		"state": "NSW",
		"locality": "CAMERON PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2286",
		"state": "NSW",
		"locality": "HOLMESVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2287",
		"state": "NSW",
		"locality": "BIRMINGHAM GARDENS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2289",
		"state": "NSW",
		"locality": "ADAMSTOWN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2290",
		"state": "NSW",
		"locality": "BENNETTS GREEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2291",
		"state": "NSW",
		"locality": "MEREWETHER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2292",
		"state": "NSW",
		"locality": "BROADMEADOW",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2293",
		"state": "NSW",
		"locality": "MARYVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2294",
		"state": "NSW",
		"locality": "CARRINGTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2295",
		"state": "NSW",
		"locality": "FERN BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2296",
		"state": "NSW",
		"locality": "ISLINGTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2297",
		"state": "NSW",
		"locality": "TIGHES HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2298",
		"state": "NSW",
		"locality": "GEORGETOWN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2299",
		"state": "NSW",
		"locality": "JESMOND",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2300",
		"state": "NSW",
		"locality": "BAR BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2302",
		"state": "NSW",
		"locality": "NEWCASTLE WEST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2303",
		"state": "NSW",
		"locality": "HAMILTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2304",
		"state": "NSW",
		"locality": "KOORAGANG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2305",
		"state": "NSW",
		"locality": "KOTARA EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2306",
		"state": "NSW",
		"locality": "WINDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2307",
		"state": "NSW",
		"locality": "SHORTLAND",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2308",
		"state": "NSW",
		"locality": "UNIVERSITY OF NEWCASTLE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2309",
		"state": "NSW",
		"locality": "DANGAR",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2311",
		"state": "NSW",
		"locality": "ALLYNBROOK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2312",
		"state": "NSW",
		"locality": "MINIMBAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2315",
		"state": "NSW",
		"locality": "CORLETTE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2316",
		"state": "NSW",
		"locality": "ANNA BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2317",
		"state": "NSW",
		"locality": "SALAMANDER BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2318",
		"state": "NSW",
		"locality": "CAMPVALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2319",
		"state": "NSW",
		"locality": "LEMON TREE PASSAGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2320",
		"state": "NSW",
		"locality": "ABERGLASSLYN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2321",
		"state": "NSW",
		"locality": "BERRY PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2322",
		"state": "NSW",
		"locality": "BERESFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2323",
		"state": "NSW",
		"locality": "ASHTONFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2324",
		"state": "NSW",
		"locality": "BALICKERA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2325",
		"state": "NSW",
		"locality": "ABERDARE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2326",
		"state": "NSW",
		"locality": "ABERMAIN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2327",
		"state": "NSW",
		"locality": "KURRI KURRI",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2328",
		"state": "NSW",
		"locality": "BUREEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2329",
		"state": "NSW",
		"locality": "CASSILIS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2330",
		"state": "NSW",
		"locality": "APPLETREE FLAT",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2333",
		"state": "NSW",
		"locality": "BAERAMI",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2334",
		"state": "NSW",
		"locality": "GRETA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2335",
		"state": "NSW",
		"locality": "BELFORD",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2336",
		"state": "NSW",
		"locality": "ABERDEEN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2337",
		"state": "NSW",
		"locality": "BELLTREES",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2338",
		"state": "NSW",
		"locality": "ARDGLEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2339",
		"state": "NSW",
		"locality": "BIG JACKS CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2340",
		"state": "NSW",
		"locality": "APPLEBY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2341",
		"state": "NSW",
		"locality": "WERRIS CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2342",
		"state": "NSW",
		"locality": "CURRABUBULA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2343",
		"state": "NSW",
		"locality": "BLACKVILLE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2344",
		"state": "NSW",
		"locality": "DURI",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2345",
		"state": "NSW",
		"locality": "ATTUNGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2346",
		"state": "NSW",
		"locality": "BORAH CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2347",
		"state": "NSW",
		"locality": "BANOON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2350",
		"state": "NSW",
		"locality": "ABERFOYLE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2352",
		"state": "NSW",
		"locality": "KOOTINGAL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2353",
		"state": "NSW",
		"locality": "MOONBI",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2354",
		"state": "NSW",
		"locality": "KENTUCKY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2355",
		"state": "NSW",
		"locality": "BENDEMEER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2356",
		"state": "NSW",
		"locality": "GWABEGAR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2357",
		"state": "NSW",
		"locality": "BOMERA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2358",
		"state": "NSW",
		"locality": "ARDING",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2359",
		"state": "NSW",
		"locality": "ABERDEEN",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "AUBURN VALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "BRODIES PLAINS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "BUKKULLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "CHERRY TREE HILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "COPETON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "ELSMORE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "GILGAI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "GRAMAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "GUM FLAT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "HOWELL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "INVERELL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "KINGS PLAINS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "LITTLE PLAIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "LONG PLAIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "MOUNT RUSSELL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "NEWSTEAD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "NULLAMANNA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "OAKWOOD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "PARADISE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2360",
		"state": "NSW",
		"locality": "ROB ROY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2361",
		"state": "NSW",
		"locality": "ASHFORD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2365",
		"state": "NSW",
		"locality": "BACKWATER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2369",
		"state": "NSW",
		"locality": "OLD MILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2370",
		"state": "NSW",
		"locality": "BALD NOB",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2371",
		"state": "NSW",
		"locality": "CAPOOMPETA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2372",
		"state": "NSW",
		"locality": "BACK CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2379",
		"state": "NSW",
		"locality": "GOOLHI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2380",
		"state": "NSW",
		"locality": "BLUE VALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2381",
		"state": "NSW",
		"locality": "BREEZA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2382",
		"state": "NSW",
		"locality": "BOGGABRI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2386",
		"state": "NSW",
		"locality": "BURREN JUNCTION",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2387",
		"state": "NSW",
		"locality": "BULYEROI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2388",
		"state": "NSW",
		"locality": "BOOLCARROLL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2390",
		"state": "NSW",
		"locality": "BAAN BAA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2395",
		"state": "NSW",
		"locality": "BINNAWAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2396",
		"state": "NSW",
		"locality": "BARADINE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2397",
		"state": "NSW",
		"locality": "BELLATA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2398",
		"state": "NSW",
		"locality": "GURLEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2399",
		"state": "NSW",
		"locality": "BINIGUY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2400",
		"state": "NSW",
		"locality": "ASHLEY",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2401",
		"state": "NSW",
		"locality": "GRAVESEND",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2402",
		"state": "NSW",
		"locality": "COOLATAI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2403",
		"state": "NSW",
		"locality": "BALFOURS PEAK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2404",
		"state": "NSW",
		"locality": "BANGHEET",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2405",
		"state": "NSW",
		"locality": "BOOMI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2406",
		"state": "NSW",
		"locality": "MUNGINDI",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2408",
		"state": "NSW",
		"locality": "BLUE NOBBY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2409",
		"state": "NSW",
		"locality": "BOGGABILLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2410",
		"state": "NSW",
		"locality": "TWIN RIVERS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2411",
		"state": "NSW",
		"locality": "CROPPA CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2415",
		"state": "NSW",
		"locality": "MONKERAI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2420",
		"state": "NSW",
		"locality": "ALISON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2421",
		"state": "NSW",
		"locality": "FISHERS HILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2422",
		"state": "NSW",
		"locality": "BACK CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2423",
		"state": "NSW",
		"locality": "BOMBAH POINT",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2424",
		"state": "NSW",
		"locality": "CAFFREYS FLAT",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2425",
		"state": "NSW",
		"locality": "ALLWORTH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2426",
		"state": "NSW",
		"locality": "COOPERNOOK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2427",
		"state": "NSW",
		"locality": "CROWDY HEAD",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2428",
		"state": "NSW",
		"locality": "BLUEYS BEACH",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2429",
		"state": "NSW",
		"locality": "BOBIN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2430",
		"state": "NSW",
		"locality": "BLACK HEAD",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2431",
		"state": "NSW",
		"locality": "ARAKOON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2439",
		"state": "NSW",
		"locality": "BATAR CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2440",
		"state": "NSW",
		"locality": "ALDAVILLA",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2441",
		"state": "NSW",
		"locality": "ALLGOMERA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2443",
		"state": "NSW",
		"locality": "BOBS CREEK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2444",
		"state": "NSW",
		"locality": "BLACKMANS POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2445",
		"state": "NSW",
		"locality": "BONNY HILLS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2446",
		"state": "NSW",
		"locality": "BAGNOO",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2447",
		"state": "NSW",
		"locality": "BAKERS CREEK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2448",
		"state": "NSW",
		"locality": "HYLAND PARK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2449",
		"state": "NSW",
		"locality": "ARGENTS HILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2450",
		"state": "NSW",
		"locality": "BOAMBEE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2452",
		"state": "NSW",
		"locality": "BOAMBEE EAST",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2453",
		"state": "NSW",
		"locality": "BIELSDOWN HILLS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2454",
		"state": "NSW",
		"locality": "BELLINGEN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2455",
		"state": "NSW",
		"locality": "URUNGA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2456",
		"state": "NSW",
		"locality": "ARRAWARRA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2460",
		"state": "NSW",
		"locality": "ALUMY CREEK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2462",
		"state": "NSW",
		"locality": "CALLIOPE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2463",
		"state": "NSW",
		"locality": "ASHBY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2464",
		"state": "NSW",
		"locality": "ANGOURIE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2465",
		"state": "NSW",
		"locality": "HARWOOD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2466",
		"state": "NSW",
		"locality": "ILUKA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2469",
		"state": "NSW",
		"locality": "ALICE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2470",
		"state": "NSW",
		"locality": "BABYL CREEK",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2471",
		"state": "NSW",
		"locality": "BORA RIDGE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2472",
		"state": "NSW",
		"locality": "BROADWATER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2473",
		"state": "NSW",
		"locality": "BUNDJALUNG",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2474",
		"state": "NSW",
		"locality": "AFTERLEE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2475",
		"state": "NSW",
		"locality": "TOOLOOM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2476",
		"state": "NSW",
		"locality": "ACACIA CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2477",
		"state": "NSW",
		"locality": "ALSTONVALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2478",
		"state": "NSW",
		"locality": "BALLINA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2479",
		"state": "NSW",
		"locality": "BANGALOW",
		"X065": "Category 3",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2480",
		"state": "NSW",
		"locality": "BENTLEY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2481",
		"state": "NSW",
		"locality": "BROKEN HEAD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2482",
		"state": "NSW",
		"locality": "GOONENGERRY",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2483",
		"state": "NSW",
		"locality": "BILLINUDGEL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2484",
		"state": "NSW",
		"locality": "BACK CREEK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2485",
		"state": "NSW",
		"locality": "TWEED HEADS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2486",
		"state": "NSW",
		"locality": "BANORA POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2487",
		"state": "NSW",
		"locality": "CASUARINA",
		"X065": "Category 1",
		"X066": "Regional",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2488",
		"state": "NSW",
		"locality": "BOGANGAR",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2489",
		"state": "NSW",
		"locality": "HASTINGS POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2490",
		"state": "NSW",
		"locality": "NORTH TUMBULGUM",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2500",
		"state": "NSW",
		"locality": "CONISTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2502",
		"state": "NSW",
		"locality": "CRINGILA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2505",
		"state": "NSW",
		"locality": "PORT KEMBLA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2506",
		"state": "NSW",
		"locality": "BERKELEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2508",
		"state": "NSW",
		"locality": "COALCLIFF",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2515",
		"state": "NSW",
		"locality": "AUSTINMER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2516",
		"state": "NSW",
		"locality": "BULLI",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2517",
		"state": "NSW",
		"locality": "RUSSELL VALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2518",
		"state": "NSW",
		"locality": "BELLAMBI",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2519",
		"state": "NSW",
		"locality": "BALGOWNIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2525",
		"state": "NSW",
		"locality": "FIGTREE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2526",
		"state": "NSW",
		"locality": "CORDEAUX",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2527",
		"state": "NSW",
		"locality": "ALBION PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2528",
		"state": "NSW",
		"locality": "BARRACK HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2529",
		"state": "NSW",
		"locality": "BLACKBUTT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2530",
		"state": "NSW",
		"locality": "AVONDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2533",
		"state": "NSW",
		"locality": "BOMBO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2534",
		"state": "NSW",
		"locality": "BROUGHTON VILLAGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2535",
		"state": "NSW",
		"locality": "BACK FOREST",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2536",
		"state": "NSW",
		"locality": "BATEHAVEN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2537",
		"state": "NSW",
		"locality": "BERGALIA",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2538",
		"state": "NSW",
		"locality": "BROOMAN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2539",
		"state": "NSW",
		"locality": "BAWLEY POINT",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2540",
		"state": "NSW",
		"locality": "BAMARANG",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2541",
		"state": "NSW",
		"locality": "BANGALEE",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2545",
		"state": "NSW",
		"locality": "BELOWRA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2546",
		"state": "NSW",
		"locality": "AKOLELE",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2548",
		"state": "NSW",
		"locality": "BERRAMBOOL",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2549",
		"state": "NSW",
		"locality": "BALD HILLS",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2550",
		"state": "NSW",
		"locality": "ANGLEDALE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2551",
		"state": "NSW",
		"locality": "BOYDTOWN",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2555",
		"state": "NSW",
		"locality": "BADGERYS CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2556",
		"state": "NSW",
		"locality": "BRINGELLY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2557",
		"state": "NSW",
		"locality": "CATHERINE FIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2558",
		"state": "NSW",
		"locality": "EAGLE VALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2559",
		"state": "NSW",
		"locality": "BLAIRMOUNT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2560",
		"state": "NSW",
		"locality": "AIRDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2563",
		"state": "NSW",
		"locality": "MENANGLE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2564",
		"state": "NSW",
		"locality": "GLENQUARIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2565",
		"state": "NSW",
		"locality": "BARDIA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2566",
		"state": "NSW",
		"locality": "BOW BOWING",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2567",
		"state": "NSW",
		"locality": "CURRANS HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2568",
		"state": "NSW",
		"locality": "MENANGLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2569",
		"state": "NSW",
		"locality": "DOUGLAS PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2570",
		"state": "NSW",
		"locality": "BELIMBLA PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2571",
		"state": "NSW",
		"locality": "BALMORAL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2572",
		"state": "NSW",
		"locality": "LAKESLAND",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2573",
		"state": "NSW",
		"locality": "TAHMOOR",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2574",
		"state": "NSW",
		"locality": "AVON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2575",
		"state": "NSW",
		"locality": "ALPINE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2576",
		"state": "NSW",
		"locality": "BOWRAL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2577",
		"state": "NSW",
		"locality": "AVOCA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2578",
		"state": "NSW",
		"locality": "BUNDANOON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2579",
		"state": "NSW",
		"locality": "BIG HILL",
		"X065": "Category 2",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2580",
		"state": "NSW",
		"locality": "BANNABY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2581",
		"state": "NSW",
		"locality": "BELLMOUNT FOREST",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2582",
		"state": "NSW",
		"locality": "BANGO",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2583",
		"state": "NSW",
		"locality": "BIGGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2584",
		"state": "NSW",
		"locality": "BINALONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2585",
		"state": "NSW",
		"locality": "GALONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2586",
		"state": "NSW",
		"locality": "BOOROWA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2587",
		"state": "NSW",
		"locality": "BEGGAN BEGGAN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2588",
		"state": "NSW",
		"locality": "WALLENDBEEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2590",
		"state": "NSW",
		"locality": "BETHUNGRA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2594",
		"state": "NSW",
		"locality": "BARWANG",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2600",
		"state": "ACT",
		"locality": "BARTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2601",
		"state": "ACT",
		"locality": "ACTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2602",
		"state": "ACT",
		"locality": "AINSLIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2603",
		"state": "ACT",
		"locality": "FORREST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2604",
		"state": "ACT",
		"locality": "CAUSEWAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2605",
		"state": "ACT",
		"locality": "CURTIN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2606",
		"state": "ACT",
		"locality": "CHIFLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2607",
		"state": "ACT",
		"locality": "FARRER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2609",
		"state": "ACT",
		"locality": "CANBERRA AIRPORT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2611",
		"state": "ACT",
		"locality": "BIMBERI",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2612",
		"state": "ACT",
		"locality": "BRADDON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2614",
		"state": "ACT",
		"locality": "ARANDA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2615",
		"state": "ACT",
		"locality": "CHARNWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2617",
		"state": "ACT",
		"locality": "BELCONNEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2618",
		"state": "ACT",
		"locality": "HALL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2619",
		"state": "NSW",
		"locality": "JERRABOMBERRA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2620",
		"state": "NSW",
		"locality": "BEARD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2621",
		"state": "NSW",
		"locality": "ANEMBO",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2622",
		"state": "NSW",
		"locality": "ARALUEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2623",
		"state": "NSW",
		"locality": "CAPTAINS FLAT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2624",
		"state": "NSW",
		"locality": "PERISHER VALLEY",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2625",
		"state": "NSW",
		"locality": "THREDBO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2626",
		"state": "NSW",
		"locality": "BREDBO",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2627",
		"state": "NSW",
		"locality": "CRACKENBACK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2628",
		"state": "NSW",
		"locality": "AVONSIDE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2629",
		"state": "NSW",
		"locality": "ADAMINABY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2630",
		"state": "NSW",
		"locality": "ARABLE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2631",
		"state": "NSW",
		"locality": "ANDO",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2632",
		"state": "NSW",
		"locality": "BIBBENLUKE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2633",
		"state": "NSW",
		"locality": "CORROWONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2640",
		"state": "NSW",
		"locality": "ALBURY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2641",
		"state": "NSW",
		"locality": "HAMILTON VALLEY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2642",
		"state": "NSW",
		"locality": "BIDGEEMIA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2643",
		"state": "NSW",
		"locality": "HOWLONG",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2644",
		"state": "NSW",
		"locality": "BOWNA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2645",
		"state": "NSW",
		"locality": "CULLIVEL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2646",
		"state": "NSW",
		"locality": "BALLDALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2647",
		"state": "NSW",
		"locality": "MULWALA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2648",
		"state": "NSW",
		"locality": "ANABRANCH NORTH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2649",
		"state": "NSW",
		"locality": "LAUREL HILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2650",
		"state": "NSW",
		"locality": "ALFREDTOWN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2651",
		"state": "NSW",
		"locality": "FOREST HILL",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2652",
		"state": "NSW",
		"locality": "BOORGA",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2653",
		"state": "NSW",
		"locality": "BURRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2655",
		"state": "NSW",
		"locality": "FRENCH PARK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2656",
		"state": "NSW",
		"locality": "BROOKDALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2658",
		"state": "NSW",
		"locality": "HENTY",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2659",
		"state": "NSW",
		"locality": "ALMA PARK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2660",
		"state": "NSW",
		"locality": "CULCAIRN",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2661",
		"state": "NSW",
		"locality": "KAPOOKA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2663",
		"state": "NSW",
		"locality": "ERIN VALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2665",
		"state": "NSW",
		"locality": "ARDLETHAN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2666",
		"state": "NSW",
		"locality": "COMBANING",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2668",
		"state": "NSW",
		"locality": "BARMEDMAN",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2669",
		"state": "NSW",
		"locality": "ERIGOLIA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2671",
		"state": "NSW",
		"locality": "ALLEENA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2672",
		"state": "NSW",
		"locality": "CURLEW WATERS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2675",
		"state": "NSW",
		"locality": "HILLSTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2678",
		"state": "NSW",
		"locality": "CHARLES STURT UNIVERSITY",
		"X065": "NA",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2680",
		"state": "NSW",
		"locality": "BEELBANGERA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2681",
		"state": "NSW",
		"locality": "MYALL PARK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2700",
		"state": "NSW",
		"locality": "BUNDURE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2701",
		"state": "NSW",
		"locality": "BERRY JERRY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2702",
		"state": "NSW",
		"locality": "GANMAIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2703",
		"state": "NSW",
		"locality": "YANCO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2705",
		"state": "NSW",
		"locality": "BROBENAH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2706",
		"state": "NSW",
		"locality": "DARLINGTON POINT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2707",
		"state": "NSW",
		"locality": "ARGOON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2710",
		"state": "NSW",
		"locality": "BARRATTA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2711",
		"state": "NSW",
		"locality": "BOOLIGAL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2712",
		"state": "NSW",
		"locality": "BERRIGAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2713",
		"state": "NSW",
		"locality": "BLIGHTY",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2714",
		"state": "NSW",
		"locality": "ARATULA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2715",
		"state": "NSW",
		"locality": "ARUMPO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2716",
		"state": "NSW",
		"locality": "FOUR CORNERS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2717",
		"state": "NSW",
		"locality": "COOMEALLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2720",
		"state": "NSW",
		"locality": "ARGALONG",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2721",
		"state": "NSW",
		"locality": "BLAND",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2722",
		"state": "NSW",
		"locality": "BRUNGLE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2725",
		"state": "NSW",
		"locality": "STOCKINBINGAL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2726",
		"state": "NSW",
		"locality": "COONEYS CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2727",
		"state": "NSW",
		"locality": "ADJUNGBILLY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2729",
		"state": "NSW",
		"locality": "ADELONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2730",
		"state": "NSW",
		"locality": "BATLOW",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2731",
		"state": "NSW",
		"locality": "BUNNALOO",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2732",
		"state": "NSW",
		"locality": "BARHAM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2733",
		"state": "NSW",
		"locality": "DHURAGOON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2734",
		"state": "NSW",
		"locality": "CUNNINYEUK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2735",
		"state": "NSW",
		"locality": "KORALEIGH",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2736",
		"state": "NSW",
		"locality": "GOODNIGHT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2737",
		"state": "NSW",
		"locality": "EUSTON",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2738",
		"state": "NSW",
		"locality": "GOL GOL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2739",
		"state": "NSW",
		"locality": "BOEILL CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2745",
		"state": "NSW",
		"locality": "GLENMORE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2747",
		"state": "NSW",
		"locality": "CADDENS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2748",
		"state": "NSW",
		"locality": "ORCHARD HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "2749",
		"state": "NSW",
		"locality": "CASTLEREAGH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2750",
		"state": "NSW",
		"locality": "EMU HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2752",
		"state": "NSW",
		"locality": "SILVERDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2753",
		"state": "NSW",
		"locality": "AGNES BANKS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2754",
		"state": "NSW",
		"locality": "NORTH RICHMOND",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2756",
		"state": "NSW",
		"locality": "BLIGH PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2757",
		"state": "NSW",
		"locality": "KURMOND",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2758",
		"state": "NSW",
		"locality": "BERAMBING",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2759",
		"state": "NSW",
		"locality": "ERSKINE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2760",
		"state": "NSW",
		"locality": "COLYTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2761",
		"state": "NSW",
		"locality": "COLEBEE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2762",
		"state": "NSW",
		"locality": "SCHOFIELDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2763",
		"state": "NSW",
		"locality": "ACACIA GARDENS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2765",
		"state": "NSW",
		"locality": "BERKSHIRE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2766",
		"state": "NSW",
		"locality": "EASTERN CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2767",
		"state": "NSW",
		"locality": "BUNGARRIBEE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2768",
		"state": "NSW",
		"locality": "GLENWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2769",
		"state": "NSW",
		"locality": "THE PONDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2770",
		"state": "NSW",
		"locality": "BIDWILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2773",
		"state": "NSW",
		"locality": "GLENBROOK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2774",
		"state": "NSW",
		"locality": "BLAXLAND",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2775",
		"state": "NSW",
		"locality": "CENTRAL MACDONALD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2776",
		"state": "NSW",
		"locality": "FAULCONBRIDGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2777",
		"state": "NSW",
		"locality": "HAWKESBURY HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2778",
		"state": "NSW",
		"locality": "LINDEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2779",
		"state": "NSW",
		"locality": "HAZELBROOK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2780",
		"state": "NSW",
		"locality": "KATOOMBA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2782",
		"state": "NSW",
		"locality": "WENTWORTH FALLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2783",
		"state": "NSW",
		"locality": "LAWSON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2784",
		"state": "NSW",
		"locality": "BULLABURRA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2785",
		"state": "NSW",
		"locality": "BLACKHEATH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2786",
		"state": "NSW",
		"locality": "BELL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2787",
		"state": "NSW",
		"locality": "BLACK SPRINGS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2790",
		"state": "NSW",
		"locality": "BEN BULLEN",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2791",
		"state": "NSW",
		"locality": "CARCOAR",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2792",
		"state": "NSW",
		"locality": "BURNT YARDS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2793",
		"state": "NSW",
		"locality": "DARBYS FALLS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2794",
		"state": "NSW",
		"locality": "BUMBALDRY",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2795",
		"state": "NSW",
		"locality": "ABERCROMBIE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2797",
		"state": "NSW",
		"locality": "GARLAND",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2798",
		"state": "NSW",
		"locality": "FOREST REEFS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2799",
		"state": "NSW",
		"locality": "BARRY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2800",
		"state": "NSW",
		"locality": "BELGRAVIA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2803",
		"state": "NSW",
		"locality": "BENDICK MURRELL",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2804",
		"state": "NSW",
		"locality": "BILLIMARI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2805",
		"state": "NSW",
		"locality": "GOOLOOGONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2806",
		"state": "NSW",
		"locality": "EUGOWRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2807",
		"state": "NSW",
		"locality": "KOORAWATHA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2808",
		"state": "NSW",
		"locality": "WYANGALA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2809",
		"state": "NSW",
		"locality": "GREENETHORPE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2810",
		"state": "NSW",
		"locality": "BIMBI",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2817",
		"state": "NSW",
		"locality": "TOORAWEENAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2818",
		"state": "NSW",
		"locality": "BENOLONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2820",
		"state": "NSW",
		"locality": "APSLEY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2821",
		"state": "NSW",
		"locality": "BURROWAY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2822",
		"state": "NSW",
		"locality": "BALLADORAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2823",
		"state": "NSW",
		"locality": "BUNDEMAR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2824",
		"state": "NSW",
		"locality": "BEEMUNNEL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2825",
		"state": "NSW",
		"locality": "BABINDA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2826",
		"state": "NSW",
		"locality": "BOGAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2827",
		"state": "NSW",
		"locality": "BEARBONG",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2828",
		"state": "NSW",
		"locality": "ARMATREE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2829",
		"state": "NSW",
		"locality": "BILLEROY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2830",
		"state": "NSW",
		"locality": "BALLIMORE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2831",
		"state": "NSW",
		"locality": "BALLADORAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2832",
		"state": "NSW",
		"locality": "COME BY CHANCE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2833",
		"state": "NSW",
		"locality": "COLLARENEBRI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2834",
		"state": "NSW",
		"locality": "ANGLEDOOL",
		"X065": "On application",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2835",
		"state": "NSW",
		"locality": "BULLA",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2836",
		"state": "NSW",
		"locality": "WHITE CLIFFS",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2838",
		"state": "NSW",
		"locality": "GOODOOGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2839",
		"state": "NSW",
		"locality": "BREWARRINA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2840",
		"state": "NSW",
		"locality": "BOURKE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2842",
		"state": "NSW",
		"locality": "MENDOORAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2843",
		"state": "NSW",
		"locality": "COOLAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2844",
		"state": "NSW",
		"locality": "BIRRIWA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2845",
		"state": "NSW",
		"locality": "WALLERAWANG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2846",
		"state": "NSW",
		"locality": "CAPERTEE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2847",
		"state": "NSW",
		"locality": "PORTLAND",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2848",
		"state": "NSW",
		"locality": "BROGANS CREEK",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2849",
		"state": "NSW",
		"locality": "BOGEE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2850",
		"state": "NSW",
		"locality": "AARONS PASS",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2852",
		"state": "NSW",
		"locality": "BARNEYS REEF",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2864",
		"state": "NSW",
		"locality": "BOWAN PARK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2865",
		"state": "NSW",
		"locality": "BOCOBRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2866",
		"state": "NSW",
		"locality": "AMAROO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2867",
		"state": "NSW",
		"locality": "BALDRY",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2868",
		"state": "NSW",
		"locality": "BOURNEWOOD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2869",
		"state": "NSW",
		"locality": "PEAK HILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2870",
		"state": "NSW",
		"locality": "ALECTOWN",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2871",
		"state": "NSW",
		"locality": "BEDGERABONG",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2873",
		"state": "NSW",
		"locality": "ALBERT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2874",
		"state": "NSW",
		"locality": "TULLAMORE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2875",
		"state": "NSW",
		"locality": "BRUIE PLAINS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2876",
		"state": "NSW",
		"locality": "BOGAN GATE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2877",
		"state": "NSW",
		"locality": "BOBADAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2878",
		"state": "NSW",
		"locality": "IVANHOE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2879",
		"state": "NSW",
		"locality": "MENINDEE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2880",
		"state": "NSW",
		"locality": "BROKEN HILL",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "2890",
		"state": "NSW",
		"locality": "AUSTRALIAN DEFENCE FORCES",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2898",
		"state": "NSW",
		"locality": "LORD HOWE ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2899",
		"state": "NSW",
		"locality": "NORFOLK ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "2900",
		"state": "ACT",
		"locality": "GREENWAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2902",
		"state": "ACT",
		"locality": "KAMBAH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2903",
		"state": "ACT",
		"locality": "ERINDALE CENTRE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2904",
		"state": "ACT",
		"locality": "FADDEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2905",
		"state": "ACT",
		"locality": "BONYTHON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2906",
		"state": "ACT",
		"locality": "BANKS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2911",
		"state": "ACT",
		"locality": "CRACE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2912",
		"state": "ACT",
		"locality": "GUNGAHLIN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2913",
		"state": "ACT",
		"locality": "CASEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "2914",
		"state": "ACT",
		"locality": "AMAROO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "3000",
		"state": "VIC",
		"locality": "MELBOURNE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X067": "Y",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3002",
		"state": "VIC",
		"locality": "EAST MELBOURNE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X067": "Y",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3003",
		"state": "VIC",
		"locality": "WEST MELBOURNE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X067": "Y",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3004",
		"state": "VIC",
		"locality": "MELBOURNE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X067": "Y",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3005",
		"state": "VIC",
		"locality": "WORLD TRADE CENTRE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3006",
		"state": "VIC",
		"locality": "SOUTH WHARF",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X067": "Y",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3008",
		"state": "VIC",
		"locality": "DOCKLANDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X067": "Y",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3010",
		"state": "VIC",
		"locality": "UNIVERSITY OF MELBOURNE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3011",
		"state": "VIC",
		"locality": "FOOTSCRAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3012",
		"state": "VIC",
		"locality": "BROOKLYN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3013",
		"state": "VIC",
		"locality": "YARRAVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3015",
		"state": "VIC",
		"locality": "NEWPORT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3016",
		"state": "VIC",
		"locality": "WILLIAMSTOWN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3018",
		"state": "VIC",
		"locality": "ALTONA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3019",
		"state": "VIC",
		"locality": "BRAYBROOK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3020",
		"state": "VIC",
		"locality": "ALBION",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3021",
		"state": "VIC",
		"locality": "ALBANVALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3022",
		"state": "VIC",
		"locality": "ARDEER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3023",
		"state": "VIC",
		"locality": "BURNSIDE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3024",
		"state": "VIC",
		"locality": "MAMBOURIN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3025",
		"state": "VIC",
		"locality": "ALTONA EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3026",
		"state": "VIC",
		"locality": "LAVERTON NORTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3027",
		"state": "VIC",
		"locality": "WILLIAMS LANDING",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3028",
		"state": "VIC",
		"locality": "ALTONA MEADOWS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3029",
		"state": "VIC",
		"locality": "HOPPERS CROSSING",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3030",
		"state": "VIC",
		"locality": "COCOROC",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3031",
		"state": "VIC",
		"locality": "FLEMINGTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3032",
		"state": "VIC",
		"locality": "ASCOT VALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3033",
		"state": "VIC",
		"locality": "KEILOR EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3034",
		"state": "VIC",
		"locality": "AVONDALE HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3036",
		"state": "VIC",
		"locality": "KEILOR",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3037",
		"state": "VIC",
		"locality": "CALDER PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3038",
		"state": "VIC",
		"locality": "KEILOR DOWNS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3039",
		"state": "VIC",
		"locality": "MOONEE PONDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3040",
		"state": "VIC",
		"locality": "ABERFELDIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3041",
		"state": "VIC",
		"locality": "CROSS KEYS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3042",
		"state": "VIC",
		"locality": "AIRPORT WEST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3043",
		"state": "VIC",
		"locality": "GLADSTONE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3044",
		"state": "VIC",
		"locality": "PASCOE VALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3045",
		"state": "VIC",
		"locality": "MELBOURNE AIRPORT",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3046",
		"state": "VIC",
		"locality": "GLENROY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3047",
		"state": "VIC",
		"locality": "BROADMEADOWS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3048",
		"state": "VIC",
		"locality": "COOLAROO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3049",
		"state": "VIC",
		"locality": "ATTWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3051",
		"state": "VIC",
		"locality": "HOTHAM HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3052",
		"state": "VIC",
		"locality": "MELBOURNE UNIVERSITY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3053",
		"state": "VIC",
		"locality": "CARLTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3054",
		"state": "VIC",
		"locality": "CARLTON NORTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3055",
		"state": "VIC",
		"locality": "BRUNSWICK SOUTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3056",
		"state": "VIC",
		"locality": "BRUNSWICK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3057",
		"state": "VIC",
		"locality": "BRUNSWICK EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3058",
		"state": "VIC",
		"locality": "BATMAN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3059",
		"state": "VIC",
		"locality": "GREENVALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3060",
		"state": "VIC",
		"locality": "FAWKNER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3061",
		"state": "VIC",
		"locality": "CAMPBELLFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3062",
		"state": "VIC",
		"locality": "SOMERTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3063",
		"state": "VIC",
		"locality": "OAKLANDS JUNCTION",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3064",
		"state": "VIC",
		"locality": "CRAIGIEBURN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3065",
		"state": "VIC",
		"locality": "FITZROY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3066",
		"state": "VIC",
		"locality": "COLLINGWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3067",
		"state": "VIC",
		"locality": "ABBOTSFORD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3068",
		"state": "VIC",
		"locality": "CLIFTON HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3070",
		"state": "VIC",
		"locality": "NORTHCOTE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3071",
		"state": "VIC",
		"locality": "THORNBURY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3072",
		"state": "VIC",
		"locality": "GILBERTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3073",
		"state": "VIC",
		"locality": "RESERVOIR",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3074",
		"state": "VIC",
		"locality": "THOMASTOWN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3075",
		"state": "VIC",
		"locality": "LALOR",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3076",
		"state": "VIC",
		"locality": "EPPING",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3078",
		"state": "VIC",
		"locality": "ALPHINGTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3079",
		"state": "VIC",
		"locality": "IVANHOE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3081",
		"state": "VIC",
		"locality": "BELLFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3082",
		"state": "VIC",
		"locality": "MILL PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3083",
		"state": "VIC",
		"locality": "BUNDOORA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3084",
		"state": "VIC",
		"locality": "BANYULE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3085",
		"state": "VIC",
		"locality": "MACLEOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3087",
		"state": "VIC",
		"locality": "WATSONIA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3088",
		"state": "VIC",
		"locality": "BRIAR HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3089",
		"state": "VIC",
		"locality": "DIAMOND CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3090",
		"state": "VIC",
		"locality": "PLENTY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3091",
		"state": "VIC",
		"locality": "YARRAMBAT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3093",
		"state": "VIC",
		"locality": "LOWER PLENTY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3094",
		"state": "VIC",
		"locality": "MONTMORENCY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3095",
		"state": "VIC",
		"locality": "ELTHAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3096",
		"state": "VIC",
		"locality": "WATTLE GLEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3097",
		"state": "VIC",
		"locality": "BEND OF ISLANDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3099",
		"state": "VIC",
		"locality": "ARTHURS CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3101",
		"state": "VIC",
		"locality": "COTHAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3102",
		"state": "VIC",
		"locality": "KEW EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3103",
		"state": "VIC",
		"locality": "BALWYN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3104",
		"state": "VIC",
		"locality": "BALWYN NORTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3105",
		"state": "VIC",
		"locality": "BULLEEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3106",
		"state": "VIC",
		"locality": "TEMPLESTOWE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3107",
		"state": "VIC",
		"locality": "TEMPLESTOWE LOWER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3108",
		"state": "VIC",
		"locality": "DONCASTER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3109",
		"state": "VIC",
		"locality": "DONCASTER EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3111",
		"state": "VIC",
		"locality": "DONVALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3113",
		"state": "VIC",
		"locality": "NORTH WARRANDYTE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3114",
		"state": "VIC",
		"locality": "PARK ORCHARDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3115",
		"state": "VIC",
		"locality": "WONGA PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3116",
		"state": "VIC",
		"locality": "CHIRNSIDE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3121",
		"state": "VIC",
		"locality": "BURNLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3122",
		"state": "VIC",
		"locality": "AUBURN SOUTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3123",
		"state": "VIC",
		"locality": "AUBURN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3124",
		"state": "VIC",
		"locality": "CAMBERWELL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3125",
		"state": "VIC",
		"locality": "BENNETTSWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3126",
		"state": "VIC",
		"locality": "CAMBERWELL EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3127",
		"state": "VIC",
		"locality": "MONT ALBERT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3128",
		"state": "VIC",
		"locality": "BOX HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3129",
		"state": "VIC",
		"locality": "BOX HILL NORTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3130",
		"state": "VIC",
		"locality": "BLACKBURN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3131",
		"state": "VIC",
		"locality": "BRENTFORD SQUARE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3132",
		"state": "VIC",
		"locality": "MITCHAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3133",
		"state": "VIC",
		"locality": "VERMONT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3134",
		"state": "VIC",
		"locality": "HEATHWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3135",
		"state": "VIC",
		"locality": "BEDFORD ROAD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3136",
		"state": "VIC",
		"locality": "CROYDON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3137",
		"state": "VIC",
		"locality": "KILSYTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3138",
		"state": "VIC",
		"locality": "MOOROOLBARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3139",
		"state": "VIC",
		"locality": "BEENAK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3140",
		"state": "VIC",
		"locality": "LILYDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3141",
		"state": "VIC",
		"locality": "SOUTH YARRA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3142",
		"state": "VIC",
		"locality": "HAWKSBURN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "8",
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3143",
		"state": "VIC",
		"locality": "ARMADALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3144",
		"state": "VIC",
		"locality": "KOOYONG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3145",
		"state": "VIC",
		"locality": "CAULFIELD EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3146",
		"state": "VIC",
		"locality": "GLEN IRIS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3147",
		"state": "VIC",
		"locality": "ASHBURTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3148",
		"state": "VIC",
		"locality": "CHADSTONE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3149",
		"state": "VIC",
		"locality": "MOUNT WAVERLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3150",
		"state": "VIC",
		"locality": "BRANDON PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3151",
		"state": "VIC",
		"locality": "BURWOOD EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": " ",
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3152",
		"state": "VIC",
		"locality": "KNOX CITY CENTRE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3153",
		"state": "VIC",
		"locality": "BAYSWATER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3154",
		"state": "VIC",
		"locality": "THE BASIN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3155",
		"state": "VIC",
		"locality": "BORONIA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3156",
		"state": "VIC",
		"locality": "FERNTREE GULLY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3158",
		"state": "VIC",
		"locality": "UPWEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3159",
		"state": "VIC",
		"locality": "MENZIES CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3160",
		"state": "VIC",
		"locality": "BELGRAVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3161",
		"state": "VIC",
		"locality": "CAULFIELD JUNCTION",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3162",
		"state": "VIC",
		"locality": "CAULFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3163",
		"state": "VIC",
		"locality": "BOORAN ROAD PO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3165",
		"state": "VIC",
		"locality": "BENTLEIGH EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3166",
		"state": "VIC",
		"locality": "HUGHESDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3167",
		"state": "VIC",
		"locality": "OAKLEIGH SOUTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3168",
		"state": "VIC",
		"locality": "CLAYTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3169",
		"state": "VIC",
		"locality": "CLARINDA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3170",
		"state": "VIC",
		"locality": "MULGRAVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3171",
		"state": "VIC",
		"locality": "SANDOWN VILLAGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3172",
		"state": "VIC",
		"locality": "DINGLEY VILLAGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3173",
		"state": "VIC",
		"locality": "KEYSBOROUGH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3174",
		"state": "VIC",
		"locality": "NOBLE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3175",
		"state": "VIC",
		"locality": "BANGHOLME",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3177",
		"state": "VIC",
		"locality": "DOVETON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3178",
		"state": "VIC",
		"locality": "ROWVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3179",
		"state": "VIC",
		"locality": "SCORESBY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3180",
		"state": "VIC",
		"locality": "KNOXFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3181",
		"state": "VIC",
		"locality": "PRAHRAN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3182",
		"state": "VIC",
		"locality": "ST KILDA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3183",
		"state": "VIC",
		"locality": "BALACLAVA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3184",
		"state": "VIC",
		"locality": "BRIGHTON ROAD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3185",
		"state": "VIC",
		"locality": "ELSTERNWICK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3186",
		"state": "VIC",
		"locality": "BRIGHTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X072": "6",
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3187",
		"state": "VIC",
		"locality": "BRIGHTON EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3188",
		"state": "VIC",
		"locality": "HAMPTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3189",
		"state": "VIC",
		"locality": "MOORABBIN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3190",
		"state": "VIC",
		"locality": "HIGHETT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3191",
		"state": "VIC",
		"locality": "SANDRINGHAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3192",
		"state": "VIC",
		"locality": "CHELTENHAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3193",
		"state": "VIC",
		"locality": "BEAUMARIS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3194",
		"state": "VIC",
		"locality": "MENTONE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3195",
		"state": "VIC",
		"locality": "ASPENDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3196",
		"state": "VIC",
		"locality": "BONBEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3197",
		"state": "VIC",
		"locality": "CARRUM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3198",
		"state": "VIC",
		"locality": "SEAFORD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3199",
		"state": "VIC",
		"locality": "FRANKSTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3200",
		"state": "VIC",
		"locality": "FRANKSTON NORTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3201",
		"state": "VIC",
		"locality": "CARRUM DOWNS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3202",
		"state": "VIC",
		"locality": "HEATHERTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3204",
		"state": "VIC",
		"locality": "BENTLEIGH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3205",
		"state": "VIC",
		"locality": "SOUTH MELBOURNE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3206",
		"state": "VIC",
		"locality": "ALBERT PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3207",
		"state": "VIC",
		"locality": "GARDEN CITY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3211",
		"state": "VIC",
		"locality": "LITTLE RIVER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Metropolitan"
		}, {
		"postcode": "3212",
		"state": "VIC",
		"locality": "AVALON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3213",
		"state": "VIC",
		"locality": "ANAKIE",
		"X065": "Category 1",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3214",
		"state": "VIC",
		"locality": "CORIO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3215",
		"state": "VIC",
		"locality": "BELL PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3216",
		"state": "VIC",
		"locality": "BELMONT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3217",
		"state": "VIC",
		"locality": "ARMSTRONG CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3218",
		"state": "VIC",
		"locality": "FYANSFORD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3219",
		"state": "VIC",
		"locality": "BREAKWATER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3220",
		"state": "VIC",
		"locality": "BAREENA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3221",
		"state": "VIC",
		"locality": "BARRABOOL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3222",
		"state": "VIC",
		"locality": "CLIFTON SPRINGS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3223",
		"state": "VIC",
		"locality": "BELLARINE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3224",
		"state": "VIC",
		"locality": "LEOPOLD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3225",
		"state": "VIC",
		"locality": "POINT LONSDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3226",
		"state": "VIC",
		"locality": "OCEAN GROVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3227",
		"state": "VIC",
		"locality": "BARWON HEADS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3228",
		"state": "VIC",
		"locality": "BELLBRAE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3230",
		"state": "VIC",
		"locality": "ANGLESEA",
		"X065": "Category 1",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3231",
		"state": "VIC",
		"locality": "AIREYS INLET",
		"X065": "Category 2",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3232",
		"state": "VIC",
		"locality": "LORNE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3233",
		"state": "VIC",
		"locality": "APOLLO BAY",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3234",
		"state": "VIC",
		"locality": "GREY RIVER",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3235",
		"state": "VIC",
		"locality": "BENWERRIN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3236",
		"state": "VIC",
		"locality": "FORREST",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3237",
		"state": "VIC",
		"locality": "AIRE VALLEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3238",
		"state": "VIC",
		"locality": "GLENAIRE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3239",
		"state": "VIC",
		"locality": "CARLISLE RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3240",
		"state": "VIC",
		"locality": "BUCKLEY",
		"X065": "Category 2",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3241",
		"state": "VIC",
		"locality": "BAMBRA",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3242",
		"state": "VIC",
		"locality": "BIRREGURRA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3243",
		"state": "VIC",
		"locality": "BARWON DOWNS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3249",
		"state": "VIC",
		"locality": "ALVIE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3250",
		"state": "VIC",
		"locality": "COLAC",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3251",
		"state": "VIC",
		"locality": "BEEAC",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3254",
		"state": "VIC",
		"locality": "COROROOKE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3260",
		"state": "VIC",
		"locality": "BOOKAAR",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3264",
		"state": "VIC",
		"locality": "TERANG",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3265",
		"state": "VIC",
		"locality": "BOORCAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3266",
		"state": "VIC",
		"locality": "BULLAHARRE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3267",
		"state": "VIC",
		"locality": "SCOTTS CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3268",
		"state": "VIC",
		"locality": "AYRFORD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3269",
		"state": "VIC",
		"locality": "PORT CAMPBELL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3270",
		"state": "VIC",
		"locality": "PETERBOROUGH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3271",
		"state": "VIC",
		"locality": "DARLINGTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3272",
		"state": "VIC",
		"locality": "MORTLAKE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3273",
		"state": "VIC",
		"locality": "HEXHAM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3274",
		"state": "VIC",
		"locality": "CARAMUT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3275",
		"state": "VIC",
		"locality": "MAILORS FLAT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3276",
		"state": "VIC",
		"locality": "MINJAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3277",
		"state": "VIC",
		"locality": "ALLANSFORD",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3278",
		"state": "VIC",
		"locality": "PURNIM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3279",
		"state": "VIC",
		"locality": "BALLANGEICH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3280",
		"state": "VIC",
		"locality": "DENNINGTON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3281",
		"state": "VIC",
		"locality": "BUSHFIELD",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3282",
		"state": "VIC",
		"locality": "ILLOWA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3283",
		"state": "VIC",
		"locality": "CROSSLEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3284",
		"state": "VIC",
		"locality": "ORFORD",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3285",
		"state": "VIC",
		"locality": "CODRINGTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3286",
		"state": "VIC",
		"locality": "CONDAH SWAMP",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3287",
		"state": "VIC",
		"locality": "HAWKESDALE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3289",
		"state": "VIC",
		"locality": "GAZETTE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3292",
		"state": "VIC",
		"locality": "NELSON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3293",
		"state": "VIC",
		"locality": "GLENTHOMPSON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3294",
		"state": "VIC",
		"locality": "DUNKELD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3300",
		"state": "VIC",
		"locality": "BYADUK NORTH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3301",
		"state": "VIC",
		"locality": "BOCHARA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3302",
		"state": "VIC",
		"locality": "BRANXHOLME",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3303",
		"state": "VIC",
		"locality": "BREAKAWAY CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3304",
		"state": "VIC",
		"locality": "BESSIEBELLE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3305",
		"state": "VIC",
		"locality": "ALLESTREE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3309",
		"state": "VIC",
		"locality": "DIGBY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3310",
		"state": "VIC",
		"locality": "MERINO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3311",
		"state": "VIC",
		"locality": "CASTERTON",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3312",
		"state": "VIC",
		"locality": "BAHGALLAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3314",
		"state": "VIC",
		"locality": "BULART",
		"X065": "On application",
		"X066": "Regional",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3315",
		"state": "VIC",
		"locality": "BRIT BRIT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3317",
		"state": "VIC",
		"locality": "HARROW",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3318",
		"state": "VIC",
		"locality": "CHARAM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3319",
		"state": "VIC",
		"locality": "APSLEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3321",
		"state": "VIC",
		"locality": "HESSE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3322",
		"state": "VIC",
		"locality": "CRESSY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3323",
		"state": "VIC",
		"locality": "BERRYBANK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3324",
		"state": "VIC",
		"locality": "LISMORE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3325",
		"state": "VIC",
		"locality": "DERRINALLUM",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3328",
		"state": "VIC",
		"locality": "TEESDALE",
		"X065": "Category 2",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3329",
		"state": "VIC",
		"locality": "BARUNAH PARK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3330",
		"state": "VIC",
		"locality": "ROKEWOOD",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3331",
		"state": "VIC",
		"locality": "BANNOCKBURN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3332",
		"state": "VIC",
		"locality": "LETHBRIDGE",
		"X065": "Category 2",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3333",
		"state": "VIC",
		"locality": "BAMGANIE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3334",
		"state": "VIC",
		"locality": "BUNGAL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3335",
		"state": "VIC",
		"locality": "PLUMPTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3336",
		"state": "VIC",
		"locality": "AINTREE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Metropolitan"
		}, {
		"postcode": "3337",
		"state": "VIC",
		"locality": "KURUNJANG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Metropolitan"
		}, {
		"postcode": "3338",
		"state": "VIC",
		"locality": "BROOKFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3340",
		"state": "VIC",
		"locality": "BACCHUS MARSH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Metropolitan"
		}, {
		"postcode": "3341",
		"state": "VIC",
		"locality": "DALES CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3342",
		"state": "VIC",
		"locality": "BALLAN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3345",
		"state": "VIC",
		"locality": "GORDON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3350",
		"state": "VIC",
		"locality": "ALFREDTON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3351",
		"state": "VIC",
		"locality": "BERRINGA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3352",
		"state": "VIC",
		"locality": "ADDINGTON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3355",
		"state": "VIC",
		"locality": "LAKE GARDENS",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3356",
		"state": "VIC",
		"locality": "DELACOMBE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3357",
		"state": "VIC",
		"locality": "BUNINYONG",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3358",
		"state": "VIC",
		"locality": "WINTER VALLY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3360",
		"state": "VIC",
		"locality": "HAPPY VALLEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3361",
		"state": "VIC",
		"locality": "BRADVALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3363",
		"state": "VIC",
		"locality": "CRESWICK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3364",
		"state": "VIC",
		"locality": "ALLENDALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3370",
		"state": "VIC",
		"locality": "CLUNES",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3371",
		"state": "VIC",
		"locality": "AMHERST",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3373",
		"state": "VIC",
		"locality": "BEAUFORT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3374",
		"state": "VIC",
		"locality": "GREAT WESTERN",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3375",
		"state": "VIC",
		"locality": "BALLYROGAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3377",
		"state": "VIC",
		"locality": "ARARAT",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3378",
		"state": "VIC",
		"locality": "TATYOON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3379",
		"state": "VIC",
		"locality": "BORNES HILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3380",
		"state": "VIC",
		"locality": "STAWELL",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3381",
		"state": "VIC",
		"locality": "BELLELLEN",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3384",
		"state": "VIC",
		"locality": "BARKLY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3385",
		"state": "VIC",
		"locality": "DADSWELLS BRIDGE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3387",
		"state": "VIC",
		"locality": "BOLANGUM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3388",
		"state": "VIC",
		"locality": "BANYENA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3390",
		"state": "VIC",
		"locality": "KEWELL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3391",
		"state": "VIC",
		"locality": "BRIM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3392",
		"state": "VIC",
		"locality": "BOOLITE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3393",
		"state": "VIC",
		"locality": "AUBREY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3395",
		"state": "VIC",
		"locality": "BEULAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3396",
		"state": "VIC",
		"locality": "HOPETOUN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3400",
		"state": "VIC",
		"locality": "HORSHAM",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3401",
		"state": "VIC",
		"locality": "BLACKHEATH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3407",
		"state": "VIC",
		"locality": "BALMORAL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3409",
		"state": "VIC",
		"locality": "ARAPILES",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3412",
		"state": "VIC",
		"locality": "GOROKE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3413",
		"state": "VIC",
		"locality": "MINIMAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3414",
		"state": "VIC",
		"locality": "ANTWERP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3415",
		"state": "VIC",
		"locality": "MIRAM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3418",
		"state": "VIC",
		"locality": "BROUGHTON",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3419",
		"state": "VIC",
		"locality": "KANIVA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3420",
		"state": "VIC",
		"locality": "LILLIMUR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3423",
		"state": "VIC",
		"locality": "JEPARIT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3424",
		"state": "VIC",
		"locality": "ALBACUTYA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3427",
		"state": "VIC",
		"locality": "DIGGERS REST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3428",
		"state": "VIC",
		"locality": "BULLA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3429",
		"state": "VIC",
		"locality": "SUNBURY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3430",
		"state": "VIC",
		"locality": "CLARKEFIELD",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3431",
		"state": "VIC",
		"locality": "RIDDELLS CREEK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3432",
		"state": "VIC",
		"locality": "BOLINDA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3433",
		"state": "VIC",
		"locality": "MONEGEETTA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3434",
		"state": "VIC",
		"locality": "CHEROKEE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3435",
		"state": "VIC",
		"locality": "BENLOCH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3437",
		"state": "VIC",
		"locality": "BULLENGAROOK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3438",
		"state": "VIC",
		"locality": "NEW GISBORNE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3440",
		"state": "VIC",
		"locality": "MACEDON",
		"X065": "Category 2",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3441",
		"state": "VIC",
		"locality": "MOUNT MACEDON",
		"X065": "Category 2",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3442",
		"state": "VIC",
		"locality": "ASHBOURNE",
		"X065": "Category 2",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3444",
		"state": "VIC",
		"locality": "BARFOLD",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3446",
		"state": "VIC",
		"locality": "DRUMMOND NORTH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3447",
		"state": "VIC",
		"locality": "TARADALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3448",
		"state": "VIC",
		"locality": "ELPHINSTONE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3450",
		"state": "VIC",
		"locality": "CASTLEMAINE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3451",
		"state": "VIC",
		"locality": "BARKERS CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3453",
		"state": "VIC",
		"locality": "HARCOURT",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3458",
		"state": "VIC",
		"locality": "BARRYS REEF",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3460",
		"state": "VIC",
		"locality": "BASALT",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3461",
		"state": "VIC",
		"locality": "BULLARTO",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3462",
		"state": "VIC",
		"locality": "GREEN GULLY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3463",
		"state": "VIC",
		"locality": "BARINGHUP",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3464",
		"state": "VIC",
		"locality": "CARISBROOK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3465",
		"state": "VIC",
		"locality": "ADELAIDE LEAD",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3467",
		"state": "VIC",
		"locality": "AVOCA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3468",
		"state": "VIC",
		"locality": "AMPHITHEATRE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3469",
		"state": "VIC",
		"locality": "ELMHURST",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3472",
		"state": "VIC",
		"locality": "BET BET",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3475",
		"state": "VIC",
		"locality": "ARCHDALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3477",
		"state": "VIC",
		"locality": "AVON PLAINS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3478",
		"state": "VIC",
		"locality": "DOOBOOBETIC",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3480",
		"state": "VIC",
		"locality": "AREEGRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3482",
		"state": "VIC",
		"locality": "MASSEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3483",
		"state": "VIC",
		"locality": "BALLAPUR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3485",
		"state": "VIC",
		"locality": "BANYAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3487",
		"state": "VIC",
		"locality": "LASCELLES",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3488",
		"state": "VIC",
		"locality": "SPEED",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3489",
		"state": "VIC",
		"locality": "TEMPY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3490",
		"state": "VIC",
		"locality": "BIG DESERT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3491",
		"state": "VIC",
		"locality": "PATCHEWOLLOCK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3494",
		"state": "VIC",
		"locality": "CARWARP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3496",
		"state": "VIC",
		"locality": "CARDROSS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3498",
		"state": "VIC",
		"locality": "IRYMPLE",
		"X065": "Category 2",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3500",
		"state": "VIC",
		"locality": "MILDURA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3501",
		"state": "VIC",
		"locality": "HATTAH",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3505",
		"state": "VIC",
		"locality": "BIRDWOODTON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3506",
		"state": "VIC",
		"locality": "COWANGIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3507",
		"state": "VIC",
		"locality": "WALPEUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3509",
		"state": "VIC",
		"locality": "LINGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3512",
		"state": "VIC",
		"locality": "CARINA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3515",
		"state": "VIC",
		"locality": "MARONG",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3516",
		"state": "VIC",
		"locality": "BRIDGEWATER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3517",
		"state": "VIC",
		"locality": "BEARS LAGOON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3518",
		"state": "VIC",
		"locality": "BERRIMAL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3520",
		"state": "VIC",
		"locality": "KINYPANIAL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3521",
		"state": "VIC",
		"locality": "PYALONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3522",
		"state": "VIC",
		"locality": "GLENHOPE EAST",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3523",
		"state": "VIC",
		"locality": "ARGYLE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3525",
		"state": "VIC",
		"locality": "BARRAKEE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3527",
		"state": "VIC",
		"locality": "BUNGULUKE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3529",
		"state": "VIC",
		"locality": "KALPIENUNG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3530",
		"state": "VIC",
		"locality": "CULGOA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3531",
		"state": "VIC",
		"locality": "BERRIWILLOCK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3533",
		"state": "VIC",
		"locality": "BIMBOURIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3537",
		"state": "VIC",
		"locality": "BARRAPORT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3540",
		"state": "VIC",
		"locality": "CANNIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3541",
		"state": "VIC",
		"locality": "LINDSAY POINT",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3542",
		"state": "VIC",
		"locality": "COKUM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3544",
		"state": "VIC",
		"locality": "CHINANGIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3546",
		"state": "VIC",
		"locality": "BOLTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3549",
		"state": "VIC",
		"locality": "ANNUELLO",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3550",
		"state": "VIC",
		"locality": "BENDIGO",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3551",
		"state": "VIC",
		"locality": "ARNOLD",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3555",
		"state": "VIC",
		"locality": "BIG HILL",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3556",
		"state": "VIC",
		"locality": "CALIFORNIA GULLY",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3557",
		"state": "VIC",
		"locality": "BARNADOWN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3558",
		"state": "VIC",
		"locality": "BURNEWANG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3559",
		"state": "VIC",
		"locality": "AVONMORE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3561",
		"state": "VIC",
		"locality": "BALLENDELLA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3562",
		"state": "VIC",
		"locality": "TORRUMBARRY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3563",
		"state": "VIC",
		"locality": "LOCKINGTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3564",
		"state": "VIC",
		"locality": "BAMAWM EXTENSION",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3565",
		"state": "VIC",
		"locality": "KOTTA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3566",
		"state": "VIC",
		"locality": "GUNBOWER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3567",
		"state": "VIC",
		"locality": "HORFIELD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3568",
		"state": "VIC",
		"locality": "BURKES BRIDGE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3570",
		"state": "VIC",
		"locality": "AUCHMORE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3571",
		"state": "VIC",
		"locality": "DINGEE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3572",
		"state": "VIC",
		"locality": "MILLOO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3573",
		"state": "VIC",
		"locality": "CALIVIL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3575",
		"state": "VIC",
		"locality": "GLADFIELD",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3576",
		"state": "VIC",
		"locality": "DURHAM OX",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3579",
		"state": "VIC",
		"locality": "APPIN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3580",
		"state": "VIC",
		"locality": "KOONDROOK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3581",
		"state": "VIC",
		"locality": "LAKE CHARM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3583",
		"state": "VIC",
		"locality": "TRESCO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3584",
		"state": "VIC",
		"locality": "LAKE BOGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3585",
		"state": "VIC",
		"locality": "CASTLE DONNINGTON",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3586",
		"state": "VIC",
		"locality": "BULGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3588",
		"state": "VIC",
		"locality": "WOORINEN SOUTH",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3589",
		"state": "VIC",
		"locality": "WOORINEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3590",
		"state": "VIC",
		"locality": "BEVERFORD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3591",
		"state": "VIC",
		"locality": "VINIFERA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3594",
		"state": "VIC",
		"locality": "NYAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3595",
		"state": "VIC",
		"locality": "NYAH WEST",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3596",
		"state": "VIC",
		"locality": "MIRALIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3597",
		"state": "VIC",
		"locality": "KENLEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3599",
		"state": "VIC",
		"locality": "BOUNDARY BEND",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3607",
		"state": "VIC",
		"locality": "TABILK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3608",
		"state": "VIC",
		"locality": "BAILIESTON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3610",
		"state": "VIC",
		"locality": "DHURRINGILE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3612",
		"state": "VIC",
		"locality": "MOORA",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3614",
		"state": "VIC",
		"locality": "TOOLAMBA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3616",
		"state": "VIC",
		"locality": "COOMA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3617",
		"state": "VIC",
		"locality": "BYRNESIDE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3618",
		"state": "VIC",
		"locality": "MERRIGUM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3620",
		"state": "VIC",
		"locality": "KYABRAM",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3621",
		"state": "VIC",
		"locality": "KYVALLEY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3622",
		"state": "VIC",
		"locality": "KOYUGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3623",
		"state": "VIC",
		"locality": "CARAG CARAG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3624",
		"state": "VIC",
		"locality": "GIRGARRE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3629",
		"state": "VIC",
		"locality": "ARDMONA",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3630",
		"state": "VIC",
		"locality": "BRANDITT",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3631",
		"state": "VIC",
		"locality": "ARCADIA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3633",
		"state": "VIC",
		"locality": "CONGUPNA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3634",
		"state": "VIC",
		"locality": "BUNBARTHA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3635",
		"state": "VIC",
		"locality": "KAARIMBA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3636",
		"state": "VIC",
		"locality": "DRUMANURE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3637",
		"state": "VIC",
		"locality": "WAAIA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3638",
		"state": "VIC",
		"locality": "KOTUPNA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3639",
		"state": "VIC",
		"locality": "BARMAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3640",
		"state": "VIC",
		"locality": "KATUNGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3641",
		"state": "VIC",
		"locality": "BEARII",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3644",
		"state": "VIC",
		"locality": "BAROOGA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3646",
		"state": "VIC",
		"locality": "DOOKIE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3647",
		"state": "VIC",
		"locality": "DOOKIE COLLEGE",
		"X065": "N/A",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3649",
		"state": "VIC",
		"locality": "KATAMATITE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3658",
		"state": "VIC",
		"locality": "BROADFORD",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3659",
		"state": "VIC",
		"locality": "TALLAROOK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3660",
		"state": "VIC",
		"locality": "CAVEAT",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3662",
		"state": "VIC",
		"locality": "PUCKAPUNYAL",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3663",
		"state": "VIC",
		"locality": "MANGALORE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3664",
		"state": "VIC",
		"locality": "AVENEL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3665",
		"state": "VIC",
		"locality": "LOCKSLEY",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3666",
		"state": "VIC",
		"locality": "BALMATTUM",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3669",
		"state": "VIC",
		"locality": "BOHO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3670",
		"state": "VIC",
		"locality": "BADDAGINNIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3672",
		"state": "VIC",
		"locality": "BENALLA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3673",
		"state": "VIC",
		"locality": "BROKEN CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3675",
		"state": "VIC",
		"locality": "BOWEYA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3677",
		"state": "VIC",
		"locality": "WANGARATTA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3678",
		"state": "VIC",
		"locality": "BOBINAWARRAH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3682",
		"state": "VIC",
		"locality": "BORALMA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3683",
		"state": "VIC",
		"locality": "CHILTERN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3685",
		"state": "VIC",
		"locality": "BOORHAMAN NORTH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3687",
		"state": "VIC",
		"locality": "WAHGUNYAH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3688",
		"state": "VIC",
		"locality": "BARNAWARTHA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3690",
		"state": "VIC",
		"locality": "WEST WODONGA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3691",
		"state": "VIC",
		"locality": "ALLANS FLAT",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3694",
		"state": "VIC",
		"locality": "BANDIANA MILPO",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3695",
		"state": "VIC",
		"locality": "CHARLEROI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3697",
		"state": "VIC",
		"locality": "TAWONGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3698",
		"state": "VIC",
		"locality": "TAWONGA SOUTH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3699",
		"state": "VIC",
		"locality": "BOGONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3700",
		"state": "VIC",
		"locality": "BULLIOH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3701",
		"state": "VIC",
		"locality": "DARTMOUTH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3704",
		"state": "VIC",
		"locality": "KOETONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3705",
		"state": "VIC",
		"locality": "CUDGEWA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3707",
		"state": "VIC",
		"locality": "BIGGARA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3708",
		"state": "VIC",
		"locality": "TINTALDRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3709",
		"state": "VIC",
		"locality": "BURROWYE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3711",
		"state": "VIC",
		"locality": "BUXTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3712",
		"state": "VIC",
		"locality": "RUBICON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3713",
		"state": "VIC",
		"locality": "EILDON",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3714",
		"state": "VIC",
		"locality": "ACHERON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3715",
		"state": "VIC",
		"locality": "ANCONA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3717",
		"state": "VIC",
		"locality": "FLOWERDALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3718",
		"state": "VIC",
		"locality": "MOLESWORTH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3719",
		"state": "VIC",
		"locality": "GOBUR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3720",
		"state": "VIC",
		"locality": "BONNIE DOON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3722",
		"state": "VIC",
		"locality": "BARWITE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3723",
		"state": "VIC",
		"locality": "ARCHERTON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3725",
		"state": "VIC",
		"locality": "BOXWOOD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3726",
		"state": "VIC",
		"locality": "BUNGEET",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3727",
		"state": "VIC",
		"locality": "ALMONDS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3728",
		"state": "VIC",
		"locality": "BOOMAHNOOMOONAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3730",
		"state": "VIC",
		"locality": "YARRAWONGA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3732",
		"state": "VIC",
		"locality": "MOYHU",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3733",
		"state": "VIC",
		"locality": "WHITFIELD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3735",
		"state": "VIC",
		"locality": "BOWMANS FOREST",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3737",
		"state": "VIC",
		"locality": "ABBEYARD",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3738",
		"state": "VIC",
		"locality": "OVENS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3739",
		"state": "VIC",
		"locality": "EUROBIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3740",
		"state": "VIC",
		"locality": "BUCKLAND",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3741",
		"state": "VIC",
		"locality": "BRIGHT",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3744",
		"state": "VIC",
		"locality": "WANDILIGONG",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3746",
		"state": "VIC",
		"locality": "ELDORADO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3747",
		"state": "VIC",
		"locality": "BEECHWORTH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3749",
		"state": "VIC",
		"locality": "BRUARONG",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3750",
		"state": "VIC",
		"locality": "WOLLERT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3751",
		"state": "VIC",
		"locality": "WOODSTOCK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3752",
		"state": "VIC",
		"locality": "SOUTH MORANG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3753",
		"state": "VIC",
		"locality": "BEVERIDGE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3754",
		"state": "VIC",
		"locality": "DOREEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3755",
		"state": "VIC",
		"locality": "YAN YEAN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3756",
		"state": "VIC",
		"locality": "CHINTIN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3757",
		"state": "VIC",
		"locality": "EDEN PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Metropolitan"
		}, {
		"postcode": "3758",
		"state": "VIC",
		"locality": "HEATHCOTE JUNCTION",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3759",
		"state": "VIC",
		"locality": "PANTON HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3760",
		"state": "VIC",
		"locality": "SMITHS GULLY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3761",
		"state": "VIC",
		"locality": "ST ANDREWS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3762",
		"state": "VIC",
		"locality": "BYLANDS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3763",
		"state": "VIC",
		"locality": "KINGLAKE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3764",
		"state": "VIC",
		"locality": "FORBES",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Regional",
		"X073": "Metropolitan"
		}, {
		"postcode": "3765",
		"state": "VIC",
		"locality": "MONTROSE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3766",
		"state": "VIC",
		"locality": "KALORAMA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3767",
		"state": "VIC",
		"locality": "MOUNT DANDENONG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3770",
		"state": "VIC",
		"locality": "COLDSTREAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3775",
		"state": "VIC",
		"locality": "YARRA GLEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3777",
		"state": "VIC",
		"locality": "BADGER CREEK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3778",
		"state": "VIC",
		"locality": "FERNSHAW",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3779",
		"state": "VIC",
		"locality": "CAMBARVILLE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3781",
		"state": "VIC",
		"locality": "COCKATOO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3782",
		"state": "VIC",
		"locality": "AVONSLEIGH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3783",
		"state": "VIC",
		"locality": "GEMBROOK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3785",
		"state": "VIC",
		"locality": "TREMONT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3786",
		"state": "VIC",
		"locality": "FERNY CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3787",
		"state": "VIC",
		"locality": "SASSAFRAS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3788",
		"state": "VIC",
		"locality": "OLINDA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3789",
		"state": "VIC",
		"locality": "SHERBROOKE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3791",
		"state": "VIC",
		"locality": "KALLISTA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3792",
		"state": "VIC",
		"locality": "THE PATCH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3793",
		"state": "VIC",
		"locality": "MONBULK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3795",
		"state": "VIC",
		"locality": "SILVAN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3796",
		"state": "VIC",
		"locality": "MOUNT EVELYN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3797",
		"state": "VIC",
		"locality": "GILDEROY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3799",
		"state": "VIC",
		"locality": "BIG PATS CREEK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3802",
		"state": "VIC",
		"locality": "ENDEAVOUR HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3803",
		"state": "VIC",
		"locality": "HALLAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3804",
		"state": "VIC",
		"locality": "NARRE WARREN EAST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3805",
		"state": "VIC",
		"locality": "FOUNTAIN GATE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3806",
		"state": "VIC",
		"locality": "BERWICK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3807",
		"state": "VIC",
		"locality": "BEACONSFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3808",
		"state": "VIC",
		"locality": "BEACONSFIELD UPPER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3809",
		"state": "VIC",
		"locality": "OFFICER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3810",
		"state": "VIC",
		"locality": "PAKENHAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3812",
		"state": "VIC",
		"locality": "MARYKNOLL",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3813",
		"state": "VIC",
		"locality": "TYNONG",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3814",
		"state": "VIC",
		"locality": "CORA LYNN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3815",
		"state": "VIC",
		"locality": "BUNYIP",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3816",
		"state": "VIC",
		"locality": "LABERTOUCHE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3818",
		"state": "VIC",
		"locality": "ATHLONE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3820",
		"state": "VIC",
		"locality": "BONA VISTA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3821",
		"state": "VIC",
		"locality": "BRANDY CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3822",
		"state": "VIC",
		"locality": "CLOVERLEA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3823",
		"state": "VIC",
		"locality": "ALLAMBEE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3824",
		"state": "VIC",
		"locality": "CHILDERS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3825",
		"state": "VIC",
		"locality": "ABERFELDY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3831",
		"state": "VIC",
		"locality": "NEERIM",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3832",
		"state": "VIC",
		"locality": "NAYOOK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3833",
		"state": "VIC",
		"locality": "ADA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3835",
		"state": "VIC",
		"locality": "THORPDALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3840",
		"state": "VIC",
		"locality": "DRIFFIELD",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3842",
		"state": "VIC",
		"locality": "CHURCHILL",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3844",
		"state": "VIC",
		"locality": "BLACKWARRY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3847",
		"state": "VIC",
		"locality": "HIAMDALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3850",
		"state": "VIC",
		"locality": "SALE",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3851",
		"state": "VIC",
		"locality": "AIRLY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3852",
		"state": "VIC",
		"locality": "EAST SALE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3854",
		"state": "VIC",
		"locality": "GLENGARRY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3856",
		"state": "VIC",
		"locality": "TOONGABBIE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3857",
		"state": "VIC",
		"locality": "COWWARR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3858",
		"state": "VIC",
		"locality": "ARBUCKLE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3859",
		"state": "VIC",
		"locality": "MAFFRA WEST UPPER",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3860",
		"state": "VIC",
		"locality": "BOISDALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3862",
		"state": "VIC",
		"locality": "BUDGEE BUDGEE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3864",
		"state": "VIC",
		"locality": "FERNBANK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3865",
		"state": "VIC",
		"locality": "LINDENOW",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3869",
		"state": "VIC",
		"locality": "JUMBUK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3870",
		"state": "VIC",
		"locality": "BOOLARRA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3871",
		"state": "VIC",
		"locality": "ALLAMBEE RESERVE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3873",
		"state": "VIC",
		"locality": "GORMANDALE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3874",
		"state": "VIC",
		"locality": "MCLOUGHLINS BEACH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3875",
		"state": "VIC",
		"locality": "BAIRNSDALE",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3878",
		"state": "VIC",
		"locality": "EAGLE POINT",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3880",
		"state": "VIC",
		"locality": "BOOLE POOLE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3882",
		"state": "VIC",
		"locality": "NICHOLSON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3885",
		"state": "VIC",
		"locality": "BRUMBY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3886",
		"state": "VIC",
		"locality": "NEWMERELLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3887",
		"state": "VIC",
		"locality": "LAKE TYERS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3888",
		"state": "VIC",
		"locality": "BENDOC",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3889",
		"state": "VIC",
		"locality": "BELLBIRD CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3890",
		"state": "VIC",
		"locality": "BULDAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3891",
		"state": "VIC",
		"locality": "GENOA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3892",
		"state": "VIC",
		"locality": "MALLACOOTA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3893",
		"state": "VIC",
		"locality": "DOUBLE BRIDGES",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3895",
		"state": "VIC",
		"locality": "DOCTORS FLAT",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3896",
		"state": "VIC",
		"locality": "BINDI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3898",
		"state": "VIC",
		"locality": "ANGLERS REST",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3900",
		"state": "VIC",
		"locality": "BENAMBRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3902",
		"state": "VIC",
		"locality": "BUMBERRAH",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3903",
		"state": "VIC",
		"locality": "SWAN REACH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3904",
		"state": "VIC",
		"locality": "METUNG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3909",
		"state": "VIC",
		"locality": "KALIMNA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3910",
		"state": "VIC",
		"locality": "LANGWARRIN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3911",
		"state": "VIC",
		"locality": "BAXTER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3912",
		"state": "VIC",
		"locality": "PEARCEDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3913",
		"state": "VIC",
		"locality": "TYABB",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3915",
		"state": "VIC",
		"locality": "HASTINGS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3916",
		"state": "VIC",
		"locality": "MERRICKS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3918",
		"state": "VIC",
		"locality": "BITTERN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3919",
		"state": "VIC",
		"locality": "CRIB POINT",
		"X065": "Category 1",
		"X066": "Regional",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3920",
		"state": "VIC",
		"locality": "HMAS CERBERUS",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3921",
		"state": "VIC",
		"locality": "ELIZABETH ISLAND",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3922",
		"state": "VIC",
		"locality": "COWES",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3923",
		"state": "VIC",
		"locality": "RHYLL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3925",
		"state": "VIC",
		"locality": "CAPE WOOLAMAI",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3926",
		"state": "VIC",
		"locality": "BALNARRING",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3927",
		"state": "VIC",
		"locality": "SOMERS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3928",
		"state": "VIC",
		"locality": "MAIN RIDGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3929",
		"state": "VIC",
		"locality": "FLINDERS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3930",
		"state": "VIC",
		"locality": "KUNYUNG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3931",
		"state": "VIC",
		"locality": "MORNINGTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3933",
		"state": "VIC",
		"locality": "MOOROODUC",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3934",
		"state": "VIC",
		"locality": "MOUNT MARTHA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3936",
		"state": "VIC",
		"locality": "ARTHURS SEAT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3937",
		"state": "VIC",
		"locality": "RED HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3938",
		"state": "VIC",
		"locality": "MCCRAE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3939",
		"state": "VIC",
		"locality": "BONEO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3940",
		"state": "VIC",
		"locality": "ROSEBUD WEST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3941",
		"state": "VIC",
		"locality": "RYE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3942",
		"state": "VIC",
		"locality": "BLAIRGOWRIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3943",
		"state": "VIC",
		"locality": "SORRENTO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3944",
		"state": "VIC",
		"locality": "PORTSEA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3945",
		"state": "VIC",
		"locality": "JEETHO",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3946",
		"state": "VIC",
		"locality": "BENA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3950",
		"state": "VIC",
		"locality": "KARDELLA SOUTH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3951",
		"state": "VIC",
		"locality": "ARAWATA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3953",
		"state": "VIC",
		"locality": "BERRYS CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3954",
		"state": "VIC",
		"locality": "KOONWARRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3956",
		"state": "VIC",
		"locality": "DUMBALK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3957",
		"state": "VIC",
		"locality": "STONY CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3958",
		"state": "VIC",
		"locality": "BUFFALO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3959",
		"state": "VIC",
		"locality": "FISH CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3960",
		"state": "VIC",
		"locality": "BENNISON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3962",
		"state": "VIC",
		"locality": "AGNES",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3964",
		"state": "VIC",
		"locality": "PORT FRANKLIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3965",
		"state": "VIC",
		"locality": "PORT WELSHPOOL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3966",
		"state": "VIC",
		"locality": "BINGINWARRI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3967",
		"state": "VIC",
		"locality": "HEDLEY",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3971",
		"state": "VIC",
		"locality": "ALBERTON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3975",
		"state": "VIC",
		"locality": "LYNBROOK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3976",
		"state": "VIC",
		"locality": "HAMPTON PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3977",
		"state": "VIC",
		"locality": "BOTANIC RIDGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3978",
		"state": "VIC",
		"locality": "CARDINIA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "Metro",
		"X073": "Metropolitan"
		}, {
		"postcode": "3979",
		"state": "VIC",
		"locality": "ALMURTA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3980",
		"state": "VIC",
		"locality": "BLIND BIGHT",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "Metro",
		"X073": "Non-Metro"
		}, {
		"postcode": "3981",
		"state": "VIC",
		"locality": "BAYLES",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3984",
		"state": "VIC",
		"locality": "ADAMS ESTATE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3987",
		"state": "VIC",
		"locality": "NYORA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "MixVIC",
		"X073": "Non-Metro"
		}, {
		"postcode": "3988",
		"state": "VIC",
		"locality": "MOUNTAIN VIEW",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3990",
		"state": "VIC",
		"locality": "GLEN FORBES",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3991",
		"state": "VIC",
		"locality": "BASS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3992",
		"state": "VIC",
		"locality": "BLACKWOOD FOREST",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3995",
		"state": "VIC",
		"locality": "ANDERSON",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "3996",
		"state": "VIC",
		"locality": "INVERLOCH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "Regional",
		"X073": "Non-Metro"
		}, {
		"postcode": "4000",
		"state": "QLD",
		"locality": "BRISBANE ADELAIDE STREET",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X096": "Q",
		"X073": "Metropolitan"
		}, {
		"postcode": "4005",
		"state": "QLD",
		"locality": "NEW FARM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "4006",
		"state": "QLD",
		"locality": "BOWEN HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X096": "Q",
		"X073": "Metropolitan"
		}, {
		"postcode": "4007",
		"state": "QLD",
		"locality": "ASCOT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "4008",
		"state": "QLD",
		"locality": "BRISBANE AIRPORT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "4009",
		"state": "QLD",
		"locality": "EAGLE FARM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4010",
		"state": "QLD",
		"locality": "ALBION",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X096": "Q",
		"X073": "Metropolitan"
		}, {
		"postcode": "4011",
		"state": "QLD",
		"locality": "CLAYFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X096": "Q",
		"X073": "Metropolitan"
		}, {
		"postcode": "4012",
		"state": "QLD",
		"locality": "NUNDAH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4013",
		"state": "QLD",
		"locality": "NORTHGATE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4014",
		"state": "QLD",
		"locality": "BANYO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X096": "Q",
		"X073": "Metropolitan"
		}, {
		"postcode": "4017",
		"state": "QLD",
		"locality": "BRACKEN RIDGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4018",
		"state": "QLD",
		"locality": "FITZGIBBON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4019",
		"state": "QLD",
		"locality": "CLONTARF",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4020",
		"state": "QLD",
		"locality": "NEWPORT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4021",
		"state": "QLD",
		"locality": "KIPPA-RING",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4022",
		"state": "QLD",
		"locality": "ROTHWELL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4025",
		"state": "QLD",
		"locality": "BULWER",
		"X065": "N/A",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4029",
		"state": "QLD",
		"locality": "ROYAL BRISBANE HOSPITAL",
		"X065": "N/A",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4030",
		"state": "QLD",
		"locality": "LUTWYCHE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4031",
		"state": "QLD",
		"locality": "GORDON PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4032",
		"state": "QLD",
		"locality": "CHERMSIDE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4034",
		"state": "QLD",
		"locality": "ASPLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4035",
		"state": "QLD",
		"locality": "ALBANY CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4036",
		"state": "QLD",
		"locality": "BALD HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4037",
		"state": "QLD",
		"locality": "EATONS HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4051",
		"state": "QLD",
		"locality": "ALDERLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4053",
		"state": "QLD",
		"locality": "BROOKSIDE CENTRE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4054",
		"state": "QLD",
		"locality": "ARANA HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4055",
		"state": "QLD",
		"locality": "BUNYA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4059",
		"state": "QLD",
		"locality": "KELVIN GROVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4060",
		"state": "QLD",
		"locality": "ASHGROVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4061",
		"state": "QLD",
		"locality": "THE GAP",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4064",
		"state": "QLD",
		"locality": "MILTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4065",
		"state": "QLD",
		"locality": "BARDON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4066",
		"state": "QLD",
		"locality": "AUCHENFLOWER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4067",
		"state": "QLD",
		"locality": "ST LUCIA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4068",
		"state": "QLD",
		"locality": "CHELMER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4069",
		"state": "QLD",
		"locality": "BROOKFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4070",
		"state": "QLD",
		"locality": "ANSTEAD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4072",
		"state": "QLD",
		"locality": "UNIVERSITY OF QUEENSLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4073",
		"state": "QLD",
		"locality": "SEVENTEEN MILE ROCKS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4074",
		"state": "QLD",
		"locality": "JAMBOREE HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4075",
		"state": "QLD",
		"locality": "CORINDA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4076",
		"state": "QLD",
		"locality": "DARRA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4077",
		"state": "QLD",
		"locality": "DOOLANDELLA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4078",
		"state": "QLD",
		"locality": "ELLEN GROVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4101",
		"state": "QLD",
		"locality": "HIGHGATE HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4102",
		"state": "QLD",
		"locality": "BURANDA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X096": "Q",
		"X073": "Metropolitan"
		}, {
		"postcode": "4103",
		"state": "QLD",
		"locality": "ANNERLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4104",
		"state": "QLD",
		"locality": "YERONGA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4105",
		"state": "QLD",
		"locality": "MOOROOKA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4106",
		"state": "QLD",
		"locality": "BRISBANE MARKET",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4107",
		"state": "QLD",
		"locality": "SALISBURY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4108",
		"state": "QLD",
		"locality": "ARCHERFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4109",
		"state": "QLD",
		"locality": "MACGREGOR",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4110",
		"state": "QLD",
		"locality": "ACACIA RIDGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4111",
		"state": "QLD",
		"locality": "NATHAN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4112",
		"state": "QLD",
		"locality": "KURABY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4113",
		"state": "QLD",
		"locality": "EIGHT MILE PLAINS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4114",
		"state": "QLD",
		"locality": "KINGSTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4115",
		"state": "QLD",
		"locality": "ALGESTER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4116",
		"state": "QLD",
		"locality": "CALAMVALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4117",
		"state": "QLD",
		"locality": "BERRINBA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4118",
		"state": "QLD",
		"locality": "BROWNS PLAINS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4119",
		"state": "QLD",
		"locality": "UNDERWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4120",
		"state": "QLD",
		"locality": "GREENSLOPES",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4121",
		"state": "QLD",
		"locality": "HOLLAND PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4122",
		"state": "QLD",
		"locality": "MANSFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4123",
		"state": "QLD",
		"locality": "ROCHEDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4124",
		"state": "QLD",
		"locality": "BORONIA HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4125",
		"state": "QLD",
		"locality": "MUNRUBEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4127",
		"state": "QLD",
		"locality": "DAISY HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4128",
		"state": "QLD",
		"locality": "SHAILER PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4129",
		"state": "QLD",
		"locality": "LOGANHOLME",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4130",
		"state": "QLD",
		"locality": "CARBROOK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4131",
		"state": "QLD",
		"locality": "LOGANLEA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4132",
		"state": "QLD",
		"locality": "CRESTMEAD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4133",
		"state": "QLD",
		"locality": "CHAMBERS FLAT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4151",
		"state": "QLD",
		"locality": "COORPAROO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4152",
		"state": "QLD",
		"locality": "CAMP HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4153",
		"state": "QLD",
		"locality": "BELMONT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4154",
		"state": "QLD",
		"locality": "GUMDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4155",
		"state": "QLD",
		"locality": "CHANDLER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "4156",
		"state": "QLD",
		"locality": "BURBANK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4157",
		"state": "QLD",
		"locality": "CAPALABA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4158",
		"state": "QLD",
		"locality": "THORNESIDE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4159",
		"state": "QLD",
		"locality": "BIRKDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4160",
		"state": "QLD",
		"locality": "ORMISTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4161",
		"state": "QLD",
		"locality": "ALEXANDRA HILLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4163",
		"state": "QLD",
		"locality": "CLEVELAND",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4164",
		"state": "QLD",
		"locality": "THORNLANDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4165",
		"state": "QLD",
		"locality": "MOUNT COTTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4169",
		"state": "QLD",
		"locality": "EAST BRISBANE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4170",
		"state": "QLD",
		"locality": "CANNON HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4171",
		"state": "QLD",
		"locality": "BALMORAL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X096": "Q",
		"X071": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "4172",
		"state": "QLD",
		"locality": "MURARRIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4173",
		"state": "QLD",
		"locality": "TINGALPA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4174",
		"state": "QLD",
		"locality": "HEMMANT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4178",
		"state": "QLD",
		"locality": "LYTTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4179",
		"state": "QLD",
		"locality": "LOTA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4183",
		"state": "QLD",
		"locality": "STRADBROKE ISLAND",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4184",
		"state": "QLD",
		"locality": "COOCHIEMUDLO ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4205",
		"state": "QLD",
		"locality": "BETHANIA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4207",
		"state": "QLD",
		"locality": "ALBERTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4208",
		"state": "QLD",
		"locality": "GILBERTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4209",
		"state": "QLD",
		"locality": "COOMERA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4210",
		"state": "QLD",
		"locality": "GUANABA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4211",
		"state": "QLD",
		"locality": "ADVANCETOWN",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4212",
		"state": "QLD",
		"locality": "HELENSVALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4213",
		"state": "QLD",
		"locality": "AUSTINVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4214",
		"state": "QLD",
		"locality": "ARUNDEL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4215",
		"state": "QLD",
		"locality": "AUSTRALIA FAIR",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4216",
		"state": "QLD",
		"locality": "BIGGERA WATERS",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4217",
		"state": "QLD",
		"locality": "BENOWA",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4218",
		"state": "QLD",
		"locality": "BROADBEACH",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4219",
		"state": "QLD",
		"locality": "WEST BURLEIGH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4220",
		"state": "QLD",
		"locality": "BURLEIGH DC",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4221",
		"state": "QLD",
		"locality": "ELANORA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4222",
		"state": "QLD",
		"locality": "GRIFFITH UNIVERSITY",
		"X065": "N/A",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4223",
		"state": "QLD",
		"locality": "CURRUMBIN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4224",
		"state": "QLD",
		"locality": "TUGUN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4225",
		"state": "QLD",
		"locality": "BILINGA",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4226",
		"state": "QLD",
		"locality": "CLEAR ISLAND WATERS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4227",
		"state": "QLD",
		"locality": "REEDY CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4228",
		"state": "QLD",
		"locality": "TALLEBUDGERA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4229",
		"state": "QLD",
		"locality": "BOND UNIVERSITY",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4230",
		"state": "QLD",
		"locality": "ROBINA TOWN CENTRE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4270",
		"state": "QLD",
		"locality": "TAMBORINE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4271",
		"state": "QLD",
		"locality": "EAGLE HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4272",
		"state": "QLD",
		"locality": "NORTH TAMBORINE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4275",
		"state": "QLD",
		"locality": "BENOBBLE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4280",
		"state": "QLD",
		"locality": "JIMBOOMBA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4285",
		"state": "QLD",
		"locality": "ALLENVIEW",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4287",
		"state": "QLD",
		"locality": "BARNEY VIEW",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4300",
		"state": "QLD",
		"locality": "AUGUSTINE HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4301",
		"state": "QLD",
		"locality": "COLLINGWOOD PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4303",
		"state": "QLD",
		"locality": "DINMORE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4304",
		"state": "QLD",
		"locality": "BLACKSTONE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4305",
		"state": "QLD",
		"locality": "BASIN POCKET",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4306",
		"state": "QLD",
		"locality": "AMBERLEY",
		"X065": "Category 1",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4307",
		"state": "QLD",
		"locality": "COLEYVILLE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4309",
		"state": "QLD",
		"locality": "ARATULA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4310",
		"state": "QLD",
		"locality": "ALLANDALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4311",
		"state": "QLD",
		"locality": "ATKINSONS DAM",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4312",
		"state": "QLD",
		"locality": "BRYDEN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4313",
		"state": "QLD",
		"locality": "BIARRA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4314",
		"state": "QLD",
		"locality": "AVOCA VALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4340",
		"state": "QLD",
		"locality": "ASHWELL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4341",
		"state": "QLD",
		"locality": "BLENHEIM",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4342",
		"state": "QLD",
		"locality": "CROWLEY VALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4343",
		"state": "QLD",
		"locality": "ADARE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4344",
		"state": "QLD",
		"locality": "CARPENDALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4345",
		"state": "QLD",
		"locality": "GATTON COLLEGE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4346",
		"state": "QLD",
		"locality": "MARBURG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4347",
		"state": "QLD",
		"locality": "GRANTHAM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4350",
		"state": "QLD",
		"locality": "ATHOL",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4352",
		"state": "QLD",
		"locality": "BALLARD",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4353",
		"state": "QLD",
		"locality": "BERGEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4354",
		"state": "QLD",
		"locality": "DOUGLAS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4355",
		"state": "QLD",
		"locality": "ANDURAMBA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4356",
		"state": "QLD",
		"locality": "BONGEEN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4357",
		"state": "QLD",
		"locality": "BRINGALILY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4358",
		"state": "QLD",
		"locality": "CAMBOOYA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4359",
		"state": "QLD",
		"locality": "BUDGEE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4360",
		"state": "QLD",
		"locality": "NOBBY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4361",
		"state": "QLD",
		"locality": "BACK PLAINS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4362",
		"state": "QLD",
		"locality": "ALLORA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4363",
		"state": "QLD",
		"locality": "SOUTHBROOK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4364",
		"state": "QLD",
		"locality": "BROOKSTEAD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4365",
		"state": "QLD",
		"locality": "LEYBURN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4370",
		"state": "QLD",
		"locality": "ALLAN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4371",
		"state": "QLD",
		"locality": "EMU VALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4372",
		"state": "QLD",
		"locality": "TANNYMOREL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4373",
		"state": "QLD",
		"locality": "KILLARNEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4374",
		"state": "QLD",
		"locality": "DALVEEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4375",
		"state": "QLD",
		"locality": "COTTONVALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4376",
		"state": "QLD",
		"locality": "THULIMBAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4377",
		"state": "QLD",
		"locality": "GLEN NIVEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4378",
		"state": "QLD",
		"locality": "APPLETHORPE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4380",
		"state": "QLD",
		"locality": "AMIENS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4381",
		"state": "QLD",
		"locality": "FLETCHER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4382",
		"state": "QLD",
		"locality": "BALLANDEAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4383",
		"state": "QLD",
		"locality": "JENNINGS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4384",
		"state": "QLD",
		"locality": "LIMEVALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4385",
		"state": "QLD",
		"locality": "BEEBO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4387",
		"state": "QLD",
		"locality": "BRUSH CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4388",
		"state": "QLD",
		"locality": "KURUMBUL",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4390",
		"state": "QLD",
		"locality": "BILLA BILLA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4400",
		"state": "QLD",
		"locality": "KINGSTHORPE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4401",
		"state": "QLD",
		"locality": "ACLAND",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4402",
		"state": "QLD",
		"locality": "COOYAR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4403",
		"state": "QLD",
		"locality": "BRYMAROO",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4404",
		"state": "QLD",
		"locality": "BOWENVILLE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4405",
		"state": "QLD",
		"locality": "BLAXLAND",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4406",
		"state": "QLD",
		"locality": "BOONDANDILLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4407",
		"state": "QLD",
		"locality": "CATTLE CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4408",
		"state": "QLD",
		"locality": "BELL",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4410",
		"state": "QLD",
		"locality": "JANDOWAE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4411",
		"state": "QLD",
		"locality": "WARRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4412",
		"state": "QLD",
		"locality": "BRIGALOW",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4413",
		"state": "QLD",
		"locality": "BAKING BOARD",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4415",
		"state": "QLD",
		"locality": "COLUMBOOLA",
		"X065": "On application",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4416",
		"state": "QLD",
		"locality": "BARRAMORNIE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4417",
		"state": "QLD",
		"locality": "NOORINDOO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4418",
		"state": "QLD",
		"locality": "GULUGUBA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4419",
		"state": "QLD",
		"locality": "COCKATOO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4420",
		"state": "QLD",
		"locality": "BROADMERE",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4421",
		"state": "QLD",
		"locality": "GORANBA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4422",
		"state": "QLD",
		"locality": "COOMRITH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4423",
		"state": "QLD",
		"locality": "GLENMORGAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4424",
		"state": "QLD",
		"locality": "DRILLHAM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4425",
		"state": "QLD",
		"locality": "BOGANDILLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4426",
		"state": "QLD",
		"locality": "JACKSON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4427",
		"state": "QLD",
		"locality": "CLIFFORD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4428",
		"state": "QLD",
		"locality": "PICKANJINNIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4454",
		"state": "QLD",
		"locality": "BAFFLE WEST",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4455",
		"state": "QLD",
		"locality": "BALLAROO",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4461",
		"state": "QLD",
		"locality": "MUCKADILLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4462",
		"state": "QLD",
		"locality": "AMBY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4465",
		"state": "QLD",
		"locality": "DUNKELD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4467",
		"state": "QLD",
		"locality": "MUNGALLALA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4468",
		"state": "QLD",
		"locality": "CLARA CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4470",
		"state": "QLD",
		"locality": "BAKERS BEND",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4471",
		"state": "QLD",
		"locality": "CLAVERTON",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4472",
		"state": "QLD",
		"locality": "BLACKALL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4474",
		"state": "QLD",
		"locality": "ADAVALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4475",
		"state": "QLD",
		"locality": "CHEEPIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4477",
		"state": "QLD",
		"locality": "AUGATHELLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4478",
		"state": "QLD",
		"locality": "BAYRICK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4479",
		"state": "QLD",
		"locality": "COOLADDI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4480",
		"state": "QLD",
		"locality": "EROMANGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4481",
		"state": "QLD",
		"locality": "FARRARS CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4482",
		"state": "QLD",
		"locality": "BIRDSVILLE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4486",
		"state": "QLD",
		"locality": "DIRRANBANDI",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4487",
		"state": "QLD",
		"locality": "BEGONIA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4488",
		"state": "QLD",
		"locality": "BOLLON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4489",
		"state": "QLD",
		"locality": "WYANDRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4490",
		"state": "QLD",
		"locality": "BARRINGUN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4491",
		"state": "QLD",
		"locality": "EULO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4492",
		"state": "QLD",
		"locality": "BULLAWARRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4493",
		"state": "QLD",
		"locality": "HUNGERFORD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4494",
		"state": "QLD",
		"locality": "BUNGUNYA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4496",
		"state": "QLD",
		"locality": "NORTH TALWOOD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4497",
		"state": "QLD",
		"locality": "DAYMAR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4498",
		"state": "QLD",
		"locality": "KIOMA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4500",
		"state": "QLD",
		"locality": "BRAY PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4501",
		"state": "QLD",
		"locality": "LAWNTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4502",
		"state": "QLD",
		"locality": "PETRIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4503",
		"state": "QLD",
		"locality": "DAKABIN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4504",
		"state": "QLD",
		"locality": "NARANGBA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4505",
		"state": "QLD",
		"locality": "BURPENGARY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4506",
		"state": "QLD",
		"locality": "MOORINA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4507",
		"state": "QLD",
		"locality": "BANKSIA BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4508",
		"state": "QLD",
		"locality": "DECEPTION BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4509",
		"state": "QLD",
		"locality": "MANGO HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4510",
		"state": "QLD",
		"locality": "BEACHMERE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4511",
		"state": "QLD",
		"locality": "GODWIN BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4512",
		"state": "QLD",
		"locality": "BRACALBA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4514",
		"state": "QLD",
		"locality": "BELLTHORPE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4515",
		"state": "QLD",
		"locality": "GLENFERN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4516",
		"state": "QLD",
		"locality": "ELIMBAH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4517",
		"state": "QLD",
		"locality": "BEERBURRUM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4518",
		"state": "QLD",
		"locality": "GLASS HOUSE MOUNTAINS",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4519",
		"state": "QLD",
		"locality": "BEERWAH",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4520",
		"state": "QLD",
		"locality": "ARMSTRONG CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4521",
		"state": "QLD",
		"locality": "CAMPBELLS POCKET",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4550",
		"state": "QLD",
		"locality": "LANDSBOROUGH",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4551",
		"state": "QLD",
		"locality": "AROONA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4552",
		"state": "QLD",
		"locality": "BALD KNOB",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4553",
		"state": "QLD",
		"locality": "DIAMOND VALLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4554",
		"state": "QLD",
		"locality": "EUDLO",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "4555",
		"state": "QLD",
		"locality": "CHEVALLUM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4556",
		"state": "QLD",
		"locality": "BUDERIM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4557",
		"state": "QLD",
		"locality": "MOOLOOLABA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4558",
		"state": "QLD",
		"locality": "COTTON TREE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4559",
		"state": "QLD",
		"locality": "DIDDILLIBAH",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4560",
		"state": "QLD",
		"locality": "BLI BLI",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4561",
		"state": "QLD",
		"locality": "BRIDGES",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4562",
		"state": "QLD",
		"locality": "BELLI PARK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4563",
		"state": "QLD",
		"locality": "BLACK MOUNTAIN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4564",
		"state": "QLD",
		"locality": "MARCOOLA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4565",
		"state": "QLD",
		"locality": "BOREEN POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4566",
		"state": "QLD",
		"locality": "NOOSAVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4567",
		"state": "QLD",
		"locality": "CASTAWAYS BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4568",
		"state": "QLD",
		"locality": "FEDERAL",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4569",
		"state": "QLD",
		"locality": "COORAN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4570",
		"state": "QLD",
		"locality": "AMAMOOR",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4571",
		"state": "QLD",
		"locality": "COMO",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4572",
		"state": "QLD",
		"locality": "ALEXANDRA HEADLAND",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4573",
		"state": "QLD",
		"locality": "COOLUM BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4574",
		"state": "QLD",
		"locality": "COOLABINE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4575",
		"state": "QLD",
		"locality": "BIRTINYA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4580",
		"state": "QLD",
		"locality": "COOLOOLA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4581",
		"state": "QLD",
		"locality": "EURONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4600",
		"state": "QLD",
		"locality": "BLACK SNAKE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4601",
		"state": "QLD",
		"locality": "BARAMBAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4605",
		"state": "QLD",
		"locality": "BARLIL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4606",
		"state": "QLD",
		"locality": "CHELMSFORD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4608",
		"state": "QLD",
		"locality": "CHARLESTOWN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4610",
		"state": "QLD",
		"locality": "ALICE CREEK",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4611",
		"state": "QLD",
		"locality": "MARSHLANDS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4612",
		"state": "QLD",
		"locality": "HIVESVILLE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4613",
		"state": "QLD",
		"locality": "ABBEYWOOD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4614",
		"state": "QLD",
		"locality": "NEUMGNA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4615",
		"state": "QLD",
		"locality": "BARKER CREEK FLAT",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4620",
		"state": "QLD",
		"locality": "ARAMARA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4621",
		"state": "QLD",
		"locality": "BIGGENDEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4625",
		"state": "QLD",
		"locality": "ARANBANGA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4626",
		"state": "QLD",
		"locality": "BEERON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4627",
		"state": "QLD",
		"locality": "ABERCORN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4630",
		"state": "QLD",
		"locality": "BANCROFT",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4650",
		"state": "QLD",
		"locality": "ALDERSHOT",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4655",
		"state": "QLD",
		"locality": "BOORAL",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4659",
		"state": "QLD",
		"locality": "BEELBI CREEK",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4660",
		"state": "QLD",
		"locality": "ABINGTON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4662",
		"state": "QLD",
		"locality": "TORBANLEA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4670",
		"state": "QLD",
		"locality": "ABBOTSFORD",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "BOOLBOONDA",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "BOOYAL",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "BULLYARD",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "BUNGADOO",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "DALYSFORD",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "DAMASCUS",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "DELAN",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "DOUGHBOY",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "DRINAN",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "DUINGAL",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "GAETA",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "GIN GIN",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "GOOD NIGHT",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "HORSE CAMP",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "KOLONGA",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "LAKE MONDURAN",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "MAROONDAN",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "MCILWRAITH",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "MOLANGUL",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "MONDURAN",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "MOOLBOOLAMAN",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "MORGANVILLE",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "MOUNT PERRY",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "MUNGY",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "NEARUM",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "NEW MOONTA",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "REDHILL FARMS",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "SKYRING RESERVE",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "ST AGNES",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "ST KILDA",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "TAKILBERAN",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "TIRROAN",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "WALLAVILLE",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "WONBAH",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4671",
		"state": "QLD",
		"locality": "WONBAH FOREST",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4673",
		"state": "QLD",
		"locality": "MIARA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4674",
		"state": "QLD",
		"locality": "BAFFLE CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4676",
		"state": "QLD",
		"locality": "GINDORAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4677",
		"state": "QLD",
		"locality": "AGNES WATER",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4678",
		"state": "QLD",
		"locality": "BOROREN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4680",
		"state": "QLD",
		"locality": "BARNEY POINT",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4694",
		"state": "QLD",
		"locality": "ALDOGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4695",
		"state": "QLD",
		"locality": "AMBROSE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4697",
		"state": "QLD",
		"locality": "RAGLAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4699",
		"state": "QLD",
		"locality": "BAJOOL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4700",
		"state": "QLD",
		"locality": "ALLENSTOWN",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "4701",
		"state": "QLD",
		"locality": "BERSERKER",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "ALBERTA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "ALSACE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "ALTON DOWNS",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "ANAKIE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "ARGOON",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "BALCOMBA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "BANANA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "BARALABA",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "BARNARD",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "BINGEGANG",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "BLACKDOWN",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "BLUFF",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "BOOLBURRA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "BOULDERCOMBE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "BUSHLEY",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "CANAL CREEK",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "CANOONA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "CAWARRAL",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "CENTRAL QUEENSLAND MC",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "COMET",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "CONSUELO",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "COOMOO",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "COOROOMAN",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "COORUMBENE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "COOWONGA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "DALMA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "DINGO",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "DIXALEA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "DULULU",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "DUMPY CREEK",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "ETNA CREEK",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "GAINSFORD",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "GARNANT",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "GINDIE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "GLENROY",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "GOGANGO",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "GOOMALLY",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "GOOVIGEN",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "GOOWARRA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "GRACEMERE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "JAMBIN",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "JARDINE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "JELLINBAH",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "JOSKELEIGH",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "KABRA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "KALAPA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "KEPPEL SANDS",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "KOKOTUNGO",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "KUNWARARA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "LOWESBY",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "MACKENZIE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "MARMOR",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "MIDGEE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "MILMAN",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "MIMOSA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "MORINISH",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "MORINISH SOUTH",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "MOUNT CHALMERS",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "NINE MILE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "PARKHURST",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "PHEASANT CREEK",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "PINK LILY",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "PLUM TREE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "RIDGELANDS",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "ROLLESTON",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "ROSSMOYA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "RUBYVALE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "SAPPHIRE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "SHOALWATER",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "SMOKY CREEK",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "SOUTH YAAMBA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "STANAGE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "STANWELL",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "STEWARTON",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "TARRAMBA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "THE CAVES",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "THE GEMFIELDS",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "THOMPSON POINT",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "TUNGAMULL",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "ULOGIE",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "WALLAROO",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "WESTWOOD",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "WILLOWS",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "WILLOWS GEMFIELDS",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "WOOLEIN",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "WOOROONA",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "WOWAN",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4702",
		"state": "QLD",
		"locality": "WYCARBAH",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4703",
		"state": "QLD",
		"locality": "ADELAIDE PARK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4704",
		"state": "QLD",
		"locality": "WATTLEBANK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4705",
		"state": "QLD",
		"locality": "CLARKE CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4706",
		"state": "QLD",
		"locality": "OGMORE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4707",
		"state": "QLD",
		"locality": "COLLAROY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4709",
		"state": "QLD",
		"locality": "TIERI",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4710",
		"state": "QLD",
		"locality": "EMU PARK",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4711",
		"state": "QLD",
		"locality": "GLENDALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4712",
		"state": "QLD",
		"locality": "DUARINGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4713",
		"state": "QLD",
		"locality": "WOORABINDA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4714",
		"state": "QLD",
		"locality": "BAREE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4715",
		"state": "QLD",
		"locality": "BILOELA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4716",
		"state": "QLD",
		"locality": "LAWGI DAWES",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4717",
		"state": "QLD",
		"locality": "BLACKWATER",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4718",
		"state": "QLD",
		"locality": "BAUHINIA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4719",
		"state": "QLD",
		"locality": "CAMBOON",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4720",
		"state": "QLD",
		"locality": "EMERALD",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4721",
		"state": "QLD",
		"locality": "ARGYLL",
		"X065": "On application",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4722",
		"state": "QLD",
		"locality": "BUCKLAND",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4723",
		"state": "QLD",
		"locality": "BELCONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4724",
		"state": "QLD",
		"locality": "ALPHA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4725",
		"state": "QLD",
		"locality": "BARCALDINE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4726",
		"state": "QLD",
		"locality": "ARAMAC",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4727",
		"state": "QLD",
		"locality": "ILFRACOMBE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4728",
		"state": "QLD",
		"locality": "DUNROBIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4730",
		"state": "QLD",
		"locality": "CAMOOLA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4731",
		"state": "QLD",
		"locality": "ISISFORD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4732",
		"state": "QLD",
		"locality": "MUTTABURRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4733",
		"state": "QLD",
		"locality": "CORFIELD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4735",
		"state": "QLD",
		"locality": "DIAMANTINA LAKES",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4736",
		"state": "QLD",
		"locality": "JUNDAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4737",
		"state": "QLD",
		"locality": "ARMSTRONG BEACH",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4738",
		"state": "QLD",
		"locality": "ILBILBIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4739",
		"state": "QLD",
		"locality": "CARMILA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4740",
		"state": "QLD",
		"locality": "ALEXANDRA",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4741",
		"state": "QLD",
		"locality": "BALL BAY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4742",
		"state": "QLD",
		"locality": "BURTON",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4743",
		"state": "QLD",
		"locality": "GLENDEN",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4744",
		"state": "QLD",
		"locality": "MORANBAH",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4745",
		"state": "QLD",
		"locality": "DYSART",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4746",
		"state": "QLD",
		"locality": "MAY DOWNS",
		"X065": "N/A",
		"X066": "On application",
		"X068": true,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4750",
		"state": "QLD",
		"locality": "BUCASIA",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4751",
		"state": "QLD",
		"locality": "GREENMOUNT",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4753",
		"state": "QLD",
		"locality": "DEVEREUX CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4754",
		"state": "QLD",
		"locality": "BENHOLME",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4756",
		"state": "QLD",
		"locality": "FINCH HATTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4757",
		"state": "QLD",
		"locality": "BROKEN RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4798",
		"state": "QLD",
		"locality": "CALEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4799",
		"state": "QLD",
		"locality": "BLOOMSBURY",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4800",
		"state": "QLD",
		"locality": "ANDROMACHE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4801",
		"state": "QLD",
		"locality": "HAYMAN ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4802",
		"state": "QLD",
		"locality": "AIRLIE BEACH",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4803",
		"state": "QLD",
		"locality": "HAMILTON ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4804",
		"state": "QLD",
		"locality": "COLLINSVILLE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4805",
		"state": "QLD",
		"locality": "BOWEN",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4806",
		"state": "QLD",
		"locality": "CARSTAIRS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4807",
		"state": "QLD",
		"locality": "AIRDMILLAN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4808",
		"state": "QLD",
		"locality": "BRANDON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4809",
		"state": "QLD",
		"locality": "BARRATTA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4810",
		"state": "QLD",
		"locality": "BELGIAN GARDENS",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4811",
		"state": "QLD",
		"locality": "CLUDEN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4812",
		"state": "QLD",
		"locality": "CURRAJONG",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4813",
		"state": "QLD",
		"locality": "TOWNSVILLE MILPO",
		"X065": "N/A",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4814",
		"state": "QLD",
		"locality": "AITKENVALE",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4815",
		"state": "QLD",
		"locality": "CONDON",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4816",
		"state": "QLD",
		"locality": "ALLIGATOR CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4817",
		"state": "QLD",
		"locality": "ALICE RIVER",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4818",
		"state": "QLD",
		"locality": "BEACH HOLM",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4819",
		"state": "QLD",
		"locality": "MAGNETIC ISLAND",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4820",
		"state": "QLD",
		"locality": "ALABAMA HILL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4821",
		"state": "QLD",
		"locality": "DUTTON RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4822",
		"state": "QLD",
		"locality": "ALBION",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4823",
		"state": "QLD",
		"locality": "CARPENTARIA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4824",
		"state": "QLD",
		"locality": "CLONCURRY",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4825",
		"state": "QLD",
		"locality": "ALPURRURULAM",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4828",
		"state": "QLD",
		"locality": "CAMOOWEAL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4829",
		"state": "QLD",
		"locality": "AMAROO",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4830",
		"state": "QLD",
		"locality": "BURKETOWN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4849",
		"state": "QLD",
		"locality": "CARDWELL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4850",
		"state": "QLD",
		"locality": "ABERGOWRIE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4852",
		"state": "QLD",
		"locality": "BINGIL BAY",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4854",
		"state": "QLD",
		"locality": "BILYANA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4855",
		"state": "QLD",
		"locality": "DAVESON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4856",
		"state": "QLD",
		"locality": "GOOLBOO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4857",
		"state": "QLD",
		"locality": "SILKWOOD EAST",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4858",
		"state": "QLD",
		"locality": "COMOON LOOP",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4859",
		"state": "QLD",
		"locality": "NO. 6 BRANCH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4860",
		"state": "QLD",
		"locality": "BAMBOO CREEK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4861",
		"state": "QLD",
		"locality": "BABINDA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4865",
		"state": "QLD",
		"locality": "GOLDSBOROUGH",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4868",
		"state": "QLD",
		"locality": "BAYVIEW HEIGHTS",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4869",
		"state": "QLD",
		"locality": "BENTLEY PARK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4870",
		"state": "QLD",
		"locality": "AEROGLEN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4871",
		"state": "QLD",
		"locality": "ALMADEN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4872",
		"state": "QLD",
		"locality": "BARRINE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4873",
		"state": "QLD",
		"locality": "BAMBOO",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4874",
		"state": "QLD",
		"locality": "EVANS LANDING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4875",
		"state": "QLD",
		"locality": "BADU ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4876",
		"state": "QLD",
		"locality": "BAMAGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4877",
		"state": "QLD",
		"locality": "CRAIGLIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "4878",
		"state": "QLD",
		"locality": "BARRON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4879",
		"state": "QLD",
		"locality": "CLIFTON BEACH",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4880",
		"state": "QLD",
		"locality": "ARRIGA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4881",
		"state": "QLD",
		"locality": "KOAH",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4882",
		"state": "QLD",
		"locality": "TOLGA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4883",
		"state": "QLD",
		"locality": "ATHERTON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4884",
		"state": "QLD",
		"locality": "GADGARRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4885",
		"state": "QLD",
		"locality": "BUTCHERS CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4886",
		"state": "QLD",
		"locality": "BEATRICE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4887",
		"state": "QLD",
		"locality": "HERBERTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4888",
		"state": "QLD",
		"locality": "EVELYN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "4890",
		"state": "QLD",
		"locality": "HOWITT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4891",
		"state": "QLD",
		"locality": "KARUMBA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4892",
		"state": "QLD",
		"locality": "ABINGDON DOWNS",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "4895",
		"state": "QLD",
		"locality": "AYTON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5000",
		"state": "SA",
		"locality": "ADELAIDE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5006",
		"state": "SA",
		"locality": "NORTH ADELAIDE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5007",
		"state": "SA",
		"locality": "BOWDEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5008",
		"state": "SA",
		"locality": "CROYDON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5009",
		"state": "SA",
		"locality": "ALLENBY GARDENS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5010",
		"state": "SA",
		"locality": "ANGLE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5011",
		"state": "SA",
		"locality": "ST CLAIR",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5012",
		"state": "SA",
		"locality": "ATHOL PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5013",
		"state": "SA",
		"locality": "GILLMAN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5014",
		"state": "SA",
		"locality": "ALBERT PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5015",
		"state": "SA",
		"locality": "BIRKENHEAD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5016",
		"state": "SA",
		"locality": "LARGS BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5017",
		"state": "SA",
		"locality": "OSBORNE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5018",
		"state": "SA",
		"locality": "NORTH HAVEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5019",
		"state": "SA",
		"locality": "EXETER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5020",
		"state": "SA",
		"locality": "WEST LAKES SHORE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5021",
		"state": "SA",
		"locality": "WEST LAKES",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5022",
		"state": "SA",
		"locality": "GRANGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5023",
		"state": "SA",
		"locality": "FINDON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5024",
		"state": "SA",
		"locality": "FULHAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5025",
		"state": "SA",
		"locality": "FLINDERS PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5031",
		"state": "SA",
		"locality": "MILE END",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5032",
		"state": "SA",
		"locality": "BROOKLYN PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5033",
		"state": "SA",
		"locality": "COWANDILLA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5034",
		"state": "SA",
		"locality": "CLARENCE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5035",
		"state": "SA",
		"locality": "ASHFORD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5037",
		"state": "SA",
		"locality": "GLANDORE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5038",
		"state": "SA",
		"locality": "CAMDEN PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5039",
		"state": "SA",
		"locality": "CLARENCE GARDENS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5040",
		"state": "SA",
		"locality": "NOVAR GARDENS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5041",
		"state": "SA",
		"locality": "COLONEL LIGHT GARDENS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5042",
		"state": "SA",
		"locality": "BEDFORD PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5043",
		"state": "SA",
		"locality": "ASCOT PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5044",
		"state": "SA",
		"locality": "GLENGOWRIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5045",
		"state": "SA",
		"locality": "GLENELG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5046",
		"state": "SA",
		"locality": "OAKLANDS PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5047",
		"state": "SA",
		"locality": "DARLINGTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5048",
		"state": "SA",
		"locality": "BRIGHTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5049",
		"state": "SA",
		"locality": "KINGSTON PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5050",
		"state": "SA",
		"locality": "BELLEVUE HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5051",
		"state": "SA",
		"locality": "BLACKWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5052",
		"state": "SA",
		"locality": "BELAIR",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5061",
		"state": "SA",
		"locality": "HYDE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5062",
		"state": "SA",
		"locality": "BROWN HILL CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5063",
		"state": "SA",
		"locality": "EASTWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5064",
		"state": "SA",
		"locality": "GLEN OSMOND",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5065",
		"state": "SA",
		"locality": "DULWICH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5066",
		"state": "SA",
		"locality": "BEAUMONT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5067",
		"state": "SA",
		"locality": "BEULAH PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5068",
		"state": "SA",
		"locality": "HEATHPOOL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5069",
		"state": "SA",
		"locality": "COLLEGE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5070",
		"state": "SA",
		"locality": "FELIXSTOW",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5072",
		"state": "SA",
		"locality": "AULDANA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5073",
		"state": "SA",
		"locality": "HECTORVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5074",
		"state": "SA",
		"locality": "CAMPBELLTOWN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5075",
		"state": "SA",
		"locality": "DERNANCOURT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5076",
		"state": "SA",
		"locality": "ATHELSTONE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5081",
		"state": "SA",
		"locality": "COLLINSWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5082",
		"state": "SA",
		"locality": "FITZROY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5083",
		"state": "SA",
		"locality": "BROADVIEW",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5084",
		"state": "SA",
		"locality": "BLAIR ATHOL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5085",
		"state": "SA",
		"locality": "CLEARVIEW",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5086",
		"state": "SA",
		"locality": "GILLES PLAINS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5087",
		"state": "SA",
		"locality": "KLEMZIG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5088",
		"state": "SA",
		"locality": "HOLDEN HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5089",
		"state": "SA",
		"locality": "HIGHBURY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5090",
		"state": "SA",
		"locality": "HOPE VALLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5091",
		"state": "SA",
		"locality": "BANKSIA PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5092",
		"state": "SA",
		"locality": "MODBURY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5093",
		"state": "SA",
		"locality": "PARA VISTA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5094",
		"state": "SA",
		"locality": "CAVAN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5095",
		"state": "SA",
		"locality": "MAWSON LAKES",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5096",
		"state": "SA",
		"locality": "GULFVIEW HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5097",
		"state": "SA",
		"locality": "REDWOOD PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5098",
		"state": "SA",
		"locality": "INGLE FARM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5106",
		"state": "SA",
		"locality": "PARAFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5107",
		"state": "SA",
		"locality": "GREEN FIELDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5108",
		"state": "SA",
		"locality": "PARALOWIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5109",
		"state": "SA",
		"locality": "BRAHMA LODGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5110",
		"state": "SA",
		"locality": "BOLIVAR",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5111",
		"state": "SA",
		"locality": "EDINBURGH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5112",
		"state": "SA",
		"locality": "ELIZABETH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5113",
		"state": "SA",
		"locality": "DAVOREN PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5114",
		"state": "SA",
		"locality": "ANDREWS FARM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5115",
		"state": "SA",
		"locality": "KUDLA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5116",
		"state": "SA",
		"locality": "EVANSTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5117",
		"state": "SA",
		"locality": "ANGLE VALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5118",
		"state": "SA",
		"locality": "BIBARINGA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5120",
		"state": "SA",
		"locality": "BUCKLAND PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5121",
		"state": "SA",
		"locality": "MACDONALD PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5125",
		"state": "SA",
		"locality": "GOLDEN GROVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5126",
		"state": "SA",
		"locality": "FAIRVIEW PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5127",
		"state": "SA",
		"locality": "WYNN VALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5131",
		"state": "SA",
		"locality": "HOUGHTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5132",
		"state": "SA",
		"locality": "PARACOMBE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5133",
		"state": "SA",
		"locality": "INGLEWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5134",
		"state": "SA",
		"locality": "CHERRYVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5136",
		"state": "SA",
		"locality": "NORTON SUMMIT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5137",
		"state": "SA",
		"locality": "ASHTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5138",
		"state": "SA",
		"locality": "BASKET RANGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "5139",
		"state": "SA",
		"locality": "FOREST RANGE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "5140",
		"state": "SA",
		"locality": "GREENHILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5141",
		"state": "SA",
		"locality": "HORSNELL GULLY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5142",
		"state": "SA",
		"locality": "URAIDLA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5144",
		"state": "SA",
		"locality": "CAREY GULLY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5150",
		"state": "SA",
		"locality": "LEAWOOD GARDENS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5151",
		"state": "SA",
		"locality": "PICCADILLY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5152",
		"state": "SA",
		"locality": "CLELAND",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5153",
		"state": "SA",
		"locality": "BIGGS FLAT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5154",
		"state": "SA",
		"locality": "ALDGATE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5155",
		"state": "SA",
		"locality": "BRIDGEWATER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5156",
		"state": "SA",
		"locality": "UPPER STURT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5157",
		"state": "SA",
		"locality": "ASHBOURNE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5158",
		"state": "SA",
		"locality": "HALLETT COVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5159",
		"state": "SA",
		"locality": "ABERFOYLE PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5160",
		"state": "SA",
		"locality": "LONSDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5161",
		"state": "SA",
		"locality": "OLD REYNELLA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5162",
		"state": "SA",
		"locality": "MORPHETT VALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5163",
		"state": "SA",
		"locality": "HACKHAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5164",
		"state": "SA",
		"locality": "CHRISTIE DOWNS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5165",
		"state": "SA",
		"locality": "CHRISTIES BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5166",
		"state": "SA",
		"locality": "O'SULLIVAN BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5167",
		"state": "SA",
		"locality": "PORT NOARLUNGA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5168",
		"state": "SA",
		"locality": "NOARLUNGA CENTRE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5169",
		"state": "SA",
		"locality": "MOANA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5170",
		"state": "SA",
		"locality": "MASLIN BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5171",
		"state": "SA",
		"locality": "BLEWITT SPRINGS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5172",
		"state": "SA",
		"locality": "DINGABLEDINGA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5173",
		"state": "SA",
		"locality": "ALDINGA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5174",
		"state": "SA",
		"locality": "SELLICKS BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5201",
		"state": "SA",
		"locality": "BLACKFELLOWS CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5202",
		"state": "SA",
		"locality": "HINDMARSH TIERS",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5203",
		"state": "SA",
		"locality": "BALD HILLS",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5204",
		"state": "SA",
		"locality": "CAPE JERVIS",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5210",
		"state": "SA",
		"locality": "MOUNT COMPASS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5211",
		"state": "SA",
		"locality": "BACK VALLEY",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5212",
		"state": "SA",
		"locality": "PORT ELLIOT",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5213",
		"state": "SA",
		"locality": "MIDDLETON",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5214",
		"state": "SA",
		"locality": "CURRENCY CREEK",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5220",
		"state": "SA",
		"locality": "PARNDANA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5221",
		"state": "SA",
		"locality": "AMERICAN RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5222",
		"state": "SA",
		"locality": "AMERICAN BEACH",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5223",
		"state": "SA",
		"locality": "BAY OF SHOALS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5231",
		"state": "SA",
		"locality": "CHAIN OF PONDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "5232",
		"state": "SA",
		"locality": "CUDLEE CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5233",
		"state": "SA",
		"locality": "FORRESTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "5234",
		"state": "SA",
		"locality": "BIRDWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5235",
		"state": "SA",
		"locality": "CROMER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5236",
		"state": "SA",
		"locality": "TUNGKILLO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5237",
		"state": "SA",
		"locality": "APAMURRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5238",
		"state": "SA",
		"locality": "ANGAS VALLEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5240",
		"state": "SA",
		"locality": "LENSWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5241",
		"state": "SA",
		"locality": "LOBETHAL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5242",
		"state": "SA",
		"locality": "BALHANNAH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5243",
		"state": "SA",
		"locality": "OAKBANK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "5244",
		"state": "SA",
		"locality": "CHARLESTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5245",
		"state": "SA",
		"locality": "HAHNDORF",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5250",
		"state": "SA",
		"locality": "BLAKISTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5251",
		"state": "SA",
		"locality": "BUGLE RANGES",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5252",
		"state": "SA",
		"locality": "BRUKUNGA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X069": "Low",
		"X070": true,
		"X073": "Metropolitan"
		}, {
		"postcode": "5253",
		"state": "SA",
		"locality": "AVOCA DELL",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5254",
		"state": "SA",
		"locality": "CALLINGTON",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5255",
		"state": "SA",
		"locality": "ANGAS PLAINS",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5256",
		"state": "SA",
		"locality": "CLAYTON BAY",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5259",
		"state": "SA",
		"locality": "ASHVILLE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5260",
		"state": "SA",
		"locality": "ELWOMPLE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5261",
		"state": "SA",
		"locality": "COOKE PLAINS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5262",
		"state": "SA",
		"locality": "BINNUM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5263",
		"state": "SA",
		"locality": "COONAWARRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5264",
		"state": "SA",
		"locality": "COORONG",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5265",
		"state": "SA",
		"locality": "COONALPYN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5266",
		"state": "SA",
		"locality": "BUNBURY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5267",
		"state": "SA",
		"locality": "BRIMBAGO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5268",
		"state": "SA",
		"locality": "BANGHAM",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5269",
		"state": "SA",
		"locality": "CUSTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5270",
		"state": "SA",
		"locality": "BUCKINGHAM",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5271",
		"state": "SA",
		"locality": "BOOL LAGOON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5272",
		"state": "SA",
		"locality": "COLES",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5273",
		"state": "SA",
		"locality": "AVENUE RANGE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5275",
		"state": "SA",
		"locality": "BLACKFORD",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5276",
		"state": "SA",
		"locality": "BRAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5277",
		"state": "SA",
		"locality": "COMAUM",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5278",
		"state": "SA",
		"locality": "KALANGADOO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5279",
		"state": "SA",
		"locality": "KOORINE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5280",
		"state": "SA",
		"locality": "MILLICENT",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5290",
		"state": "SA",
		"locality": "MOUNT GAMBIER",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5291",
		"state": "SA",
		"locality": "ALLENDALE EAST",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5301",
		"state": "SA",
		"locality": "CARCUMA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5302",
		"state": "SA",
		"locality": "LAMEROO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5303",
		"state": "SA",
		"locality": "PARILLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5304",
		"state": "SA",
		"locality": "KARTE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5306",
		"state": "SA",
		"locality": "WYNARKA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5307",
		"state": "SA",
		"locality": "KAROONDA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5308",
		"state": "SA",
		"locality": "COPEVILLE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5309",
		"state": "SA",
		"locality": "BORRIKA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5310",
		"state": "SA",
		"locality": "CALIPH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5311",
		"state": "SA",
		"locality": "ALAWOONA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5312",
		"state": "SA",
		"locality": "VEITCH",
		"X065": "N/A",
		"X066": "N/A",
		"X073": "Non-Metro"
		}, {
		"postcode": "5320",
		"state": "SA",
		"locality": "BEATTY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5321",
		"state": "SA",
		"locality": "CADELL",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5322",
		"state": "SA",
		"locality": "GOLDEN HEIGHTS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5330",
		"state": "SA",
		"locality": "BOOLGUN",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5331",
		"state": "SA",
		"locality": "KINGSTON ON MURRAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5332",
		"state": "SA",
		"locality": "MOOROOK",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5333",
		"state": "SA",
		"locality": "BOOKPURNONG",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5340",
		"state": "SA",
		"locality": "MUNDIC CREEK",
		"X065": "On application",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5341",
		"state": "SA",
		"locality": "RENMARK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5342",
		"state": "SA",
		"locality": "MONASH",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5343",
		"state": "SA",
		"locality": "BERRI",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5344",
		"state": "SA",
		"locality": "GLOSSOP",
		"X065": "On application",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5345",
		"state": "SA",
		"locality": "BARMERA",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5346",
		"state": "SA",
		"locality": "COBDOGLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5350",
		"state": "SA",
		"locality": "ROSEDALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "5351",
		"state": "SA",
		"locality": "ALTONA",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5352",
		"state": "SA",
		"locality": "BETHANY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5353",
		"state": "SA",
		"locality": "ANGASTON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5354",
		"state": "SA",
		"locality": "BAKARA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5355",
		"state": "SA",
		"locality": "DAVEYSTON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5356",
		"state": "SA",
		"locality": "ANNADALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5357",
		"state": "SA",
		"locality": "BLANCHETOWN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5360",
		"state": "SA",
		"locality": "GREENOCK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5371",
		"state": "SA",
		"locality": "MORN HILL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5372",
		"state": "SA",
		"locality": "FREELING",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5373",
		"state": "SA",
		"locality": "ALLENDALE NORTH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5374",
		"state": "SA",
		"locality": "AUSTRALIA PLAINS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5381",
		"state": "SA",
		"locality": "BRADY CREEK",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5400",
		"state": "SA",
		"locality": "MAGDALA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5401",
		"state": "SA",
		"locality": "ALMA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5410",
		"state": "SA",
		"locality": "LINWOOD",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5411",
		"state": "SA",
		"locality": "GILES CORNER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5412",
		"state": "SA",
		"locality": "NAVAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5413",
		"state": "SA",
		"locality": "APOINGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5414",
		"state": "SA",
		"locality": "MANOORA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5415",
		"state": "SA",
		"locality": "MINTARO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5416",
		"state": "SA",
		"locality": "FARRELL FLAT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5417",
		"state": "SA",
		"locality": "BALAH",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5418",
		"state": "SA",
		"locality": "COLLINSVILLE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5419",
		"state": "SA",
		"locality": "CANOWIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5420",
		"state": "SA",
		"locality": "CANOWIE BELT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5421",
		"state": "SA",
		"locality": "FRANKLYN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5422",
		"state": "SA",
		"locality": "CAVENAGH",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5431",
		"state": "SA",
		"locality": "AMYTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5432",
		"state": "SA",
		"locality": "BARATTA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5433",
		"state": "SA",
		"locality": "BRUCE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5434",
		"state": "SA",
		"locality": "BARNDIOOTA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5440",
		"state": "SA",
		"locality": "ABMINGA STATION",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5451",
		"state": "SA",
		"locality": "AUBURN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5452",
		"state": "SA",
		"locality": "LEASINGHAM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5453",
		"state": "SA",
		"locality": "ARMAGH",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5454",
		"state": "SA",
		"locality": "ANDREWS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5455",
		"state": "SA",
		"locality": "HILLTOWN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5460",
		"state": "SA",
		"locality": "BARABBA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5461",
		"state": "SA",
		"locality": "BALAKLAVA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5462",
		"state": "SA",
		"locality": "BLYTH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5464",
		"state": "SA",
		"locality": "ANAMA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5470",
		"state": "SA",
		"locality": "YACKA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5471",
		"state": "SA",
		"locality": "GULNARE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5472",
		"state": "SA",
		"locality": "GEORGETOWN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5473",
		"state": "SA",
		"locality": "GLADSTONE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5480",
		"state": "SA",
		"locality": "APPILA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5481",
		"state": "SA",
		"locality": "BANGOR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5482",
		"state": "SA",
		"locality": "BOOLEROO CENTRE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5483",
		"state": "SA",
		"locality": "MELROSE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5485",
		"state": "SA",
		"locality": "WILMINGTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5490",
		"state": "SA",
		"locality": "CALTOWIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5491",
		"state": "SA",
		"locality": "BELALIE EAST",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5493",
		"state": "SA",
		"locality": "YONGALA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5495",
		"state": "SA",
		"locality": "BAROOTA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5501",
		"state": "SA",
		"locality": "AVON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5502",
		"state": "SA",
		"locality": "FISCHER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5510",
		"state": "SA",
		"locality": "LOCHIEL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5520",
		"state": "SA",
		"locality": "BARUNGA GAP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5521",
		"state": "SA",
		"locality": "REDHILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5522",
		"state": "SA",
		"locality": "FISHERMAN BAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5523",
		"state": "SA",
		"locality": "BEETALOO VALLEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5540",
		"state": "SA",
		"locality": "RISDON PARK",
		"X065": "Category 3",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5550",
		"state": "SA",
		"locality": "BEAUFORT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5552",
		"state": "SA",
		"locality": "KAINTON",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5554",
		"state": "SA",
		"locality": "BOORS PLAIN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5555",
		"state": "SA",
		"locality": "ALFORD",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5556",
		"state": "SA",
		"locality": "NORTH BEACH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5558",
		"state": "SA",
		"locality": "AGERY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5560",
		"state": "SA",
		"locality": "BUTE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5570",
		"state": "SA",
		"locality": "CLINTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5571",
		"state": "SA",
		"locality": "ARDROSSAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5572",
		"state": "SA",
		"locality": "ARTHURTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5573",
		"state": "SA",
		"locality": "BALGOWAN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5575",
		"state": "SA",
		"locality": "BLUFF BEACH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5576",
		"state": "SA",
		"locality": "HONITON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5577",
		"state": "SA",
		"locality": "COUCH BEACH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5580",
		"state": "SA",
		"locality": "CURRAMULKA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5581",
		"state": "SA",
		"locality": "PORT VINCENT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5582",
		"state": "SA",
		"locality": "PORT GILES",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5583",
		"state": "SA",
		"locality": "COOBOWIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5600",
		"state": "SA",
		"locality": "CORUNNA STATION",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5601",
		"state": "SA",
		"locality": "BACKY POINT",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5602",
		"state": "SA",
		"locality": "COWELL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5603",
		"state": "SA",
		"locality": "ARNO BAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5604",
		"state": "SA",
		"locality": "PORT NEILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5605",
		"state": "SA",
		"locality": "BUTLER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5606",
		"state": "SA",
		"locality": "PORT LINCOLN",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5607",
		"state": "SA",
		"locality": "BOSTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5608",
		"state": "SA",
		"locality": "WHYALLA NORRIE",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5609",
		"state": "SA",
		"locality": "WHYALLA JENKINS",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5611",
		"state": "SA",
		"locality": "IRON BARON",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5630",
		"state": "SA",
		"locality": "EDILLILIE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5631",
		"state": "SA",
		"locality": "COCKALEECHIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5632",
		"state": "SA",
		"locality": "KAPINNIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5633",
		"state": "SA",
		"locality": "BOONERDO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5640",
		"state": "SA",
		"locality": "CAMPOONA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5641",
		"state": "SA",
		"locality": "BARNA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5642",
		"state": "SA",
		"locality": "DARKE PEAK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5650",
		"state": "SA",
		"locality": "COOTRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5651",
		"state": "SA",
		"locality": "KYANCUTTA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5652",
		"state": "SA",
		"locality": "PANEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5653",
		"state": "SA",
		"locality": "YANINEE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5654",
		"state": "SA",
		"locality": "COCATA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5655",
		"state": "SA",
		"locality": "BOCKELBERG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5660",
		"state": "SA",
		"locality": "CHILPENUNDA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5661",
		"state": "SA",
		"locality": "KOOLGERA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5670",
		"state": "SA",
		"locality": "BRAMFIELD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5671",
		"state": "SA",
		"locality": "BAIRD BAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5680",
		"state": "SA",
		"locality": "CARAWA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5690",
		"state": "SA",
		"locality": "BOOKABIE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5700",
		"state": "SA",
		"locality": "BLANCHE HARBOR",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5701",
		"state": "SA",
		"locality": "ARKAROOLA VILLAGE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5710",
		"state": "SA",
		"locality": "STIRLING NORTH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5713",
		"state": "SA",
		"locality": "EMEROO",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5715",
		"state": "SA",
		"locality": "CARRIEWERLOO",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5717",
		"state": "SA",
		"locality": "HILTABA",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5719",
		"state": "SA",
		"locality": "BON BON",
		"X065": "N/A",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5720",
		"state": "SA",
		"locality": "ARCOONA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5722",
		"state": "SA",
		"locality": "ANDAMOOKA",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5723",
		"state": "SA",
		"locality": "ALLANDALE STATION",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5724",
		"state": "SA",
		"locality": "MARLA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5725",
		"state": "SA",
		"locality": "OLYMPIC DAM",
		"X065": "On application",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5730",
		"state": "SA",
		"locality": "ALPANA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5731",
		"state": "SA",
		"locality": "BOLLARDS LAGOON",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X070": true,
		"X073": "Non-Metro"
		}, {
		"postcode": "5732",
		"state": "SA",
		"locality": "ANGEPENA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5733",
		"state": "SA",
		"locality": "ALTON DOWNS STATION",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5734",
		"state": "SA",
		"locality": "CROWN POINT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "5950",
		"state": "SA",
		"locality": "ADELAIDE AIRPORT",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "6000",
		"state": "WA",
		"locality": "CITY DELIVERY CENTRE",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X096": "W",
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6003",
		"state": "WA",
		"locality": "HIGHGATE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6004",
		"state": "WA",
		"locality": "EAST PERTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X096": "W",
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6005",
		"state": "WA",
		"locality": "KINGS PARK",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6006",
		"state": "WA",
		"locality": "NORTH PERTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6007",
		"state": "WA",
		"locality": "LEEDERVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6008",
		"state": "WA",
		"locality": "DAGLISH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6009",
		"state": "WA",
		"locality": "BROADWAY NEDLANDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6010",
		"state": "WA",
		"locality": "CLAREMONT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6011",
		"state": "WA",
		"locality": "COTTESLOE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6012",
		"state": "WA",
		"locality": "MOSMAN PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6014",
		"state": "WA",
		"locality": "FLOREAT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6015",
		"state": "WA",
		"locality": "CITY BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X071": true,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6016",
		"state": "WA",
		"locality": "GLENDALOUGH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6017",
		"state": "WA",
		"locality": "HERDSMAN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6018",
		"state": "WA",
		"locality": "CHURCHLANDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6019",
		"state": "WA",
		"locality": "SCARBOROUGH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6020",
		"state": "WA",
		"locality": "CARINE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6021",
		"state": "WA",
		"locality": "BALCATTA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6022",
		"state": "WA",
		"locality": "HAMERSLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6023",
		"state": "WA",
		"locality": "DUNCRAIG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6024",
		"state": "WA",
		"locality": "GREENWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6025",
		"state": "WA",
		"locality": "CRAIGIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6026",
		"state": "WA",
		"locality": "KINGSLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6027",
		"state": "WA",
		"locality": "BELDON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6028",
		"state": "WA",
		"locality": "BURNS BEACH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6029",
		"state": "WA",
		"locality": "TRIGG",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6030",
		"state": "WA",
		"locality": "CLARKSON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6031",
		"state": "WA",
		"locality": "BANKSIA GROVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6032",
		"state": "WA",
		"locality": "NOWERGUP",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6033",
		"state": "WA",
		"locality": "CARABOODA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6034",
		"state": "WA",
		"locality": "EGLINTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6035",
		"state": "WA",
		"locality": "YANCHEP",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6036",
		"state": "WA",
		"locality": "BUTLER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6037",
		"state": "WA",
		"locality": "TWO ROCKS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6038",
		"state": "WA",
		"locality": "ALKIMOS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6041",
		"state": "WA",
		"locality": "CARABAN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6042",
		"state": "WA",
		"locality": "SEABIRD",
		"X065": "On application",
		"X066": "Regional",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6043",
		"state": "WA",
		"locality": "BRETON BAY",
		"X065": "On application",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6044",
		"state": "WA",
		"locality": "KARAKIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6050",
		"state": "WA",
		"locality": "COOLBINIA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6051",
		"state": "WA",
		"locality": "MAYLANDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6052",
		"state": "WA",
		"locality": "BEDFORD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6053",
		"state": "WA",
		"locality": "BAYSWATER",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6054",
		"state": "WA",
		"locality": "ASHFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6055",
		"state": "WA",
		"locality": "BRABHAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6056",
		"state": "WA",
		"locality": "BASKERVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6057",
		"state": "WA",
		"locality": "HIGH WYCOMBE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6058",
		"state": "WA",
		"locality": "FORRESTFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6059",
		"state": "WA",
		"locality": "DIANELLA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6060",
		"state": "WA",
		"locality": "JOONDANNA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6061",
		"state": "WA",
		"locality": "BALGA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6062",
		"state": "WA",
		"locality": "EMBLETON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6063",
		"state": "WA",
		"locality": "BEECHBORO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6064",
		"state": "WA",
		"locality": "ALEXANDER HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6065",
		"state": "WA",
		"locality": "ASHBY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6066",
		"state": "WA",
		"locality": "BALLAJURA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6067",
		"state": "WA",
		"locality": "CULLACABARDEE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6068",
		"state": "WA",
		"locality": "WHITEMAN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6069",
		"state": "WA",
		"locality": "AVELEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6070",
		"state": "WA",
		"locality": "DARLINGTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6071",
		"state": "WA",
		"locality": "GLEN FORREST",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6072",
		"state": "WA",
		"locality": "MAHOGANY CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6073",
		"state": "WA",
		"locality": "MUNDARING",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6074",
		"state": "WA",
		"locality": "SAWYERS VALLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6076",
		"state": "WA",
		"locality": "BICKLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6077",
		"state": "WA",
		"locality": "GNANGARA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6078",
		"state": "WA",
		"locality": "MARIGINIUP",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6079",
		"state": "WA",
		"locality": "LEXIA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6081",
		"state": "WA",
		"locality": "PARKERVILLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6082",
		"state": "WA",
		"locality": "BAILUP",
		"X065": "Category 1",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6083",
		"state": "WA",
		"locality": "GIDGEGANNUP",
		"X065": "Category 1",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6084",
		"state": "WA",
		"locality": "AVON VALLEY NATIONAL PARK",
		"X065": "Category 1",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6090",
		"state": "WA",
		"locality": "MALAGA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6100",
		"state": "WA",
		"locality": "BURSWOOD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6101",
		"state": "WA",
		"locality": "CARLISLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6102",
		"state": "WA",
		"locality": "BENTLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6103",
		"state": "WA",
		"locality": "RIVERVALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6104",
		"state": "WA",
		"locality": "ASCOT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X096": "W",
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6105",
		"state": "WA",
		"locality": "CLOVERDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6106",
		"state": "WA",
		"locality": "WELSHPOOL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6107",
		"state": "WA",
		"locality": "BECKENHAM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6108",
		"state": "WA",
		"locality": "THORNLIE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6109",
		"state": "WA",
		"locality": "MADDINGTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6110",
		"state": "WA",
		"locality": "GOSNELLS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6111",
		"state": "WA",
		"locality": "ASHENDON",
		"X065": "Category 1",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6112",
		"state": "WA",
		"locality": "ARMADALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6121",
		"state": "WA",
		"locality": "OAKFORD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6122",
		"state": "WA",
		"locality": "BYFORD",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6123",
		"state": "WA",
		"locality": "MUNDIJONG",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6124",
		"state": "WA",
		"locality": "JARRAHDALE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6125",
		"state": "WA",
		"locality": "HOPELAND",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6126",
		"state": "WA",
		"locality": "KEYSBROOK",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6147",
		"state": "WA",
		"locality": "LANGFORD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6148",
		"state": "WA",
		"locality": "FERNDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6149",
		"state": "WA",
		"locality": "BULL CREEK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6150",
		"state": "WA",
		"locality": "BATEMAN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6151",
		"state": "WA",
		"locality": "KENSINGTON",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X096": "W",
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6152",
		"state": "WA",
		"locality": "COMO",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6153",
		"state": "WA",
		"locality": "APPLECROSS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6154",
		"state": "WA",
		"locality": "ALFRED COVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6155",
		"state": "WA",
		"locality": "CANNING VALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6156",
		"state": "WA",
		"locality": "ATTADALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6157",
		"state": "WA",
		"locality": "BICTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6158",
		"state": "WA",
		"locality": "EAST FREMANTLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6159",
		"state": "WA",
		"locality": "NORTH FREMANTLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6160",
		"state": "WA",
		"locality": "FREMANTLE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6161",
		"state": "WA",
		"locality": "ROTTNEST ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6162",
		"state": "WA",
		"locality": "BEACONSFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6163",
		"state": "WA",
		"locality": "BIBRA LAKE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6164",
		"state": "WA",
		"locality": "ATWELL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6165",
		"state": "WA",
		"locality": "HOPE VALLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6166",
		"state": "WA",
		"locality": "COOGEE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6167",
		"state": "WA",
		"locality": "ANKETELL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6168",
		"state": "WA",
		"locality": "COOLOONGUP",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6169",
		"state": "WA",
		"locality": "SAFETY BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6170",
		"state": "WA",
		"locality": "LEDA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6171",
		"state": "WA",
		"locality": "BALDIVIS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6172",
		"state": "WA",
		"locality": "PORT KENNEDY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6173",
		"state": "WA",
		"locality": "SECRET HARBOUR",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6174",
		"state": "WA",
		"locality": "GOLDEN BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6175",
		"state": "WA",
		"locality": "SINGLETON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6176",
		"state": "WA",
		"locality": "KARNUP",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6180",
		"state": "WA",
		"locality": "LAKELANDS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6181",
		"state": "WA",
		"locality": "STAKE HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6182",
		"state": "WA",
		"locality": "KERALUP",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6207",
		"state": "WA",
		"locality": "MYARA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6208",
		"state": "WA",
		"locality": "BLYTHEWOOD",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6209",
		"state": "WA",
		"locality": "BARRAGUP",
		"X065": "Category 2",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6210",
		"state": "WA",
		"locality": "COODANUP",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X074": "South",
		"X073": "Metropolitan"
		}, {
		"postcode": "6211",
		"state": "WA",
		"locality": "BOUVARD",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6213",
		"state": "WA",
		"locality": "BANKSIADALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6214",
		"state": "WA",
		"locality": "BIRCHMONT",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6215",
		"state": "WA",
		"locality": "HAMEL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6218",
		"state": "WA",
		"locality": "YARLOOP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6220",
		"state": "WA",
		"locality": "COOKERNUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6221",
		"state": "WA",
		"locality": "MORNINGTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6223",
		"state": "WA",
		"locality": "BENGER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6224",
		"state": "WA",
		"locality": "BEELA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6225",
		"state": "WA",
		"locality": "ALLANSON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6226",
		"state": "WA",
		"locality": "ROELANDS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6227",
		"state": "WA",
		"locality": "BUREKUP",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6228",
		"state": "WA",
		"locality": "WATERLOO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6229",
		"state": "WA",
		"locality": "PICTON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6230",
		"state": "WA",
		"locality": "BUNBURY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6232",
		"state": "WA",
		"locality": "EATON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6233",
		"state": "WA",
		"locality": "AUSTRALIND",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6236",
		"state": "WA",
		"locality": "CROOKED BROOK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6237",
		"state": "WA",
		"locality": "BOYANUP",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6239",
		"state": "WA",
		"locality": "ARGYLE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6240",
		"state": "WA",
		"locality": "LOWDEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6243",
		"state": "WA",
		"locality": "WILGA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6244",
		"state": "WA",
		"locality": "BOYUP BROOK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6251",
		"state": "WA",
		"locality": "BRAZIER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6252",
		"state": "WA",
		"locality": "MULLALYUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6253",
		"state": "WA",
		"locality": "BALINGUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6254",
		"state": "WA",
		"locality": "GREENBUSHES",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6255",
		"state": "WA",
		"locality": "BENJINUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6256",
		"state": "WA",
		"locality": "GLENLYNN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6258",
		"state": "WA",
		"locality": "BALBARRUP",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6260",
		"state": "WA",
		"locality": "BEEDELUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6262",
		"state": "WA",
		"locality": "BOORARA BROOK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6271",
		"state": "WA",
		"locality": "CAPEL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6275",
		"state": "WA",
		"locality": "BARRABUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6280",
		"state": "WA",
		"locality": "ABBA RIVER",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6281",
		"state": "WA",
		"locality": "DUNSBOROUGH",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6282",
		"state": "WA",
		"locality": "YALLINGUP",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6284",
		"state": "WA",
		"locality": "BAUDIN",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6285",
		"state": "WA",
		"locality": "BRAMLEY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6286",
		"state": "WA",
		"locality": "BORANUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6288",
		"state": "WA",
		"locality": "ALEXANDRA BRIDGE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6290",
		"state": "WA",
		"locality": "AUGUSTA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6302",
		"state": "WA",
		"locality": "BADGIN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6304",
		"state": "WA",
		"locality": "BALLY BALLY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6306",
		"state": "WA",
		"locality": "ALDERSYDE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6308",
		"state": "WA",
		"locality": "CODJATOTINE",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6309",
		"state": "WA",
		"locality": "EAST POPANYINNING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6311",
		"state": "WA",
		"locality": "COMMODINE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6312",
		"state": "WA",
		"locality": "BOUNDAIN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6313",
		"state": "WA",
		"locality": "HIGHBURY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6315",
		"state": "WA",
		"locality": "ARTHUR RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6316",
		"state": "WA",
		"locality": "BOYERINE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6317",
		"state": "WA",
		"locality": "BADGEBUP",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6318",
		"state": "WA",
		"locality": "BROOMEHILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6320",
		"state": "WA",
		"locality": "BOBALONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6321",
		"state": "WA",
		"locality": "CRANBROOK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6322",
		"state": "WA",
		"locality": "TENTERDEN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6323",
		"state": "WA",
		"locality": "KENDENUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6324",
		"state": "WA",
		"locality": "DENBARKER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6326",
		"state": "WA",
		"locality": "NARRIKUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6327",
		"state": "WA",
		"locality": "REDMOND",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6328",
		"state": "WA",
		"locality": "CHEYNES",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6330",
		"state": "WA",
		"locality": "ALBANY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6333",
		"state": "WA",
		"locality": "BOW BRIDGE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6335",
		"state": "WA",
		"locality": "GNOWANGERUP",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6336",
		"state": "WA",
		"locality": "COWALELLUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6337",
		"state": "WA",
		"locality": "FITZGERALD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6338",
		"state": "WA",
		"locality": "AMELUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6341",
		"state": "WA",
		"locality": "NYABING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6343",
		"state": "WA",
		"locality": "PINGRUP",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6346",
		"state": "WA",
		"locality": "FITZGERALD RIVER NATIONAL PARK",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6348",
		"state": "WA",
		"locality": "HOPETOUN",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6350",
		"state": "WA",
		"locality": "DUMBLEYUNG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6351",
		"state": "WA",
		"locality": "MOULYINNING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6352",
		"state": "WA",
		"locality": "KUKERIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6353",
		"state": "WA",
		"locality": "BEENONG",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6355",
		"state": "WA",
		"locality": "DUNN ROCK",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6356",
		"state": "WA",
		"locality": "HATTER HILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6357",
		"state": "WA",
		"locality": "PINGARING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6358",
		"state": "WA",
		"locality": "KARLGARIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6359",
		"state": "WA",
		"locality": "FORRESTANIA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6361",
		"state": "WA",
		"locality": "HARRISMITH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6363",
		"state": "WA",
		"locality": "DUDININ",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6365",
		"state": "WA",
		"locality": "JILAKIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6367",
		"state": "WA",
		"locality": "KONDININ",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6368",
		"state": "WA",
		"locality": "SOUTH KUMMININ",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6369",
		"state": "WA",
		"locality": "MOUNT WALKER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6370",
		"state": "WA",
		"locality": "EAST WICKEPIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6372",
		"state": "WA",
		"locality": "YEALERING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6373",
		"state": "WA",
		"locality": "BULLARING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6375",
		"state": "WA",
		"locality": "ADAMSVALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6383",
		"state": "WA",
		"locality": "BADJALING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6384",
		"state": "WA",
		"locality": "PANTAPIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6385",
		"state": "WA",
		"locality": "KWOLYIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6386",
		"state": "WA",
		"locality": "SHACKLETON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6390",
		"state": "WA",
		"locality": "BANNISTER",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6391",
		"state": "WA",
		"locality": "QUINDANNING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6392",
		"state": "WA",
		"locality": "BOKAL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6393",
		"state": "WA",
		"locality": "DURANILLIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6394",
		"state": "WA",
		"locality": "BEAUFORT RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6395",
		"state": "WA",
		"locality": "CHERRY TREE POOL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6396",
		"state": "WA",
		"locality": "FRANKLAND RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6397",
		"state": "WA",
		"locality": "ROCKY GULLY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6398",
		"state": "WA",
		"locality": "BROKE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6401",
		"state": "WA",
		"locality": "BUCKLAND",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6403",
		"state": "WA",
		"locality": "GRASS VALLEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6405",
		"state": "WA",
		"locality": "GREENWOODS VALLEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6407",
		"state": "WA",
		"locality": "CUNDERDIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6409",
		"state": "WA",
		"locality": "NORTH TAMMIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6410",
		"state": "WA",
		"locality": "DAADENNING CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6411",
		"state": "WA",
		"locality": "DOODLAKINE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6412",
		"state": "WA",
		"locality": "BAANDEE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6413",
		"state": "WA",
		"locality": "HINES HILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6414",
		"state": "WA",
		"locality": "NANGEENAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6415",
		"state": "WA",
		"locality": "GOOMARIN",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6418",
		"state": "WA",
		"locality": "BRUCE ROCK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6419",
		"state": "WA",
		"locality": "ARDATH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6420",
		"state": "WA",
		"locality": "CRAMPHORNE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6421",
		"state": "WA",
		"locality": "BURRACOPPIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6422",
		"state": "WA",
		"locality": "WALGOOLAN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6423",
		"state": "WA",
		"locality": "BOODAROCKIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6424",
		"state": "WA",
		"locality": "BODALLIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6425",
		"state": "WA",
		"locality": "DULYALBIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6426",
		"state": "WA",
		"locality": "CORINTHIA",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6427",
		"state": "WA",
		"locality": "KOOLYANOBBING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6428",
		"state": "WA",
		"locality": "BABAKIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6429",
		"state": "WA",
		"locality": "BOORABBIN",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6430",
		"state": "WA",
		"locality": "SOUTH KALGOORLIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6431",
		"state": "WA",
		"locality": "BOORARA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "MixWA",
		"X073": "Non-Metro"
		}, {
		"postcode": "6432",
		"state": "WA",
		"locality": "BOULDER",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6434",
		"state": "WA",
		"locality": "CUNDEELEE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6436",
		"state": "WA",
		"locality": "MENZIES",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6437",
		"state": "WA",
		"locality": "LEINSTER",
		"X065": "N/A",
		"X066": "On application",
		"X068": true,
		"X069": "Medium",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6438",
		"state": "WA",
		"locality": "LAKE DARLOT",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6440",
		"state": "WA",
		"locality": "BANDYA",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X069": "Medium",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6442",
		"state": "WA",
		"locality": "KAMBALDA EAST",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6443",
		"state": "WA",
		"locality": "BALLADONIA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6445",
		"state": "WA",
		"locality": "NORTH CASCADE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6446",
		"state": "WA",
		"locality": "GRASS PATCH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6447",
		"state": "WA",
		"locality": "LORT RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6448",
		"state": "WA",
		"locality": "GIBSON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6450",
		"state": "WA",
		"locality": "BANDY CREEK",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6452",
		"state": "WA",
		"locality": "BURAMINYA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6460",
		"state": "WA",
		"locality": "GOOMALLING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6461",
		"state": "WA",
		"locality": "DOWERIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6462",
		"state": "WA",
		"locality": "HINDMARSH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6463",
		"state": "WA",
		"locality": "BENJABERRING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6465",
		"state": "WA",
		"locality": "MANMANNING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6466",
		"state": "WA",
		"locality": "CADOUX",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6467",
		"state": "WA",
		"locality": "BURAKIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6468",
		"state": "WA",
		"locality": "GOODLANDS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6470",
		"state": "WA",
		"locality": "KULJA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6472",
		"state": "WA",
		"locality": "BEACON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6473",
		"state": "WA",
		"locality": "NORTH WIALKI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6475",
		"state": "WA",
		"locality": "BADGERIN ROCK",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6476",
		"state": "WA",
		"locality": "GABBIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6477",
		"state": "WA",
		"locality": "BENCUBBIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6479",
		"state": "WA",
		"locality": "BARBALIN",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6480",
		"state": "WA",
		"locality": "NUKARNI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6484",
		"state": "WA",
		"locality": "BULLFINCH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6485",
		"state": "WA",
		"locality": "COWCOWING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6487",
		"state": "WA",
		"locality": "NORTH YELBENI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6488",
		"state": "WA",
		"locality": "NORTH TRAYNING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6489",
		"state": "WA",
		"locality": "KUNUNOPPIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6490",
		"state": "WA",
		"locality": "BURRAN ROCK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6501",
		"state": "WA",
		"locality": "MUCHEA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6502",
		"state": "WA",
		"locality": "BINDOON",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6503",
		"state": "WA",
		"locality": "BAMBUN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6504",
		"state": "WA",
		"locality": "MOOLIABEENEE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6505",
		"state": "WA",
		"locality": "WANNAMAL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6506",
		"state": "WA",
		"locality": "MOGUMBER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6507",
		"state": "WA",
		"locality": "CATABY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6509",
		"state": "WA",
		"locality": "GLENTROMIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6510",
		"state": "WA",
		"locality": "BARBERTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6511",
		"state": "WA",
		"locality": "CERVANTES",
		"X065": "On application",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6512",
		"state": "WA",
		"locality": "COOMBERDALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6513",
		"state": "WA",
		"locality": "GUNYIDI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6514",
		"state": "WA",
		"locality": "GREEN HEAD",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6515",
		"state": "WA",
		"locality": "COOROW",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6516",
		"state": "WA",
		"locality": "JURIEN BAY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6517",
		"state": "WA",
		"locality": "CARNAMAH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6518",
		"state": "WA",
		"locality": "ENEABBA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6519",
		"state": "WA",
		"locality": "ARRINO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6521",
		"state": "WA",
		"locality": "BADGINGARRA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6522",
		"state": "WA",
		"locality": "BUNDANOON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6525",
		"state": "WA",
		"locality": "ALLANOOKA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6528",
		"state": "WA",
		"locality": "MOUNT HILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6530",
		"state": "WA",
		"locality": "BEACHLANDS",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6532",
		"state": "WA",
		"locality": "AJANA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "MixWA",
		"X073": "Non-Metro"
		}, {
		"postcode": "6535",
		"state": "WA",
		"locality": "ALMA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6536",
		"state": "WA",
		"locality": "KALBARRI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6537",
		"state": "WA",
		"locality": "DENHAM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "MixWA",
		"X073": "Non-Metro"
		}, {
		"postcode": "6556",
		"state": "WA",
		"locality": "BEECHINA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6558",
		"state": "WA",
		"locality": "WOOROLOO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6560",
		"state": "WA",
		"locality": "WUNDOWIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6562",
		"state": "WA",
		"locality": "BAKERS HILL",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6564",
		"state": "WA",
		"locality": "CLACKLINE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6566",
		"state": "WA",
		"locality": "BEJOORDING",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6567",
		"state": "WA",
		"locality": "DEWARS POOL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6568",
		"state": "WA",
		"locality": "BOLGART",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6569",
		"state": "WA",
		"locality": "CALINGIRI",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6571",
		"state": "WA",
		"locality": "YERECOIN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6572",
		"state": "WA",
		"locality": "PIAWANING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6574",
		"state": "WA",
		"locality": "BINDI BINDI",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6575",
		"state": "WA",
		"locality": "MILING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6603",
		"state": "WA",
		"locality": "KONNONGORRING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6605",
		"state": "WA",
		"locality": "KONDUT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6606",
		"state": "WA",
		"locality": "BALLIDU",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6608",
		"state": "WA",
		"locality": "EAST DAMBORING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6609",
		"state": "WA",
		"locality": "DALWALLINU",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6612",
		"state": "WA",
		"locality": "JIBBERDING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6613",
		"state": "WA",
		"locality": "BUNTINE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6614",
		"state": "WA",
		"locality": "MAYA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6616",
		"state": "WA",
		"locality": "LATHAM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6620",
		"state": "WA",
		"locality": "PERENJORI",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6623",
		"state": "WA",
		"locality": "BOWGADA",
		"X065": "N/A",
		"X066": "Country",
		"X068": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6625",
		"state": "WA",
		"locality": "MERKANOOKA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6627",
		"state": "WA",
		"locality": "CANNA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6628",
		"state": "WA",
		"locality": "TARDUN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6630",
		"state": "WA",
		"locality": "DEVILS CREEK",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6631",
		"state": "WA",
		"locality": "PINDAR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6632",
		"state": "WA",
		"locality": "AMBANIA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6635",
		"state": "WA",
		"locality": "SOUTH MURCHISON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "MixWA",
		"X073": "Non-Metro"
		}, {
		"postcode": "6638",
		"state": "WA",
		"locality": "COOLADAR HILL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6639",
		"state": "WA",
		"locality": "SANDSTONE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6640",
		"state": "WA",
		"locality": "CUE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "South",
		"X073": "Non-Metro"
		}, {
		"postcode": "6642",
		"state": "WA",
		"locality": "ANGELO RIVER",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "MixWA",
		"X073": "Non-Metro"
		}, {
		"postcode": "6646",
		"state": "WA",
		"locality": "LAKE CARNEGIE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "MixWA",
		"X073": "Non-Metro"
		}, {
		"postcode": "6701",
		"state": "WA",
		"locality": "BABBAGE ISLAND",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "MixWA",
		"X073": "Non-Metro"
		}, {
		"postcode": "6705",
		"state": "WA",
		"locality": "EAST LYONS RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6707",
		"state": "WA",
		"locality": "CAPE RANGE NATIONAL PARK",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6710",
		"state": "WA",
		"locality": "CANE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6711",
		"state": "WA",
		"locality": "THEVENARD ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6712",
		"state": "WA",
		"locality": "BARROW ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6713",
		"state": "WA",
		"locality": "DAMPIER",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6714",
		"state": "WA",
		"locality": "ANTONYMYRE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6716",
		"state": "WA",
		"locality": "FORTESCUE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6718",
		"state": "WA",
		"locality": "ROEBOURNE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6720",
		"state": "WA",
		"locality": "COSSACK",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6721",
		"state": "WA",
		"locality": "INDEE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6722",
		"state": "WA",
		"locality": "BOODARIE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6725",
		"state": "WA",
		"locality": "BILINGURR",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X069": "Medium",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6726",
		"state": "WA",
		"locality": "CABLE BEACH",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6728",
		"state": "WA",
		"locality": "CAMBALLIN",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6733",
		"state": "WA",
		"locality": "KOOLAN ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6740",
		"state": "WA",
		"locality": "DRYSDALE RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6743",
		"state": "WA",
		"locality": "CAMBRIDGE GULF",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6751",
		"state": "WA",
		"locality": "CHICHESTER",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6753",
		"state": "WA",
		"locality": "NEWMAN",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6754",
		"state": "WA",
		"locality": "PARABURDOO",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6758",
		"state": "WA",
		"locality": "NULLAGINE",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6760",
		"state": "WA",
		"locality": "MARBLE BAR",
		"X065": "N/A",
		"X066": "N/A",
		"X068": true,
		"X069": "High",
		"X070": true,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6762",
		"state": "WA",
		"locality": "TELFER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6765",
		"state": "WA",
		"locality": "FITZROY CROSSING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6770",
		"state": "WA",
		"locality": "HALLS CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6798",
		"state": "WA",
		"locality": "CHRISTMAS ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "6799",
		"state": "WA",
		"locality": "HOME ISLAND COCOS (KEELING) ISLANDS",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X074": "North",
		"X073": "Non-Metro"
		}, {
		"postcode": "7000",
		"state": "TAS",
		"locality": "GLEBE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7004",
		"state": "TAS",
		"locality": "BATTERY POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7005",
		"state": "TAS",
		"locality": "DYNNYRNE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7007",
		"state": "TAS",
		"locality": "MOUNT NELSON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7008",
		"state": "TAS",
		"locality": "LENAH VALLEY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7009",
		"state": "TAS",
		"locality": "DERWENT PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7010",
		"state": "TAS",
		"locality": "DOWSING POINT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7011",
		"state": "TAS",
		"locality": "AUSTINS FERRY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7012",
		"state": "TAS",
		"locality": "COLLINSVALE",
		"X065": "Category 2",
		"X066": "On application",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7015",
		"state": "TAS",
		"locality": "GEILSTON BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7016",
		"state": "TAS",
		"locality": "RISDON VALE",
		"X065": "Category 2",
		"X066": "Country",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7017",
		"state": "TAS",
		"locality": "GRASSTREE HILL",
		"X065": "Category 2",
		"X066": "On application",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7018",
		"state": "TAS",
		"locality": "BELLERIVE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7019",
		"state": "TAS",
		"locality": "CLARENDON VALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7020",
		"state": "TAS",
		"locality": "CLIFTON BEACH",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7021",
		"state": "TAS",
		"locality": "LAUDERDALE",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7022",
		"state": "TAS",
		"locality": "SOUTH ARM",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7023",
		"state": "TAS",
		"locality": "OPOSSUM BAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7024",
		"state": "TAS",
		"locality": "CREMORNE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7025",
		"state": "TAS",
		"locality": "DULCOT",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7026",
		"state": "TAS",
		"locality": "CAMPANIA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7027",
		"state": "TAS",
		"locality": "COLEBROOK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7030",
		"state": "TAS",
		"locality": "APSLEY",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7050",
		"state": "TAS",
		"locality": "KINGSTON",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7052",
		"state": "TAS",
		"locality": "BLACKMANS BAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7053",
		"state": "TAS",
		"locality": "BONNET HILL",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7054",
		"state": "TAS",
		"locality": "BARRETTA",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7055",
		"state": "TAS",
		"locality": "HUNTINGFIELD",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7109",
		"state": "TAS",
		"locality": "CRABTREE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7112",
		"state": "TAS",
		"locality": "ABELS BAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7113",
		"state": "TAS",
		"locality": "FRANKLIN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7116",
		"state": "TAS",
		"locality": "BROOKS BAY",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7117",
		"state": "TAS",
		"locality": "DOVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7119",
		"state": "TAS",
		"locality": "STONOR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7120",
		"state": "TAS",
		"locality": "ANDOVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7139",
		"state": "TAS",
		"locality": "STRATHGORDON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7140",
		"state": "TAS",
		"locality": "BLACK HILLS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7150",
		"state": "TAS",
		"locality": "ADVENTURE BAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7151",
		"state": "TAS",
		"locality": "CASEY",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7155",
		"state": "TAS",
		"locality": "KETTERING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7162",
		"state": "TAS",
		"locality": "BIRCHS BAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7163",
		"state": "TAS",
		"locality": "FLOWERPOT",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7170",
		"state": "TAS",
		"locality": "ACTON PARK",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7171",
		"state": "TAS",
		"locality": "MIDWAY POINT",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7172",
		"state": "TAS",
		"locality": "NUGENT",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7173",
		"state": "TAS",
		"locality": "CARLTON",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7174",
		"state": "TAS",
		"locality": "COPPING",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7175",
		"state": "TAS",
		"locality": "BREAM CREEK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7176",
		"state": "TAS",
		"locality": "KELLEVIE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7177",
		"state": "TAS",
		"locality": "BOOMER BAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7178",
		"state": "TAS",
		"locality": "MURDUNNA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7179",
		"state": "TAS",
		"locality": "EAGLEHAWK NECK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7180",
		"state": "TAS",
		"locality": "TARANNA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7182",
		"state": "TAS",
		"locality": "CAPE PILLAR",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7183",
		"state": "TAS",
		"locality": "HIGHCROFT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7184",
		"state": "TAS",
		"locality": "CAPE RAOUL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7185",
		"state": "TAS",
		"locality": "PREMAYDENA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7186",
		"state": "TAS",
		"locality": "SALTWATER RIVER",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7187",
		"state": "TAS",
		"locality": "KOONYA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7190",
		"state": "TAS",
		"locality": "TRIABUNNA",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7209",
		"state": "TAS",
		"locality": "ROSS",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7210",
		"state": "TAS",
		"locality": "CAMPBELL TOWN",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7211",
		"state": "TAS",
		"locality": "CLEVELAND",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7212",
		"state": "TAS",
		"locality": "EVANDALE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7213",
		"state": "TAS",
		"locality": "AVOCA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7214",
		"state": "TAS",
		"locality": "FINGAL",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7215",
		"state": "TAS",
		"locality": "BEAUMARIS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7216",
		"state": "TAS",
		"locality": "AKAROA",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7248",
		"state": "TAS",
		"locality": "INVERMAY",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7249",
		"state": "TAS",
		"locality": "KINGS MEADOWS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7250",
		"state": "TAS",
		"locality": "BLACKSTONE HEIGHTS",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7252",
		"state": "TAS",
		"locality": "BEECHFORD",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7253",
		"state": "TAS",
		"locality": "BELL BAY",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7254",
		"state": "TAS",
		"locality": "BELLINGHAM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7255",
		"state": "TAS",
		"locality": "BLUE ROCKS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7256",
		"state": "TAS",
		"locality": "King Island",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7257",
		"state": "TAS",
		"locality": "CAPE BARREN ISLAND",
		"X065": "N/A",
		"X066": "N/A",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7258",
		"state": "TAS",
		"locality": "BREADALBANE",
		"X065": "Category 2",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7259",
		"state": "TAS",
		"locality": "MYRTLE BANK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7260",
		"state": "TAS",
		"locality": "BLUMONT",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7261",
		"state": "TAS",
		"locality": "BRANXHOLM",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7262",
		"state": "TAS",
		"locality": "BRIDPORT",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7263",
		"state": "TAS",
		"locality": "ALBERTON",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7264",
		"state": "TAS",
		"locality": "ANSONS BAY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7265",
		"state": "TAS",
		"locality": "BANCA",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7267",
		"state": "TAS",
		"locality": "BANGOR",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7268",
		"state": "TAS",
		"locality": "LILYDALE",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7270",
		"state": "TAS",
		"locality": "BADGER HEAD",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X069": "Medium",
		"X073": "Non-Metro"
		}, {
		"postcode": "7275",
		"state": "TAS",
		"locality": "BLACKWALL",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7276",
		"state": "TAS",
		"locality": "GRAVELLY BEACH",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7277",
		"state": "TAS",
		"locality": "BRIDGENORTH",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7290",
		"state": "TAS",
		"locality": "HADSPEN",
		"X065": "Category 1",
		"X066": "Metropolitan",
		"X068": false,
		"X073": "Metropolitan"
		}, {
		"postcode": "7291",
		"state": "TAS",
		"locality": "CARRICK",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7292",
		"state": "TAS",
		"locality": "HAGLEY",
		"X065": "On application",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7300",
		"state": "TAS",
		"locality": "DEVON HILLS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7301",
		"state": "TAS",
		"locality": "BISHOPSBOURNE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7302",
		"state": "TAS",
		"locality": "BRACKNELL",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7303",
		"state": "TAS",
		"locality": "BIRRALEE",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7304",
		"state": "TAS",
		"locality": "BRANDUM",
		"X065": "Category 3",
		"X066": "On application",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7305",
		"state": "TAS",
		"locality": "MERSEYLEA",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7306",
		"state": "TAS",
		"locality": "ACACIA HILLS",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7307",
		"state": "TAS",
		"locality": "BAKERS BEACH",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7310",
		"state": "TAS",
		"locality": "ABERDEEN",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7315",
		"state": "TAS",
		"locality": "ABBOTSHAM",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7316",
		"state": "TAS",
		"locality": "PENGUIN",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7320",
		"state": "TAS",
		"locality": "ACTON",
		"X065": "Category 3",
		"X066": "Regional",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7321",
		"state": "TAS",
		"locality": "BLACK RIVER",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X069": "Medium",
		"X073": "Non-Metro"
		}, {
		"postcode": "7322",
		"state": "TAS",
		"locality": "SOMERSET",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7325",
		"state": "TAS",
		"locality": "CALDER",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7330",
		"state": "TAS",
		"locality": "SMITHTON",
		"X065": "Category 3",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7331",
		"state": "TAS",
		"locality": "STANLEY",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7466",
		"state": "TAS",
		"locality": "GORMANSTON",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7467",
		"state": "TAS",
		"locality": "LAKE MARGARET",
		"X065": "On application",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X073": "Non-Metro"
		}, {
		"postcode": "7468",
		"state": "TAS",
		"locality": "MACQUARIE HEADS",
		"X065": "On application",
		"X066": "Country",
		"X068": false,
		"X073": "Non-Metro"
		}, {
		"postcode": "7469",
		"state": "TAS",
		"locality": "GRANVILLE HARBOUR",
		"X065": "On application",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X073": "Non-Metro"
		}, {
		"postcode": "7470",
		"state": "TAS",
		"locality": "ROSEBERY",
		"X065": "On application",
		"X066": "N/A",
		"X068": false,
		"X069": "High",
		"X073": "Non-Metro"
		}],
	"X266": "0.07",
	"X267": "0.1",
	"rateCodeTable": [{
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "1",
		"initialRateCode": "PHL.FR.FR1I",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR1I",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 1 Year Fixed Rate Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ 1 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "2",
		"initialRateCode": "PHL.FR.FR2I",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR2I",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 2 Year Fixed Rate Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ 2 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "3",
		"initialRateCode": "PHL.FR.FR3I",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR3I",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 3 Year Fixed Rate Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ 3 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "4",
		"initialRateCode": "PHL.FR.FR4I",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR4I",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 4 Year Fixed Rate Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ 4 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "5",
		"initialRateCode": "PHL.FR.FR5I",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR5I",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 5 Year Fixed Rate Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ 5 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "6",
		"initialRateCode": "PHL.FR.FR7I",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR7I",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 6 Year Fixed Rate Home Loan",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 6 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "7",
		"initialRateCode": "PHL.FR.FR7I",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR7I",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 7 Year Fixed Rate Home Loan",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 7 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "8",
		"initialRateCode": "PHL.FR.FR10I",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR10I",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 8 Year Fixed Rate Home Loan",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 8 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "9",
		"initialRateCode": "PHL.FR.FR10I",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR10I",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 9 Year Fixed Rate Home Loan",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 9 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "10",
		"initialRateCode": "PHL.FR.FR10I",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR10I",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 10 Year Fixed Rate Home Loan",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 10 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "1",
		"initialRateCode": "PHL.FR.FR1IIO",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR1IIO",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 1 Year Fixed Rate Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ 1 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "2",
		"initialRateCode": "PHL.FR.FR2IIO",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR2IIO",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 2 Year Fixed Rate Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ 2 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "3",
		"initialRateCode": "PHL.FR.FR3IIO",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR3IIO",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 3 Year Fixed Rate Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ 3 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "4",
		"initialRateCode": "PHL.FR.FR4IIO",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR4IIO",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 4 Year Fixed Rate Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ 4 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "5",
		"initialRateCode": "PHL.FR.FR5IIO",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR5IIO",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 5 Year Fixed Rate Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ 5 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "6",
		"initialRateCode": "PHL.FR.FR7IIO",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR7IIO",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 6 Year Fixed Rate Home Loan",
		"systems": ["NONE"],
		"breakfree": true,
		"pdfProductName": "ANZ 6 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "7",
		"initialRateCode": "PHL.FR.FR7IIO",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR7IIO",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 7 Year Fixed Rate Home Loan",
		"systems": ["NONE"],
		"breakfree": true,
		"pdfProductName": "ANZ 7 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "8",
		"initialRateCode": "PHL.FR.FR10IIO",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR10IIO",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 8 Year Fixed Rate Home Loan",
		"systems": ["NONE"],
		"breakfree": true,
		"pdfProductName": "ANZ 8 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "9",
		"initialRateCode": "PHL.FR.FR10IIO",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR10IIO",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 9 Year Fixed Rate Home Loan",
		"systems": ["NONE"],
		"breakfree": true,
		"pdfProductName": "ANZ 9 Year Fixed Rate Home Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "10",
		"initialRateCode": "PHL.FR.FR10IIO",
		"subsequentRateCode": "PHL.VR.VRI",
		"fixedRateCode": "PHL.FR.FR10IIO",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ 10 Year Fixed Rate Home Loan",
		"systems": ["NONE"],
		"breakfree": true,
		"pdfProductName": "ANZ 10 Year Fixed Rate Home Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "1",
		"initialRateCode": "PRL.IFR.IFR1I",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR1I",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 1 Year Fixed Rate RIL",
		"breakfree": true,
		"pdfProductName": "ANZ 1 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "2",
		"initialRateCode": "PRL.IFR.IFR2I",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR2I",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 2 Year Fixed Rate RIL",
		"breakfree": true,
		"pdfProductName": "ANZ 2 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "3",
		"initialRateCode": "PRL.IFR.IFR3I",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR3I",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 3 Year Fixed Rate RIL",
		"breakfree": true,
		"pdfProductName": "ANZ 3 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "4",
		"initialRateCode": "PRL.IFR.IFR4I",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR4I",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 4 Year Fixed Rate RIL",
		"breakfree": true,
		"pdfProductName": "ANZ 4 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "5",
		"initialRateCode": "PRL.IFR.IFR5I",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR5I",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 5 Year Fixed Rate RIL",
		"breakfree": true,
		"pdfProductName": "ANZ 5 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "6",
		"initialRateCode": "PRL.IFR.IFR7I",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR7I",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 6 Year Fixed Rate RIL",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 6 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "7",
		"initialRateCode": "PRL.IFR.IFR7I",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR7I",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 7 Year Fixed Rate RIL",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 7 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "8",
		"initialRateCode": "PRL.IFR.IFR10I",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR10I",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 8 Year Fixed Rate RIL",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 8 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "9",
		"initialRateCode": "PRL.IFR.IFR10I",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR10I",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 9 Year Fixed Rate RIL",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 9 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["principalAndInterest"],
		"fixedIoTerm": "10",
		"initialRateCode": "PRL.IFR.IFR10I",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR10I",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 10 Year Fixed Rate RIL",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 10 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "1",
		"initialRateCode": "PRL.IFR.IFR1IIO",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR1IIO",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 1 Year Fixed Rate RIL",
		"breakfree": true,
		"pdfProductName": "ANZ 1 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "2",
		"initialRateCode": "PRL.IFR.IFR2IIO",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR2IIO",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 2 Year Fixed Rate RIL",
		"breakfree": true,
		"pdfProductName": "ANZ 2 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "3",
		"initialRateCode": "PRL.IFR.IFR3IIO",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR3IIO",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 3 Year Fixed Rate RIL",
		"breakfree": true,
		"pdfProductName": "ANZ 3 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "4",
		"initialRateCode": "PRL.IFR.IFR4IIO",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR4IIO",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 4 Year Fixed Rate RIL",
		"breakfree": true,
		"pdfProductName": "ANZ 4 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "5",
		"initialRateCode": "PRL.IFR.IFR5IIO",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR5IIO",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 5 Year Fixed Rate RIL",
		"breakfree": true,
		"pdfProductName": "ANZ 5 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "6",
		"initialRateCode": "PRL.IFR.IFR7IIO",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR7IIO",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 6 Year Fixed Rate RIL",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 6 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "7",
		"initialRateCode": "PRL.IFR.IFR7IIO",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR7IIO",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 7 Year Fixed Rate RIL",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 7 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "8",
		"initialRateCode": "PRL.IFR.IFR10IIO",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR10IIO",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 8 Year Fixed Rate RIL",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 8 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "9",
		"initialRateCode": "PRL.IFR.IFR10IIO",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR10IIO",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 9 Year Fixed Rate RIL",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 9 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": true,
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "10",
		"initialRateCode": "PRL.IFR.IFR10IIO",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.IFR.IFR10IIO",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 10 Year Fixed Rate RIL",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 10 Year Fixed Rate Residential Investment Loan"
		}, {
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestInAdvance"],
		"fixedIoTerm": "1",
		"initialRateCode": "PRL.ILA.IIA1INDEX",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.ILA.IIA1INDEX",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 1 Interest-in-Advance RIL",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 1 Year Fixed Rate Residential Investment Loan"
		}, {
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestInAdvance"],
		"fixedIoTerm": "2",
		"initialRateCode": "PRL.ILA.IIA2INDEX",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.ILA.IIA2INDEX",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 2 Interest-in-Advance RIL",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 2 Year Fixed Rate Residential Investment Loan"
		}, {
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestInAdvance"],
		"fixedIoTerm": "3",
		"initialRateCode": "PRL.ILA.IIA3INDEX",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.ILA.IIA3INDEX",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 3 Interest-in-Advance RIL",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 3 Year Fixed Rate Residential Investment Loan"
		}, {
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestInAdvance"],
		"fixedIoTerm": "4",
		"initialRateCode": "PRL.ILA.IIA4INDEX",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.ILA.IIA4INDEX",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 4 Interest-in-Advance RIL",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 4 Year Fixed Rate Residential Investment Loan"
		}, {
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestInAdvance"],
		"fixedIoTerm": "5",
		"initialRateCode": "PRL.ILA.IIA5INDEX",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.ILA.IIA5INDEX",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 5 Interest-in-Advance RIL",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ 5 Year Fixed Rate Residential Investment Loan"
		}, {
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestInAdvance"],
		"fixedIoTerm": "6",
		"initialRateCode": "PRL.ILA.IIA7INDEX",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.ILA.IIA7INDEX",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 6 Interest-in-Advance RIL",
		"system": "holmes",
		"systems": ["NONE"],
		"breakfree": true,
		"pdfProductName": "ANZ 6 Year Fixed Rate Residential Investment Loan"
		}, {
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestInAdvance"],
		"fixedIoTerm": "7",
		"initialRateCode": "PRL.ILA.IIA7INDEX",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.ILA.IIA7INDEX",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 7 Interest-in-Advance RIL",
		"system": "holmes",
		"systems": ["NONE"],
		"breakfree": true,
		"pdfProductName": "ANZ 7 Year Fixed Rate Residential Investment Loan"
		}, {
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestInAdvance"],
		"fixedIoTerm": "8",
		"initialRateCode": "PRL.ILA.IIA10INDEX",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.ILA.IIA10INDEX",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 8 Interest-in-Advance RIL",
		"system": "holmes",
		"systems": ["NONE"],
		"breakfree": true,
		"pdfProductName": "ANZ 8 Year Fixed Rate Residential Investment Loan"
		}, {
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestInAdvance"],
		"fixedIoTerm": "9",
		"initialRateCode": "PRL.ILA.IIA10INDEX",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.ILA.IIA10INDEX",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 9 Interest-in-Advance RIL",
		"system": "holmes",
		"systems": ["NONE"],
		"breakfree": true,
		"pdfProductName": "ANZ 9 Year Fixed Rate Residential Investment Loan"
		}, {
		"rateType": "fixed",
		"rateTypes": ["fixed"],
		"repaymentType": ["interestInAdvance"],
		"fixedIoTerm": "10",
		"initialRateCode": "PRL.ILA.IIA10INDEX",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"fixedRateCode": "PRL.ILA.IIA10INDEX",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ 10 Interest-in-Advance RIL",
		"system": "holmes",
		"systems": ["NONE"],
		"breakfree": true,
		"pdfProductName": "ANZ 10 Year Fixed Rate Residential Investment Loan"
		}, {
		"investment": false,
		"rateType": "fixed",
		"rateTypes": ["variable"],
		"repaymentType": ["principalAndInterest"],
		"initialRateCode": "PHL.VR.VRI",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ Standard Variable Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ Standard Variable Home Loan"
		}, {
		"investment": true,
		"rateType": "variable",
		"rateTypes": ["variable"],
		"repaymentType": ["principalAndInterest"],
		"initialRateCode": "PRL.IVR.IVRI",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ Standard Variable RIL",
		"breakfree": true,
		"pdfProductName": "ANZ Standard Variable Residential Investment Loan"
		}, {
		"investment": false,
		"rateType": "variable",
		"rateTypes": ["variable"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "5",
		"initialRateCode": "PHL.VR.VRIIO",
		"subsequentRateCode": "PHL.VR.VRI",
		"variableRateCode": "PHL.VR.VRI",
		"productName": "ANZ Standard Variable Home Loan",
		"breakfree": true,
		"pdfProductName": "ANZ Standard Variable Home Loan"
		}, {
		"investment": true,
		"rateType": "variable",
		"rateTypes": ["variable"],
		"repaymentType": ["interestOnly"],
		"fixedIoTerm": "5",
		"initialRateCode": "PRL.IVR.IVRIIO",
		"subsequentRateCode": "PRL.IVR.IVRI",
		"variableRateCode": "PRL.IVR.IVRI",
		"productName": "ANZ Standard Variable RIL",
		"breakfree": true,
		"pdfProductName": "ANZ Standard Variable Residential Investment Loan"
		}, {
		"investment": false,
		"rateType": "simplicityPlus",
		"rateTypes": ["simplicityPlus"],
		"repaymentType": ["principalAndInterest"],
		"initialRateCode": "PHL.SP.SPI",
		"variableRateCode": "PHL.SP.SPI",
		"productName": "ANZ Simplicity PLUS Home Loan",
		"breakfree": false,
		"pdfProductName": "ANZ Simplicity PLUS Home Loan"
		}, {
		"investment": true,
		"rateType": "simplicityPlus",
		"rateTypes": ["simplicityPlus"],
		"repaymentType": ["principalAndInterest"],
		"initialRateCode": "PRL.ISP.ISPI",
		"variableRateCode": "PRL.ISP.ISPI",
		"productName": "ANZ Simplicity PLUS RIL",
		"breakfree": false,
		"pdfProductName": "ANZ Simplicity PLUS Residential Investment Loan"
		}, {
		"investment": false,
		"rateType": "simplicityPlus",
		"rateTypes": ["simplicityPlus"],
		"repaymentType": ["interestOnly"],
		"initialRateCode": "PHL.SP.SPIIO",
		"subsequentRateCode": "PHL.SP.SPI",
		"variableRateCode": "PHL.SP.SPI",
		"productName": "ANZ Simplicity PLUS Home Loan",
		"systems": ["NONE"],
		"breakfree": false,
		"pdfProductName": "ANZ Simplicity PLUS Home Loan"
		}, {
		"investment": true,
		"rateType": "simplicityPlus",
		"rateTypes": ["simplicityPlus"],
		"repaymentType": ["interestOnly"],
		"initialRateCode": "PRL.ISP.ISPIIO",
		"subsequentRateCode": "PRL.ISP.ISPI",
		"variableRateCode": "PRL.ISP.ISPI",
		"productName": "ANZ Simplicity PLUS RIL",
		"breakfree": false,
		"pdfProductName": "ANZ Simplicity PLUS Residential Investment Loan"
		}, {
		"rateType": "equityManager",
		"rateTypes": ["equityManager"],
		"initialRateCode": "PEL.EM.EMI",
		"variableRateCode": "PEL.EM.EMI",
		"productName": "ANZ Equity Manager ",
		"system": "holmes",
		"systems": ["holmes"],
		"breakfree": true,
		"pdfProductName": "ANZ Equity Manager "
		}],
	"X294": [{
		"X295": "Variable",
		"X296": "Outstanding",
		"X297": "970",
		"X298": "1200",
		"X299": "PLVRI5",
		"X300": "PLVRC5"
		}, {
		"X295": "Variable",
		"X296": "Great",
		"X297": "880",
		"X298": "969",
		"X299": "PLVRI4",
		"X300": "PLVRC4"
		}, {
		"X295": "Variable",
		"X296": "Good",
		"X297": "705",
		"X298": "879",
		"X299": "PLVRI3",
		"X300": "PLVRC3"
		}, {
		"X295": "Variable",
		"X296": "Average",
		"X297": "495",
		"X298": "704",
		"X299": "PLVRI2",
		"X300": "PLVRC2"
		}, {
		"X295": "Variable",
		"X296": "Fair",
		"X297": "401",
		"X298": "494",
		"X299": "PLVRI1",
		"X300": "PLVRC1"
		}, {
		"X295": "Variable",
		"X296": "Poor",
		"X297": "0",
		"X298": "400",
		"X299": "PLVRI1",
		"X300": "PLVRC1"
		}, {
		"X295": "Fixed",
		"X296": "Outstanding",
		"X297": "970",
		"X298": "1200",
		"X299": "PLFRI5",
		"X300": "PLFRC5"
		}, {
		"X295": "Fixed",
		"X296": "Great",
		"X297": "880",
		"X298": "969",
		"X299": "PLFRI4",
		"X300": "PLFRC4"
		}, {
		"X295": "Fixed",
		"X296": "Good",
		"X297": "705",
		"X298": "879",
		"X299": "PLFRI3",
		"X300": "PLFRC3"
		}, {
		"X295": "Fixed",
		"X296": "Average",
		"X297": "495",
		"X298": "704",
		"X299": "PLFRI2",
		"X300": "PLFRC2"
		}, {
		"X295": "Fixed",
		"X296": "Fair",
		"X297": "401",
		"X298": "494",
		"X299": "PLFRI1",
		"X300": "PLFRC1"
		}, {
		"X295": "Fixed",
		"X296": "Poor",
		"X297": "0",
		"X298": "400",
		"X299": "PLFRI1",
		"X300": "PLFRC1"
		}],
	"X268": "Change",
	"X269": "HOO80PIR ",
	"X270": "0",
	"X271": "0.1",
	"X272": "15",
	"X273": "Increasing",
	"X274": "+",
	"X275": "0.25",
	"X276": "400000",
	"X277": "1000",
	"X278": "9900000",
	"X279": "25",
	"effectiveDateFHOG": "2024-07-08T00:00:00Z",
	"firstHomeOwnersGrantLumpSum": {
		"act": [{
			"cutoffThreshold": "750000",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct"],
			"uncertain": false,
			"value": "0"
			}],
		"nsw": [{
			"cutoffThreshold": "600000",
			"eligibleTypes": ["new"],
			"uncertain": false,
			"value": "10000"
			}, {
			"cutoffThreshold": "750000",
			"eligibleTypes": ["offThePlan" , "landConstruct"],
			"uncertain": false,
			"value": "10000"
			}],
		"nt": [{
			"cutoffThreshold": "99999999",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct"],
			"uncertain": false,
			"value": "10000"
			}],
		"qld": [{
			"cutoffThreshold": "750000",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct"],
			"uncertain": false,
			"value": "30000"
			}],
		"sa": [{
			"cutoffThreshold": "99999999",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct"],
			"uncertain": false,
			"value": "15000"
			}],
		"tas": [{
			"cutoffThreshold": "99999999",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct"],
			"uncertain": false,
			"value": "10000"
			}],
		"vic": [{
			"cutoffThreshold": "750000",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct"],
			"uncertain": false,
			"value": "10000"
			}],
		"wa": [{
			"cutoffThreshold": "750000",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct"],
			"uncertain": true,
			"value": "10000"
			}]
	},
	"firstHomeOwnersGrantLumpSumDetails": {
		"act": [{
			"cutoffThreshold": "750000",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct", "constructOnly"],
			"investment": false,
			"uncertain": false,
			"value": "0"
			}],
		"nsw": [{
			"cutoffThreshold": "600000",
			"eligibleTypes": ["new"],
			"investment": false,
			"uncertain": false,
			"value": "10000"
			}, {
			"cutoffThreshold": "750000",
			"eligibleTypes": ["offThePlan" , "landConstruct", "constructOnly"],
			"investment": false,
			"uncertain": false,
			"value": "10000"
			}],
		"nt": [{
			"cutoffThreshold": "99999999",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct", "constructOnly"],
			"investment": false,
			"uncertain": false,
			"value": "10000"
			}],
		"qld": [{
			"cutoffThreshold": "750000",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct", "constructOnly"],
			"investment": false,
			"uncertain": false,
			"value": "30000"
			}],
		"sa": [{
			"cutoffThreshold": "99999999",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct", "constructOnly"],
			"investment": false,
			"uncertain": false,
			"value": "15000"
			}],
		"tas": [{
			"cutoffThreshold": "99999999",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct", "constructOnly"],
			"investment": false,
			"uncertain": false,
			"value": "10000"
			}],
		"vic": [{
			"cutoffThreshold": "750000",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct", "constructOnly"],
			"investment": false,
			"uncertain": false,
			"X074": ["Metro", "MixVIC","Regional"],
			"value": "10000"
			}],
		"wa": [{
			"cutoffThreshold": "750000",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct", "constructOnly"],
			"investment": false,
			"uncertain": true,
			"X074": ["South", "MixWA"],
			"value": "10000"
			}, {
			"cutoffThreshold": "1000000",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct", "constructOnly"],
			"investment": false,
			"uncertain": true,
			"X074": ["North"],
			"value": "10000"
			}, {
			"cutoffThreshold": "750000",
			"eligibleTypes": ["new", "offThePlan" , "landConstruct", "constructOnly"],
			"investment": false,
			"uncertain": true,
			"value": "10000"
			}]
	},
	"firstHomeOwnersGrantStampDutyReduction": {
		"act": true,
		"nsw": true,
		"nt": true,
		"qld": true,
		"sa": true,
		"tas": false,
		"vic": true,
		"wa": true
	},
	"X225": "0.8",
	"X226": {
		"act": [{
			"X227": "0.025",
			"X228": "2000",
			"X229": "4000",
			"X230": "2000",
			"X231": "10000",
			"X232": "338",
			"X233": "1000"
			}],
		"nsw": [{
			"X227": "0.025",
			"X228": "2000",
			"X229": "4000",
			"X230": "2000",
			"X231": "10000",
			"X232": "335.7",
			"X233": "1000"
			}],
		"nt": [{
			"X227": "0.025",
			"X228": "2000",
			"X229": "4000",
			"X230": "2000",
			"X231": "10000",
			"X232": "336",
			"X233": "1000"
			}],
		"qld": [{
			"X227": "0.025",
			"X228": "2000",
			"X229": "4000",
			"X230": "2000",
			"X231": "10000",
			"X232": "398.14",
			"X233": "1000"
			}],
		"sa": [{
			"X227": "0.025",
			"X228": "2000",
			"X229": "4000",
			"X230": "2000",
			"X231": "10000",
			"X232": "358",
			"X233": "1000"
			}],
		"tas": [{
			"X227": "0.025",
			"X228": "2000",
			"X229": "4000",
			"X230": "2000",
			"X231": "10000",
			"X232": "362.46",
			"X233": "1000"
			}],
		"vic": [{
			"X227": "0.025",
			"X228": "2000",
			"X229": "4000",
			"X230": "2000",
			"X231": "10000",
			"X232": "295.8",
			"X233": "1000"
			}],
		"wa": [{
			"X227": "0.025",
			"X228": "2000",
			"X229": "4000",
			"X230": "2000",
			"X231": "10000",
			"X232": "376.6",
			"X233": "1000"
			}]
	},
	"X234": {
		"act": [{
			"X235": "25001",
			"X236": "20001",
			"X237": "10001",
			"X238": "15001",
			"X239": "17001",
			"X240": "13001"
			}],
		"nsw": [{
			"X235": "25002",
			"X236": "20002",
			"X237": "10002",
			"X238": "15002",
			"X239": "17002",
			"X240": "13002"
			}],
		"nt": [{
			"X235": "25003",
			"X236": "20003",
			"X237": "10003",
			"X238": "15003",
			"X239": "17003",
			"X240": "13003"
			}],
		"qld": [{
			"X235": "25004",
			"X236": "20004",
			"X237": "10004",
			"X238": "15004",
			"X239": "17004",
			"X240": "13004"
			}],
		"sa": [{
			"X235": "25005",
			"X236": "20005",
			"X237": "10005",
			"X238": "15005",
			"X239": "17005",
			"X240": "13005"
			}],
		"tas": [{
			"X235": "25006",
			"X236": "20006",
			"X237": "10006",
			"X238": "15006",
			"X239": "17006",
			"X240": "13006"
			}],
		"vic": [{
			"X235": "25007",
			"X236": "20007",
			"X237": "10007",
			"X238": "15007",
			"X239": "17007",
			"X240": "13007"
			}],
		"wa": [{
			"X235": "25008",
			"X236": "20008",
			"X237": "10008",
			"X238": "15008",
			"X239": "17008",
			"X240": "13008"
			}]
	},
	"X241": [{
		"X258": false,
		"X243": "60",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Simplicity PLUS special offer discount 60% or less LVR*",
		"X247": "SPSIP60",
		"X248": "SPSCP60",
		"X253": "PHL",
		"X254": "SP"
		}, {
		"X258": false,
		"X243": "60",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Simplicity PLUS",
		"X247": "SPI",
		"X248": "SPC",
		"X253": "PHL",
		"X254": "SP"
		}, {
		"X258": false,
		"X243": "60",
		"X259": ["variable"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Standard Variable Rate 80% or less LVR",
		"X247": "HOO80PIR",
		"X248": "HOO80PIC",
		"X253": "PHL",
		"X254": "PHLHD"
		}, {
		"X258": false,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "1",
		"X246": "1 year Fixed 80% or less LVR",
		"X247": "HOFI180",
		"X248": "HOFI180C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "2",
		"X246": "2 years Fixed 80% or less LVR",
		"X247": "HOFI280",
		"X248": "HOFI280C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "3",
		"X246": "3 years Fixed 80% or less LVR",
		"X247": "HOFI380",
		"X248": "HOFI380C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed 80% or less LVR",
		"X247": "HOFI480",
		"X248": "HOFI480C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed 80% or less LVR",
		"X247": "HOFI580",
		"X248": "HOFI580C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "60",
		"X243": "70",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Simplicity PLUS special offer discount 70% or less LVR*",
		"X247": "SPSIP70",
		"X248": "SPSCP70",
		"X253": "PHL",
		"X254": "SP"
		}, {
		"X258": false,
		"X242": "60",
		"X243": "70",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Simplicity PLUS",
		"X247": "SPI",
		"X248": "SPC",
		"X253": "PHL",
		"X254": "SP"
		}, {
		"X258": false,
		"X242": "60",
		"X243": "70",
		"X259": ["variable"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Standard Variable Rate 80% or less LVR",
		"X247": "HOO80PIR",
		"X248": "HOO80PIC",
		"X253": "PHL",
		"X254": "PHLHD"
		}, {
		"X258": false,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "1",
		"X246": "1 year Fixed 80% or less LVR",
		"X247": "HOFI180",
		"X248": "HOFI180C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "2",
		"X246": "2 years Fixed 80% or less LVR",
		"X247": "HOFI280",
		"X248": "HOFI280C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "3",
		"X246": "3 years Fixed 80% or less LVR",
		"X247": "HOFI380",
		"X248": "HOFI380C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed 80% or less LVR",
		"X247": "HOFI480",
		"X248": "HOFI480C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed 80% or less LVR",
		"X247": "HOFI580",
		"X248": "HOFI580C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Simplicity PLUS special offer discount 80% or less LVR*",
		"X247": "SPSI69",
		"X248": "SPSC80",
		"X253": "PHL",
		"X254": "SP"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Simplicity PLUS",
		"X247": "SPI",
		"X248": "SPC",
		"X253": "PHL",
		"X254": "SP"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["variable"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Standard Variable Rate 80% or less LVR",
		"X247": "HOO80PIR",
		"X248": "HOO80PIC",
		"X253": "PHL",
		"X254": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "1",
		"X246": "1 year Fixed 80% or less LVR",
		"X247": "HOFI180",
		"X248": "HOFI180C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "2",
		"X246": "2 years Fixed 80% or less LVR",
		"X247": "HOFI280",
		"X248": "HOFI280C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "3",
		"X246": "3 years Fixed 80% or less LVR",
		"X247": "HOFI380",
		"X248": "HOFI380C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed 80% or less LVR",
		"X247": "HOFI480",
		"X248": "HOFI480C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed 80% or less LVR",
		"X247": "HOFI480",
		"X248": "HOFI580C",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X243": "90",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Simplicity PLUS special offer discount*",
		"X247": "SPSI",
		"X248": "SPSC",
		"X253": "PHL",
		"X254": "SP"
		}, {
		"X258": false,
		"X242": "80",
		"X243": "90",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Simplicity PLUS",
		"X247": "SPI",
		"X248": "SPC",
		"X253": "PHL",
		"X254": "SP"
		}, {
		"X258": false,
		"X242": "80",
		"X243": "90",
		"X259": ["variable"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Standard Variable Rate",
		"X247": "HOO81PIR",
		"X248": "HOO81PIC",
		"X253": "PHL",
		"X254": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "1",
		"X246": "1 year Fixed",
		"X247": "HOOFR1I",
		"X248": "HOOFR1IC",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "2",
		"X246": "2 years Fixed",
		"X247": "HOOFR2I",
		"X248": "HOOFR2IC",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "3",
		"X246": "3 years Fixed",
		"X247": "HOOFR3I",
		"X248": "HOOFR3IC",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed",
		"X247": "HOOFR4I",
		"X248": "HOOFR4IC",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed",
		"X247": "HOOFR5I",
		"X248": "HOOFR5IC",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "90",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Simplicity PLUS special offer discount*",
		"X247": "SPSIP100",
		"X248": "SPSCP100",
		"X253": "PHL",
		"X254": "SP"
		}, {
		"X258": false,
		"X242": "90",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Simplicity PLUS",
		"X247": "SPI",
		"X248": "SPC",
		"X253": "PHL",
		"X254": "SP"
		}, {
		"X258": false,
		"X242": "90",
		"X259": ["variable"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X246": "Standard Variable Rate",
		"X247": "HOO81PIR",
		"X248": "HOO81PIC",
		"X253": "PHL",
		"X254": "PHLHD"
		}, {
		"X258": false,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "1",
		"X246": "1 year Fixed",
		"X247": "HOOFR1I",
		"X248": "HOOFR1IC",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "2",
		"X246": "2 years Fixed",
		"X247": "HOOFR2I",
		"X248": "HOOFR2IC",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": true,
		"X265": "3",
		"X246": "3 years Fixed",
		"X247": "HOOFR3I",
		"X248": "HOOFR3IC",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed",
		"X247": "HOOFR4I",
		"X248": "HOOFR4IC",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed",
		"X247": "HOOFR5I",
		"X248": "HOOFR5IC",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X243": "70",
		"X259": ["variable"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Standard Variable Rate 80% or less LVR",
		"X247": "HOO80IOR",
		"X248": "HOO80IOC",
		"X253": "PHL",
		"X254": "PHLHD",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed 80% or less LVR",
		"X247": "HOFIO801",
		"X248": "HOOFR1IOC",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed 80% or less LVR",
		"X247": "HOFIO802",
		"X248": "HOOFR2IOC",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed 80% or less LVR",
		"X247": "HOFIO803",
		"X248": "HOOFR3IOC",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed 80% or less LVR",
		"X247": "HOFIO804",
		"X248": "HOOFR4IOC",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed 80% or less LVR",
		"X247": "HOFIO805",
		"X248": "HOOFR5IOC",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["variable"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Standard Variable Rate 80% or less LVR",
		"X247": "HOO80IOR",
		"X248": "HOO80IOC",
		"X253": "PHL",
		"X254": "PHLHD",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed 80% or less LVR",
		"X247": "HOFIO801",
		"X248": "HOOFR1IOC",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed 80% or less LVR",
		"X247": "HOFIO802",
		"X248": "HOOFR2IOC",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed 80% or less LVR",
		"X247": "HOFIO803",
		"X248": "HOOFR3IOC",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed 80% or less LVR",
		"X247": "HOFIO804",
		"X248": "HOOFR4IOC",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed 80% or less LVR",
		"X247": "HOFIO805",
		"X248": "HOOFR5IOC",
		"X253": "PHL",
		"X254": "HOOHLSIR",
		"X262": "HOO80PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X259": ["variable"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Standard Variable Rate",
		"X247": "HOO81IOR",
		"X248": "HOO81IOC",
		"X253": "PHL",
		"X254": "PHLHD",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed",
		"X247": "HOOFR1IO",
		"X248": "HOFIO801C",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed",
		"X247": "HOOFR2IO",
		"X248": "HOFIO802C",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed",
		"X247": "HOOFR3IO",
		"X248": "HOFIO803C",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed",
		"X247": "HOOFR4IO",
		"X248": "HOFIO804C",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": false,
		"X242": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed",
		"X247": "HOOFR5IO",
		"X248": "HOFIO805C",
		"X253": "PHL",
		"X254": "HOOFR",
		"X262": "HOO81PIR",
		"X263": "PHL",
		"X264": "PHLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Simplicity PLUS special offer discount 60% or less LVR*",
		"X247": "SOVR60",
		"X248": "SOVRC60",
		"X253": "PRL",
		"X254": "ISP"
		}, {
		"X258": true,
		"X243": "60",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Simplicity PLUS",
		"X247": "ISPI",
		"X248": "ISPC",
		"X253": "PRL",
		"X254": "ISP"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["variable"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Standard Variable Rate 80% or less LVR",
		"X247": "HINV80PIR",
		"X248": "HINV80PIC",
		"X253": "PRL",
		"X254": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed 80% or less LVR",
		"X247": "HIFI180",
		"X248": "HIFI180C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed 80% or less LVR",
		"X247": "HIFI280",
		"X248": "HIFI280C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed 80% or less LVR",
		"X247": "HIFI380",
		"X248": "HIFI380C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed 80% or less LVR",
		"X247": "HIFI480",
		"X248": "HIFI480C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed 80% or less LVR",
		"X247": "HIFI580",
		"X248": "HIFI580C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "7",
		"X246": "7 years Fixed 80% or less LVR",
		"X247": "HIFI780",
		"X248": "HIFI780C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "10",
		"X246": "10 years Fixed 80% or less LVR",
		"X247": "HIFI1080",
		"X248": "HIFI1080C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Simplicity PLUS special offer discount 70% or less LVR*",
		"X247": "SOVR70",
		"X248": "SOVRC70",
		"X253": "PRL",
		"X254": "ISP"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Simplicity PLUS",
		"X247": "ISPI",
		"X248": "ISPC",
		"X253": "PRL",
		"X254": "ISP"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["variable"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Standard Variable Rate 80% or less LVR",
		"X247": "HINV80PIR",
		"X248": "HINV80PIC",
		"X253": "PRL",
		"X254": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed 80% or less LVR",
		"X247": "HIFI180",
		"X248": "HIFI180C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed 80% or less LVR",
		"X247": "HIFI280",
		"X248": "HIFI280C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed 80% or less LVR",
		"X247": "HIFI380",
		"X248": "HIFI380C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed 80% or less LVR",
		"X247": "HIFI480",
		"X248": "HIFI480C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed 80% or less LVR",
		"X247": "HIFI580",
		"X248": "HIFI580C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "7",
		"X246": "7 years Fixed 80% or less LVR",
		"X247": "HIFI780",
		"X248": "HIFI780C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "10",
		"X246": "10 years Fixed 80% or less LVR",
		"X247": "HIFI1080",
		"X248": "HIFI1080C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Simplicity PLUS special offer discount 80% or less LVR*",
		"X247": "SOVR80",
		"X248": "SOVRC80",
		"X253": "PRL",
		"X254": "ISP"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Simplicity PLUS",
		"X247": "ISPI",
		"X248": "ISPC",
		"X253": "PRL",
		"X254": "ISP"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["variable"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Standard Variable Rate 80% or less LVR",
		"X247": "HINV80PIR",
		"X248": "HINV80PIC",
		"X253": "PRL",
		"X254": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed 80% or less LVR",
		"X247": "HIFI180",
		"X248": "HIFI180C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed 80% or less LVR",
		"X247": "HIFI280",
		"X248": "HIFI280C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed 80% or less LVR",
		"X247": "HIFI380",
		"X248": "HIFI380C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed 80% or less LVR",
		"X247": "HIFI480",
		"X248": "HIFI480C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed 80% or less LVR",
		"X247": "HIFI580",
		"X248": "HIFI580C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "7",
		"X246": "7 years Fixed 80% or less LVR",
		"X247": "HIFI780",
		"X248": "HIFI780C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "10",
		"X246": "10 years Fixed 80% or less LVR",
		"X247": "HIFI1080",
		"X248": "HIFI1080C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Simplicity PLUS special offer discount*",
		"X247": "SOVR",
		"X248": "SOVRC",
		"X253": "PRL",
		"X254": "ISP"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Simplicity PLUS",
		"X247": "ISPI",
		"X248": "ISPC",
		"X253": "PRL",
		"X254": "ISP"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["variable"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Standard Variable Rate",
		"X247": "HINV81PIR",
		"X248": "HINV81PIC",
		"X253": "PRL",
		"X254": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed",
		"X247": "HIF1I",
		"X248": "HIF1IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed",
		"X247": "HIF2I",
		"X248": "HIF2IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed",
		"X247": "HIF3I",
		"X248": "HIF3IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed",
		"X247": "HIF4I",
		"X248": "HIF4IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed",
		"X247": "HIF5I",
		"X248": "HIF5IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "7",
		"X246": "7 years Fixed",
		"X247": "HIF7I",
		"X248": "HIF7IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "10",
		"X246": "10 years Fixed",
		"X247": "HIF10I",
		"X248": "HIF10IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Simplicity PLUS special offer discount*",
		"X247": "SOVR100",
		"X248": "SOVRC100",
		"X253": "PRL",
		"X254": "ISP"
		}, {
		"X258": true,
		"X242": "90",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Simplicity PLUS",
		"X247": "ISPI",
		"X248": "ISPC",
		"X253": "PRL",
		"X254": "ISP"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["variable"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X246": "Standard Variable Rate",
		"X247": "HINV81PIR",
		"X248": "HINV81PIC",
		"X253": "PRL",
		"X254": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed",
		"X247": "HIF1I",
		"X248": "HIF1IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed",
		"X247": "HIF2I",
		"X248": "HIF2IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed",
		"X247": "HIF3I",
		"X248": "HIF3IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed",
		"X247": "HIF4I",
		"X248": "HIF4IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed",
		"X247": "HIF5I",
		"X248": "HIF5IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "7",
		"X246": "7 years Fixed",
		"X247": "HIF7I",
		"X248": "HIF7IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["principalAndInterest"],
		"X261": false,
		"X265": "10",
		"X246": "10 years Fixed",
		"X247": "HIF10I",
		"X248": "HIF10IC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Simplicity PLUS special offer discount 60% or less LVR*",
		"X247": "SOVRIO60",
		"X248": "SOVRCIO60",
		"X253": "PRL",
		"X254": "ISP",
		"X262": "SOVR70",
		"X263": "PRL",
		"X264": "ISP"
		}, {
		"X258": true,
		"X243": "60",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Simplicity PLUS",
		"X247": "ISPIIO",
		"X248": "ISPCIO",
		"X253": "PRL",
		"X254": "ISP",
		"X262": "ISPI",
		"X263": "PRL",
		"X264": "ISP"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["variable"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Standard Variable Rate 80% or less LVR",
		"X247": "HINV80IOR",
		"X248": "HINV80IOC",
		"X253": "PRL",
		"X254": "PRLHD",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed 80% or less LVR",
		"X247": "HIFIO180",
		"X248": "HIFIO180C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed 80% or less LVR",
		"X247": "HIFIO280",
		"X248": "HIFIO280C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed 80% or less LVR",
		"X247": "HIFIO380",
		"X248": "HIFIO380C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed 80% or less LVR",
		"X247": "HIFIO480",
		"X248": "HIFIO480C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed 80% or less LVR",
		"X247": "HIFIO580",
		"X248": "HIFIO580C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "7",
		"X246": "7 years Fixed 80% or less LVR",
		"X247": "HIFIO780",
		"X248": "HIFIO780C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X243": "60",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "10",
		"X246": "10 years Fixed 80% or less LVR",
		"X247": "HIFIO1080",
		"X248": "HIFIO1080C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Simplicity PLUS special offer discount 70% or less LVR*",
		"X247": "SOVRIO70",
		"X248": "SOVRCIO70",
		"X253": "PRL",
		"X254": "ISP",
		"X262": "SOVR70",
		"X263": "PRL",
		"X264": "ISP"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Simplicity PLUS",
		"X247": "ISPIIO",
		"X248": "ISPCIO",
		"X253": "PRL",
		"X254": "ISP",
		"X262": "ISPI",
		"X263": "PRL",
		"X264": "ISP"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["variable"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Standard Variable Rate 80% or less LVR",
		"X247": "HINV80IOR",
		"X248": "HINV80IOC",
		"X253": "PRL",
		"X254": "PRLHD",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed 80% or less LVR",
		"X247": "HIFIO180",
		"X248": "HIFIO180C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed 80% or less LVR",
		"X247": "HIFIO280",
		"X248": "HIFIO280C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed 80% or less LVR",
		"X247": "HIFIO380",
		"X248": "HIFIO380C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed 80% or less LVR",
		"X247": "HIFIO480",
		"X248": "HIFIO480C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed 80% or less LVR",
		"X247": "HIFIO580",
		"X248": "HIFIO580C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "7",
		"X246": "7 years Fixed 80% or less LVR",
		"X247": "HIFIO780",
		"X248": "HIFIO780C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "60",
		"X243": "70",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "10",
		"X246": "10 years Fixed 80% or less LVR",
		"X247": "HIFIO1080",
		"X248": "HIFIO1080C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Simplicity PLUS special offer discount 80% or less LVR*",
		"X247": "SOVRIO80",
		"X248": "SOVRCIO80",
		"X253": "PRL",
		"X254": "ISP",
		"X262": "SOVR80",
		"X263": "PRL",
		"X264": "ISP"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Simplicity PLUS",
		"X247": "ISPIIO",
		"X248": "ISPCIO",
		"X253": "PRL",
		"X254": "ISP",
		"X262": "ISPI",
		"X263": "PRL",
		"X264": "ISP"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["variable"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Standard Variable Rate 80% or less LVR",
		"X247": "HINV80IOR",
		"X248": "HINV80IOC",
		"X253": "PRL",
		"X254": "PRLHD",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed 80% or less LVR",
		"X247": "HIFIO180",
		"X248": "HIFIO180C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed 80% or less LVR",
		"X247": "HIFIO280",
		"X248": "HIFIO280C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed 80% or less LVR",
		"X247": "HIFIO380",
		"X248": "HIFIO380C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed 80% or less LVR",
		"X247": "HIFIO480",
		"X248": "HIFIO480C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed 80% or less LVR",
		"X247": "HIFIO580",
		"X248": "HIFIO580C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "7",
		"X246": "7 years Fixed 80% or less LVR",
		"X247": "HIFIO780",
		"X248": "HIFIO780C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "70",
		"X243": "80",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "10",
		"X246": "10 years Fixed 80% or less LVR",
		"X247": "HIFIO1080",
		"X248": "HIFIO1080C",
		"X253": "PRL",
		"X254": "HINVHLSIR",
		"X262": "HINV80PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Simplicity PLUS special offer discount*",
		"X247": "SOVRIO",
		"X248": "SOVRCIO",
		"X253": "PRL",
		"X254": "ISP",
		"X262": "SOVR",
		"X263": "PRL",
		"X264": "ISP"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Simplicity PLUS",
		"X247": "ISPIIO",
		"X248": "ISPCIO",
		"X253": "PRL",
		"X254": "ISP",
		"X262": "ISPI",
		"X263": "PRL",
		"X264": "ISP"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["variable"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Standard Variable Rate",
		"X247": "HINV81IOR",
		"X248": "HINV81IOC",
		"X253": "PRL",
		"X254": "PRLHD",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed",
		"X247": "HIF1IO",
		"X248": "HIF1IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed",
		"X247": "HIF2IO",
		"X248": "HIF2IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed",
		"X247": "HIF3IO",
		"X248": "HIF3IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed",
		"X247": "HIF4IO",
		"X248": "HIF4IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed",
		"X247": "HIF5IO",
		"X248": "HIF5IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "7",
		"X246": "7 years Fixed",
		"X247": "HIFR7IO",
		"X248": "HIFR7IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "80",
		"X243": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "10",
		"X246": "10 years Fixed",
		"X247": "HIF10IO",
		"X248": "HIF10IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X244": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Simplicity PLUS special offer discount*",
		"X247": "SOVRIO100",
		"X248": "SOVRCIO100",
		"X253": "PRL",
		"X254": "ISP",
		"X262": "SOVR",
		"X263": "PRL",
		"X264": "ISP"
		}, {
		"X258": true,
		"X242": "90",
		"X245": "50000",
		"X259": ["simplicityPlus"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Simplicity PLUS",
		"X247": "ISPIIO",
		"X248": "ISPCIO",
		"X253": "PRL",
		"X254": "ISP",
		"X262": "ISPI",
		"X263": "PRL",
		"X264": "ISP"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["variable"],
		"X260": ["interestOnly"],
		"X261": false,
		"X246": "Standard Variable Rate",
		"X247": "HINV81IOR",
		"X248": "HINV81IOC",
		"X253": "PRL",
		"X254": "PRLHD",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "1",
		"X246": "1 year Fixed",
		"X247": "HIF1IO",
		"X248": "HIF1IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "2",
		"X246": "2 years Fixed",
		"X247": "HIF2IO",
		"X248": "HIF2IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "3",
		"X246": "3 years Fixed",
		"X247": "HIF3IO",
		"X248": "HIF3IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "4",
		"X246": "4 years Fixed",
		"X247": "HIF4IO",
		"X248": "HIF4IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "5",
		"X246": "5 years Fixed",
		"X247": "HIF5IO",
		"X248": "HIF5IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "7",
		"X246": "7 years Fixed",
		"X247": "HIFR7IO",
		"X248": "HIFR7IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}, {
		"X258": true,
		"X242": "90",
		"X259": ["fixed"],
		"X260": ["interestOnly"],
		"X261": false,
		"X265": "10",
		"X246": "10 years Fixed",
		"X247": "HIF10IO",
		"X248": "HIF10IOC",
		"X253": "PRL",
		"X254": "HINVIFR",
		"X262": "HINV81PIR",
		"X263": "PRL",
		"X264": "PRLHD"
		}],
	"X249": {
		"act": "Australian Capital Territory",
		"nsw": "New South Wales",
		"nt": "Northern Territory",
		"qld": "Queensland",
		"sa": "South Australia",
		"tas": "Tasmania",
		"vic": "Victoria",
		"wa": "Western Australia"
	},
	"effectiveDatePricing": "2021-03-14T00:00:00Z",
	"breakfreeSpecialOfferTable": [{
		"startDate": "2012-03-01",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "0",
		"totalMortgageLendingAmountThreshold": "0",
		"fixedInterestOnlyTermThreshold": "0",
		"applicationLvrIncludingLmiThreshold": "0",
		"breakfree": true,
		"rateType": ["fixed"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.002",
		"subsequentRateDiscount": "0",
		"fixedRateDiscount": "0.002",
		"variableRateDiscount": "0"
		}, {
		"startDate": "2012-03-01",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "0",
		"totalMortgageLendingAmountThreshold": "150000",
		"fixedInterestOnlyTermThreshold": "0",
		"applicationLvrIncludingLmiThreshold": "0",
		"breakfree": true,
		"rateType": ["fixed"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.002",
		"subsequentRateDiscount": "0.014",
		"fixedRateDiscount": "0.002",
		"variableRateDiscount": "0.014"
		}, {
		"startDate": "2012-03-01",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "0",
		"totalMortgageLendingAmountThreshold": "0",
		"fixedInterestOnlyTermThreshold": "0",
		"applicationLvrIncludingLmiThreshold": "0.8",
		"breakfree": true,
		"rateType": ["fixed"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.0015",
		"subsequentRateDiscount": "0",
		"fixedRateDiscount": "0.0015",
		"variableRateDiscount": "0"
		}, {
		"startDate": "2012-03-01",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "0",
		"totalMortgageLendingAmountThreshold": "150000",
		"fixedInterestOnlyTermThreshold": "0",
		"applicationLvrIncludingLmiThreshold": "0.8",
		"breakfree": true,
		"rateType": ["fixed"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.0015",
		"subsequentRateDiscount": "0.012",
		"fixedRateDiscount": "0.0015",
		"variableRateDiscount": "0.012"
		}, {
		"startDate": "2012-03-01",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "0",
		"totalMortgageLendingAmountThreshold": "0",
		"fixedInterestOnlyTermThreshold": "0",
		"applicationLvrIncludingLmiThreshold": "0",
		"breakfree": true,
		"rateType": ["variable"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0",
		"subsequentRateDiscount": "0",
		"variableRateDiscount": "0"
		}, {
		"startDate": "2012-03-01",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "0",
		"totalMortgageLendingAmountThreshold": "150000",
		"fixedInterestOnlyTermThreshold": "0",
		"applicationLvrIncludingLmiThreshold": "0",
		"breakfree": true,
		"rateType": ["variable"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.014",
		"subsequentRateDiscount": "0.014",
		"variableRateDiscount": "0.014"
		}, {
		"startDate": "2012-03-01",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "0",
		"totalMortgageLendingAmountThreshold": "0",
		"fixedInterestOnlyTermThreshold": "0",
		"applicationLvrIncludingLmiThreshold": "0.8",
		"breakfree": true,
		"rateType": ["variable"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0",
		"subsequentRateDiscount": "0",
		"variableRateDiscount": "0"
		}, {
		"startDate": "2012-03-01",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "0",
		"totalMortgageLendingAmountThreshold": "150000",
		"fixedInterestOnlyTermThreshold": "0",
		"applicationLvrIncludingLmiThreshold": "0.8",
		"breakfree": true,
		"rateType": ["variable"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.012",
		"subsequentRateDiscount": "0.012",
		"variableRateDiscount": "0.012"
		}, {
		"startDate": "2012-03-01",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "0",
		"fixedInterestOnlyTermThreshold": "0",
		"applicationLvrIncludingLmiThreshold": "0",
		"rateType": ["fixed"],
		"initialRateDiscount": "0.0005",
		"subsequentRateDiscount": "0",
		"fixedRateDiscount": "0.0005",
		"variableRateDiscount": "0"
		}, {
		"startDate": "2012-03-01",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "0",
		"fixedInterestOnlyTermThreshold": "0",
		"applicationLvrIncludingLmiThreshold": "0.8",
		"rateType": ["fixed"],
		"initialRateDiscount": "0",
		"subsequentRateDiscount": "0",
		"fixedRateDiscount": "0",
		"variableRateDiscount": "0"
		}, {
		"startDate": "2018-08-02",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "0",
		"investment": false,
		"rateType": ["simplicityPlus"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0",
		"subsequentRateDiscount": "0",
		"variableRateDiscount": "0"
		}, {
		"startDate": "2018-08-02",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "50000",
		"applicationLvrIncludingLmiThreshold": "0",
		"investment": false,
		"repaymentType": "Principal and Interest",
		"rateType": ["simplicityPlus"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.0102",
		"subsequentRateDiscount": "0.0102",
		"variableRateDiscount": "0.0102"
		}, {
		"startDate": "2018-08-02",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "50000",
		"applicationLvrIncludingLmiThreshold": "0.8",
		"investment": false,
		"repaymentType": "Principal and Interest",
		"rateType": ["simplicityPlus"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.0076",
		"subsequentRateDiscount": "0.0076",
		"variableRateDiscount": "0.0076"
		}, {
		"startDate": "2018-08-02",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "50000",
		"applicationLvrIncludingLmiThreshold": "0",
		"investment": true,
		"repaymentType": "Principal and Interest",
		"rateType": ["simplicityPlus"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.0062",
		"subsequentRateDiscount": "0.0062",
		"variableRateDiscount": "0.0062"
		}, {
		"startDate": "2018-08-02",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "50000",
		"applicationLvrIncludingLmiThreshold": "0.8",
		"investment": true,
		"repaymentType": "Principal and Interest",
		"rateType": ["simplicityPlus"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.0052",
		"subsequentRateDiscount": "0.0052",
		"variableRateDiscount": "0.0052"
		}, {
		"startDate": "2018-08-02",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "50000",
		"applicationLvrIncludingLmiThreshold": "0",
		"investment": true,
		"rateType": ["simplicityPlus"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.0041",
		"subsequentRateDiscount": "0.0062",
		"variableRateDiscount": "0.0041"
		}, {
		"startDate": "2018-08-02",
		"endDate": "null",
		"newApplicationLendingAmountThreshold": "50000",
		"applicationLvrIncludingLmiThreshold": "0.8",
		"investment": true,
		"rateType": ["simplicityPlus"],
		"feeWaiver": ["LAF"],
		"initialRateDiscount": "0.0041",
		"subsequentRateDiscount": "0.0052",
		"variableRateDiscount": "0.0041"
		}],
	"X148": [{
		"X149": true,
		"X156": false,
		"X157": false
		}, {
		"X149": false,
		"X151": ["fixed", "variable"],
		"X153": ["variable"],
		"X154": ["interestOnly"],
		"X156": true,
		"X157": true
		}, {
		"X149": false,
		"X151": ["fixed", "variable"],
		"X153": ["fixed"],
		"X154": ["interestOnly", "principalAndInterest"],
		"X156": false,
		"X157": true
		}, {
		"X149": false,
		"X151": ["fixed", "variable"],
		"X153": ["variable"],
		"X154": ["principalAndInterest"],
		"X156": true
		}, {
		"X149": false,
		"X151": ["simplicityPlus"],
		"X153": ["simplicityPlus"],
		"X154": ["interestOnly"],
		"X156": true,
		"X157": true
		}, {
		"X149": false,
		"X152": ["lineOfCredit"],
		"X154": ["lineOfCredit"],
		"X155": false,
		"X156": true
		}, {
		"X149": false,
		"X156": false,
		"X157": false
		}],
		"X083": ["new"],
		"X084": ["new", "existing"],
		"X095": false,
		"X085": false,
	"breakfreeCreditCardTypes": [{
		"cardId": "1",
		"cardType": "ANZ Platinum",
		"minimum": "6000",
		"maximum": "50000",
		"frequentFlyer": false,
		"downgrade": false
		}, {
		"cardId": "2",
		"cardType": "ANZ Frequent Flyer Platinum",
		"minimum": "6000",
		"maximum": "50000",
		"frequentFlyer": true,
		"downgrade": false,
		"disclaimer": "Additional Rewards Program Services Fee applies"
		}, {
		"cardId": "3",
		"cardType": "ANZ Rewards Platinum",
		"minimum": "6000",
		"maximum": "50000",
		"frequentFlyer": false,
		"downgrade": false,
		"disclaimer": "Additional Rewards Program Services Fee applies"
		}, {
		"cardId": "4",
		"cardType": "ANZ Low Rate Platinum (discontinued)",
		"minimum": "6000",
		"maximum": "50000",
		"frequentFlyer": false,
		"downgrade": false,
		"disclaimer": "ANZ has stopped issuing ANZ Low Rate Platinum Mastercard accounts on 25 May 2018. These accounts will be replaced with the ANZ Platinum Visa card account. If your application for ANZ Low Rate Platinum was approved or your card(s) are issued after 25 May 2018, you will be issued an ANZ Platinum account. Your ANZ Platinum account will be a Visa card, instead of a Mastercard, but will have the same or better fees and interest rates as the ANZ Low Rate Platinum account. You should review the product features at www.anz.com/platinumcompare before submitting this application."
		}, {
		"cardId": "9",
		"cardType": "ANZ Low Rate Visa",
		"minimum": "1000",
		"maximum": "50000",
		"frequentFlyer": false,
		"downgrade": false
		}, {
		"cardId": "8",
		"cardType": "ANZ Rewards Travel Adventures",
		"minimum": "6000",
		"maximum": "50000",
		"frequentFlyer": false,
		"downgrade": false,
		"disclaimer": "Additional Rewards Program Services Fee applies"
		}, {
		"cardId": "5",
		"cardType": "ANZ Rewards Black",
		"minimum": "15000",
		"maximum": "75000",
		"frequentFlyer": false,
		"downgrade": true,
		"disclaimer": "Additional Rewards Program Services Fee applies"
		}, {
		"cardId": "7",
		"cardType": "ANZ Frequent Flyer Black",
		"minimum": "15000",
		"maximum": "75000",
		"frequentFlyer": true,
		"downgrade": true,
		"disclaimer": "Additional Rewards Program Services Fee applies"
		}, {
		"cardId": "10",
		"cardType": "No Card",
		"minimum": "0",
		"maximum": "0",
		"frequentFlyer": false,
		"downgrade": false
		}, {
		"cardId": "6",
		"cardType": "No Change"
		}],
	"breakfreeCreditCardFilter": [{
		"filterID": "7",
		"filterName": "No Card",
		"cardStatus": ["new","existing"],
		"cardId": ["10"]
		}, {
		"filterID": "1",
		"filterName": "No Change",
		"cardStatus": ["existing"],
		"cardId": ["3","5","8"]
		}, {
		"filterID": "2",
		"filterName": "Flexible rewards card",
		"cardStatus": ["new","existing"],
		"cardId": ["3","5","8"]
		}, {
		"filterID": "3",
		"filterName": "Qantas Frequent Flyer card",
		"cardStatus": ["new","existing"],
		"cardId": ["2","7"]
		}, {
		"filterID": "4",
		"filterName": "Low ongoing interest rate",
		"cardStatus": ["new","existing"],
		"cardId": ["9"]
		}, {
		"filterID": "5",
		"filterName": "Simple everyday card",
		"cardStatus": ["new","existing"],
		"cardId": ["1","9"]
		}, {
		"filterID": "6",
		"filterName": "All cards",
		"cardStatus": ["new","existing"],
		"cardId": ["1","2","3","4","9","5","7","8"]
		}],
	"transactionAccountAssuredTypes": [{
		"assuredId": "1",
		"assuredName": "Not Required",
		"accountStatus": ["new","existing"],
		"downgrade": false
		}, {
		"assuredId": "2",
		"assuredName": "Purpose Not Eligible",
		"accountStatus": ["new","existing"],
		"downgrade": false,
		"disclaimer": "ANZ Assured only provides cover for temporary expenses arrising on your ANZ Everyday Account. Customer cannot apply for an ANZ Assured Facility for any other purpose."
		}, {
		"assuredId": "3",
		"assuredName": "New $500 Limit",
		"accountStatus": ["new","existing"],
		"downgrade": false
		}, {
		"assuredId": "4",
		"assuredName": "New $1000 Limit without downgrade",
		"accountStatus": ["new","existing"],
		"downgrade": false,
		"disclaimer": "Only consider the customer for a $1,000 limit and if declined, do not consider the customer for a $500 limit."
		}, {
		"assuredId": "5",
		"assuredName": "New $1000 Limit with downgrade",
		"accountStatus": ["new","existing"],
		"downgrade": true,
		"disclaimer": "If the customer does not meet the credit product requirements for the $1,000 limit, they consent to being considered for, and if approved, issued with a $500 limit."
		}, {
		"assuredId": "6",
		"assuredName": "Increase to $1000",
		"accountStatus": ["existing"],
		"downgrade": false
		}, {
		"assuredId": "7",
		"assuredName": "Existing Limit",
		"accountStatus": ["existing"],
		"downgrade": false
		}],
	"breakfreeLoanTypes": [{
		"new": true,
		"rateType": ["fixed","variable"]
		}, {
		"new": false,
		"anz": true,
		"X086": ["Standard Residential"],
		"X162": "0.01",
		"X087": "0.01"
		}],
	"X135": [{
		"X161": "1",
		"X136": "Payslip & 3 Months Statements (Weekly)",
		"X137": "Weekly",
		"X147": "3",
		"X138": "13"
		}, {
		"X161": "2",
		"X136": "Payslip & 3 Months Statements (Fortnightly)",
		"X137": "Fortnightly",
		"X147": "3",
		"X138": "7"
		}, {
		"X161": "3",
		"X136": "Payslip & 3 Months Statements (Monthly)",
		"X137": "Monthly",
		"X147": "3",
		"X138": "3"
		}, {
		"X161": "4",
		"X136": "6 Months Statements (Weekly)",
		"X137": "Weekly",
		"X147": "6",
		"X138": "26"
		}, {
		"X161": "5",
		"X136": "6 Months Statements (Fortnightly)",
		"X137": "Fortnightly",
		"X147": "6",
		"X138": "13"
		}, {
		"X161": "6",
		"X136": "6 Months Statements (Monthly)",
		"X137": "Monthly",
		"X147": "6",
		"X138": "6"
		}],
	"X122": [{
		"X126": "1",
		"X123": "Other",
		"X124": "Maintenance",
		"X125": false
		}, {
		"X126": "2",
		"X123": "Other",
		"X124": "Trust Disbursement",
		"X125": true
		}, {
		"X126": "3",
		"X123": "Other",
		"X124": "Other Taxable",
		"X125": true
		}, {
		"X126": "4",
		"X123": "Other",
		"X124": "Other Non-Taxable",
		"X125": false
		}, {
		"X126": "5",
		"X123": "Government",
		"X124": "Aged Pension",
		"X125": false
		}, {
		"X126": "6",
		"X123": "Government",
		"X124": "Carers Payment",
		"X125": false
		}, {
		"X126": "7",
		"X123": "Government",
		"X124": "Disability Pension",
		"X125": false
		}, {
		"X126": "8",
		"X123": "Government",
		"X124": "Family Tax Benefit A & B",
		"X125": false
		}, {
		"X126": "9",
		"X123": "Government",
		"X124": "Parenting Payment",
		"X125": false
		}, {
		"X126": "10",
		"X123": "Government",
		"X124": "Foster Care",
		"X125": false
		}, {
		"X126": "11",
		"X123": "Government",
		"X124": "Veteren Affairs Pension",
		"X125": false
		}, {
		"X126": "12",
		"X123": "Government",
		"X124": "Austudy/Newstart Allowance",
		"X125": true
		}, {
		"X126": "13",
		"X123": "Government",
		"X124": "Other Government Benefits",
		"X125": true
		}, {
		"X126": "14",
		"X123": "Government",
		"X124": "Workcover Benefits",
		"X125": true
		}]
}
